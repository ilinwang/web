root_path=$(dirname "$0")


echo "#!/bin/bash" > $root_path/generate_solution.sh
echo "cd $root_path" >> $root_path/generate_solution.sh
echo "" >> $root_path/generate_solution.sh


code_folder="bin"
n_it_s=10
n_it_l=1


for alg in My_BF_deque_all_ntc My_BF_queue_all_ntc My_spdial_all_ntc My_spheap_all_ntc My_FW_a_all_ntc My_FW_g_all_ntc
# for alg in My_FW_g_all_ntc
do
    folder_path="$root_path/$alg"
    if [ ! -d "$folder_path" ]; then
        mkdir "$folder_path"
    fi

    for x in 10
    do
        for y in 10 25 50
        # for y in 50
        do
            for c1 in "1 1000" "1000 10000"
            do
                for c2 in "1 1000" "1000 10000"
                do
                    for r in "0.1 1"
                    do
                        for seed in 2 20 200 2000
                        do
                        set -- $c1
                        first1="$1"
                        second1="$2"
                        set -- $c2
                        first2="$1"
                        second2="$2"
                        set -- $r
                        first3="$1"
                        second3="$2"
                    
                        echo "$code_folder/$alg inputs/x${x}_y${y}_c1min${first1}_c1max${second1}_c2min${first2}_c2max${second2}_rmin${first3}_rmax${second3}_seed${seed}.txt $n_it_s > $folder_path/${alg}_x${x}_y${y}_c1min${first1}_c1max${second1}_c2min${first2}_c2max${second2}_rmin${first3}_rmax${second3}_seed${seed}_solution.txt" >> $root_path/generate_solution.sh

                        done
                    done
                done
            done
        done
    done     
done

for alg in My_BF_deque_all_ntc My_BF_queue_all_ntc My_spdial_all_ntc My_spheap_all_ntc My_FW_a_all_ntc My_FW_g_all_ntc 
# for alg in My_FW_g_all_ntc
do
    folder_path="$root_path/$alg"
    if [ ! -d "$folder_path" ]; then
        mkdir "$folder_path"
    fi

    for x in 50 100
    do
        for y in 10 25 50
        # for y in 50
        do
            for c1 in "1 1000" "1000 10000"
            do
                for c2 in "1 1000" "1000 10000"
                do
                    for r in "0.1 1"
                    do
                        for seed in 2 20 200 2000
                        do
                        set -- $c1
                        first1="$1"
                        second1="$2"
                        set -- $c2
                        first2="$1"
                        second2="$2"
                        set -- $r
                        first3="$1"
                        second3="$2"
                    
                        echo "$code_folder/$alg inputs/x${x}_y${y}_c1min${first1}_c1max${second1}_c2min${first2}_c2max${second2}_rmin${first3}_rmax${second3}_seed${seed}.txt $n_it_l > $folder_path/${alg}_x${x}_y${y}_c1min${first1}_c1max${second1}_c2min${first2}_c2max${second2}_rmin${first3}_rmax${second3}_seed${seed}_solution.txt" >> $root_path/generate_solution.sh

                        done
                    done
                done
            done
        done
    done     
done

