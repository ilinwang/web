In this folder, you will find the following files and directories:

1. `bin` folder: Contains six algorithms for solving the network.
2. `src` folder: Includes a network generator.
3. `batch_generate_network.sh`: Creates a batch file to generate the network.
4. `batch_generate_solution.sh`: Creates a batch file to solve the network.
5. `summarize_result.ipynb`: Generates an Excel file summarizing the results of the six algorithms solving the networks.

To get started, follow these steps:

1. Run `batch_generate_network.sh` to generate the `generate_network.sh` file.
2. Run `generate_network.sh` to create an `inputs` folder if it doesn't exist and generate the networks.
3. Run `batch_generate_solution.sh` to generate the `generate_solution.sh` file and to create six folders, one for each algorithm to store their respective results.
4. Run `generate_solution.sh`  to generate the results in the appropriate folders.
5. Run `summarize_result.ipynb` to generate a summary Excel file containing all the results.
