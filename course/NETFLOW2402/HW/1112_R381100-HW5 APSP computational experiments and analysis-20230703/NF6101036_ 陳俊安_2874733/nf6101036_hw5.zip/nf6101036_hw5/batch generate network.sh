root_path=$(dirname "$0")
file=spweb2
final_file_location="Inputs"

echo "#!/bin/bash" > $root_path/generate_network.sh
echo "cd $root_path" >> $root_path/generate_network.sh
echo "" >> $root_path/generate_network.sh



# 1. 陳俊安 : 
# x: 10, 100, 1000; 
# y: 10, 50, 100; 
# (c1min,c1max)=(1,1000), (1000,10000); 
# (c2min,c2max)=(1,1000), (1000,10000); 
# (r_min, r_max)=(0.1,1); 
# seed: 2, 20, 200, 2000 
# 共 3x3x2x2x1x4=154個 cases
    
# spweb2 name x y c1min c1max c2min c2max rmin rmax seed

# c1_tuple=( (1,1000) (1000,10000) )
# c2_tuple=( (1,1000) (1000,10000) )

#create folder
folder_path="$root_path/$final_file_location"
    if [ ! -d "$folder_path" ]; then
        mkdir "$folder_path"
    fi

for x in 10 50 100
do
    for y in 10 25 50
    do
        for c1 in "1 1000" "1000 10000"
        do
            for c2 in "1 1000" "1000 10000"
            do
                for r in "0.1 1"
                do
                    for seed in 2 20 200 2000
                    do
                    set -- $c1
                    first1="$1"
                    second1="$2"
                    set -- $c2
                    first2="$1"
                    second2="$2"
                    set -- $r
                    first3="$1"
                    second3="$2"
                
                    echo "src/${file} x${x}_y${y}_c1min${first1}_c1max${second1}_c2min${first2}_c2max${second2}_rmin${first3}_rmax${second3}_seed${seed} ${x} ${y} ${first1} ${second1} ${first2} ${second2} ${first3} ${second3} ${seed} > ${final_file_location}/x${x}_y${y}_c1min${first1}_c1max${second1}_c2min${first2}_c2max${second2}_rmin${first3}_rmax${second3}_seed${seed}.txt" >> $root_path/generate_network.sh

                    done
                done
            done
        done
    done
done

