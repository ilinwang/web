#!/bin/bash

# Set the parameter values
code_names1=(fwg)
#heap bf pape dial fwa fwg

#heap for 82~144
#for ((i=82;i<=144;i++))
#do
#	echo "heap input$i.txt 1"
#	#command line
#	./heap input$i.txt 1
#done

#dial
for ((i=1;i<=100;i++))
do
	echo "dial input$i.txt 1"
	#command line
	./dial input$i.txt 1
done