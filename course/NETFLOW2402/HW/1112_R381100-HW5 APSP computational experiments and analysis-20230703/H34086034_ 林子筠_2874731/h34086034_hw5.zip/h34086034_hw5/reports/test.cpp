/*
    This code can be compiled and run ok, but will occur stack overflow when n*C+1 is about 180001.

    purpose:
        Read file, printout ALL-ALL shortest paths' total length, using Dijkstra's Dial's bucket.

    usage:
        h34086034_spdial  no output file input1.txt

    input file:
        input1.txt

    output file:
        no

    compile:
        g++ -o h34086034_spdial h34086034_spdial.cpp

    pseudocode:
    read file, m, and n
    ------
    store arcs A and arc lengths L
    ------
    Dijkstra's Dial's bucket
    ------
    print result

    coded by Zi-Yun Lin, ID: H34086034, email: celine20001024@gmail.com
    date: 2023.05.03
*/

#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<queue>
#include<algorithm>
#include <ctime>
#include <cmath>

#define INF 9999999

using namespace std;

int main(){

	string fname;
    int n_it = 1;
    cin >> fname >> n_it;

	string path = "./inputs/" + fname;

	ifstream file;
	file.open(path.c_str());

	string str, temp;
    int n1, n2, len; //n1: from, n2: to
    int n = 0, m = 0, x = 0;

	while(getline(file,str)){
        //read n,m
        if(str[0] == 'p'){
		    for(int i = 0; i < str.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n = stoi(temp.substr(0,x));
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            m = stoi(temp.substr(1,x));
            break;
    }}

    vector<int> A[n+1]; //store from to
    vector<int> L[n+1]; //store arc length

    while(getline(file,str)){
		if(str[0] == 'a'){
            //split str for node1
            for(int i = 0; i < str.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n1 = stoi(temp.substr(0,x));
            //split str for node2
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n2 = stoi(temp.substr(0,x));
            //split str for arc length
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}

            len = stoi(temp.substr(x));
            cout << len << endl;
            A[n1].push_back(n2);
            L[n1].push_back(len);
    }}

	//Dial's bucket
	int comparisons = 0; //nontrivial triple comparisons
    int sum_print = 0;

    int C = L[1][0]; //max length
	for(int i = 1; i <= n; i++){
        for(int j = 0; j < L[i].size(); j++){
            if(L[i][j] > C){
                C = L[i][j];
    }}}
    cout << "C = " << C << endl;
    C = sqrt(C);
    cout << "C = " << C << endl;

    //time computation
    clock_t start = clock();

    for(int loop = 1; loop <= n_it; loop++){
        vector<vector<int>> d(n+1, vector<int>(n+1, INF)); //distance

        for(int i = 1; i <= n; ++i){
            d[i][i] = 0;
        }

        for(int s = 1; s <= n; s++){
            vector<vector<int>> B(n * C + 1);//creat buckets B
            B[0].push_back(s);

            int idx = 0;
            int min_node;

            while(1){
                while(B[idx].size() == 0 && idx < n*C){idx++;} //find idx of non-empty bucket

                if(idx == n*C){break;}

                min_node = B[idx][0];
                B[idx].erase(B[idx].begin());

                for(int j = 0; j < A[min_node].size() ; j++){ //for each arc(i,j) in A(i)
                    if(d[s][A[min_node][j]] >= d[s][min_node] + L[min_node][j]){
                        if(d[s][A[min_node][j]] != INF){
                            comparisons++;
                            B[d[s][A[min_node][j]]].erase(remove(B[d[s][A[min_node][j]]].begin(), B[d[s][A[min_node][j]]].end(), A[min_node][j]), B[d[s][A[min_node][j]]].end());
                        }
                        B[d[s][min_node] + L[min_node][j]].push_back(A[min_node][j]);
                        d[s][A[min_node][j]] = d[s][min_node] + L[min_node][j];
        }}}}

        int sum = 0; //sum of all the ALL-ALL shortest path lengths
        for(int i = 1; i <= n; ++i){
            for(int j = 1; j <= n; ++j){
                if(d[i][j] != INF){
                    sum += d[i][j];
        }}}
        sum_print = sum;
    }

    clock_t stop = clock();
    double t = static_cast<double>(stop - start) / CLOCKS_PER_SEC;

    cout << "Sum of distances: " << sum_print << endl;
    cout << "Running time: " << t << endl;
    cout << "Total number of nontrivial triple comparisons: " << comparisons << endl;

	file.close();
	return 0;
}
