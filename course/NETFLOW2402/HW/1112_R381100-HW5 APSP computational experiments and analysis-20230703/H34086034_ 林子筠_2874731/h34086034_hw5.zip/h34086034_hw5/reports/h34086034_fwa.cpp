/*
    This code can be compiled and run ok.

    purpose:
        Read file, printout ALL-ALL shortest paths' total length, using Floyd-Warshal Algebraic.

    usage:
        h34086034_bf  no output file  input1.txt

    input file:
        input1.txt

    output file:
        no

    compile:
        g++ -o h34086034_fwa h34086034_fwa.cpp

    pseudocode:
    read file, m, and n
    ------
    store arcs A and arc lengths L
    ------
    Floyd-Warshal Algebraic
    ------
    print result

    coded by Zi-Yun Lin, ID: H34086034, email: celine20001024@gmail.com
    date: 2023.05.30
*/

#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<queue>
#include <ctime>

#define INF 9999999

using namespace std;

struct Edge{
    int source;
    int destin;
    int length;
};

int main(int argc, char* argv[]){

	string fname;
    int n_it = 1;

	if(argc > 2){
        fname = argv[1];
        n_it = stoi(argv[2]);
    } else{
        cout << "Please provide the network filename and the total number of iterations as command-line arguments." << endl;
        return 1;
    }

	string path = "./inputs/" + fname;

	ifstream file;
	file.open(path.c_str());

	string str, temp;
    int n1, n2, len; //n1: from, n2: to
    int n = 0, m = 0, x = 0;

	while(getline(file,str)){
        //read n,m
        if(str[0] == 'p'){
		    for(int i = 0; i < str.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n = stoi(temp.substr(0,x));
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            m = stoi(temp.substr(1,x));
            break;
    }}

    vector<Edge> edges(m);
    int e = 0;

    while(getline(file,str)){
		if(str[0] == 'a'){
            //split str for node1
            for(int i = 0; i < str.size(); i++){
                if(isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n1 = stoi(temp.substr(0,x));
            //split str for node2
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n2 = stoi(temp.substr(0,x));
            //split str for arc length
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            len = stoi(temp.substr(x));
            edges[e] = {n1, n2, len};
            e++;
    }}

    //Floyd-Warshal Algebraic
    int comparisons = 0; //nontrivial triple comparisons
    int sum_print = 0;

    //time computation
    clock_t start = clock();

    for(int loop = 1; loop <= n_it; loop++){
        vector<vector<int>> d(n+1, vector<int>(n+1, INF)); //distance

        for(int i = 0; i < m; ++i){
            d[edges[i].source][edges[i].destin] = edges[i].length;
        }

        //diagonal elements
        for(int i = 1; i <= n; ++i){
            d[i][i] = 0;
        }

        for(int k = 1; k <= n; ++k){ //source
            for(int i = 1; i <= n; ++i){ //destination
                for(int j = 1; j <= n; ++j){ //update distance with intermediate nodes
                    if(d[i][j] > d[i][k] + d[k][j] && d[k][j] != INF && d[i][k] != INF){
                        comparisons++;
                        d[i][j] = d[i][k] + d[k][j];
        }}}}

        int sum = 0; //sum of all the ALL-ALL shortest path lengths
        for(int i = 1; i <= n; ++i){
            for(int j = 1; j <= n; ++j){
                if(d[i][j] != INF){
                    sum += d[i][j];
        }}}
        sum_print = sum;
    }

    clock_t stop = clock();
    double t = static_cast<double>(stop - start) / CLOCKS_PER_SEC;

    cout << "Sum of distances: " << sum_print << endl;
    cout << "Running time: " << t << endl;
    cout << "Total number of nontrivial triple comparisons: " << comparisons << endl;

	file.close();
	return 0;
}
