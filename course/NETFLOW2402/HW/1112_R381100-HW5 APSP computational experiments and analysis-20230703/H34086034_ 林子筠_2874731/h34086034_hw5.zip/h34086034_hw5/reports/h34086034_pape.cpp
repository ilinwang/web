/*
    This code can be compiled and run ok.

    purpose:
        Read file, printout ALL-ALL shortest paths' total length, using PAPE.

    usage:
        h34086034_pape  no output file  input1.txt

    input file:
        input1.txt

    output file:
        no

    compile:
        g++ -o h34086034_pape h34086034_pape.cpp

    pseudocode:
    read file, m, and n
    ------
    store arcs A and arc lengths L
    ------
    PAPE
    ------
    print result

    coded by Zi-Yun Lin, ID: H34086034, email: celine20001024@gmail.com
    date: 2023.03.23
*/

#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<queue>
#include <ctime>

#define INF 9999999

using namespace std;

int main(int argc, char* argv[]){

	string fname;
    int n_it = 1;

	if(argc > 2){
        fname = argv[1];
        n_it = stoi(argv[2]);
    } else{
        cout << "Please provide the network filename and the total number of iterations as command-line arguments." << endl;
        return 1;
    }

	string path = "./inputs/" + fname;

	ifstream file;
	file.open(path.c_str());

	string str, temp;
    int n1, n2, len;
    int n = 0, m = 0, x = 0;

	while(getline(file,str)){
        //read n,m
        if(str[0] == 'p'){
		    for(int i = 0; i < str.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n = stoi(temp.substr(0,x));
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            m = stoi(temp.substr(1,x));
            break;
    }}

    vector<int> A[n+1]; //store from to
    vector<int> L[n+1]; //store arc length

    while(getline(file,str)){
		if(str[0] == 'a'){
            //split str for node1
            for(int i = 0; i < str.size(); i++){
                if(isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n1 = stoi(temp.substr(0,x));
            //split str for node2
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n2 = stoi(temp.substr(0,x));
            //split str for arc length
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            len = stoi(temp.substr(x));
            A[n1].push_back(n2);
            L[n1].push_back(len);
        }
    }

    //PAPE
    int comparisons = 0; //nontrivial triple comparisons
    int sum_print = 0;

    //time computation
    clock_t start = clock();

    for(int loop = 1; loop <= n_it; loop++){
        vector<vector<int>> d(n+1, vector<int>(n+1, INF)); //distance

        for(int i = 1; i <= n; ++i){
            d[i][i] = 0;
        }

        for(int s = 1; s <= n; s++){
            vector<int> delta;
            delta.push_back(s);

            while(!delta.empty()){
                int cur = delta.back(); //current node
                delta.pop_back();

                for(int j = 0; j < A[cur].size() ; j++){ //for each arc(i,j) in A(i)
                    int temp = d[s][cur] + L[cur][j];
                    if(d[s][cur] != INF && d[s][A[cur][j]] > temp){
                        comparisons++;
                        d[s][A[cur][j]] = temp;
                        delta.push_back(A[cur][j]);
        }}}}

        int sum = 0; //sum of all the ALL-ALL shortest path lengths
        for(int i = 1; i <= n; ++i){
            for(int j = 1; j <= n; ++j){
                if(d[i][j] != INF){
                    sum += d[i][j];
        }}}
        sum_print = sum;
    }

    clock_t stop = clock();
    double t = static_cast<double>(stop - start) / CLOCKS_PER_SEC;

    cout << "Sum of distances: " << sum_print << endl;
    cout << "Running time: " << t << endl;
    cout << "Total number of nontrivial triple comparisons: " << comparisons << endl;

	file.close();
	return 0;
}
