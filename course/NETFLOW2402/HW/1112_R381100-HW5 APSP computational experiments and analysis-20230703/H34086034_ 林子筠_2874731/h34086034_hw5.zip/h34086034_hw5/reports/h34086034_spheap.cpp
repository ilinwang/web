/*
    This code can be compiled and run ok.

    purpose:
        Read file, printout ALL-ALL shortest paths' total length, using Dijkstra's binary heap.

    usage:
        h34086034_spheap  no output file  input1.txt

    input file:
        input1.txt

    output file:
        no

    compile:
        g++ -o h34086034_spheap h34086034_spheap.cpp

    pseudocode:
    dijkstra function
    ------
    read m,n
    ------
    store arcs A and arc lengths L
    ------
    Binary Heap
    ------
    print result

    coded by Zi-Yun Lin, ID: H34086034, email: celine20001024@gmail.com
    date: 2023.05.03
*/
#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<queue>
#include <ctime>
#include <limits>

#define INF 9999999

using namespace std;

struct Edge {
    int to, weight;
    Edge(int to, int weight) : to(to), weight(weight) {}
};

typedef vector<vector<Edge>> AdjList;

struct HeapNode {
    int node, dist;
    HeapNode(int node, int dist) : node(node), dist(dist) {}
    bool operator<(const HeapNode& other) const {
        return dist > other.dist;
    }
};

int main(int argc, char* argv[]){

    string fname;
    int n_it = 1;

	if(argc > 2){
        fname = argv[1];
        n_it = stoi(argv[2]);
    } else{
        cout << "Please provide the network filename and the total number of iterations as command-line arguments." << endl;
        return 1;
    }

	string path = "./inputs/" + fname;

	ifstream file;
	file.open(path.c_str());

	string str, temp;
    int n1, n2, len;
    int n = 0, m = 0, x = 0;

	while(getline(file,str)){
        //read n,m
        if(str[0] == 'p'){
		    for(int i = 0; i < str.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n = stoi(temp.substr(0,x));
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            m = stoi(temp.substr(1,x));
            break;
    }}

    AdjList A(n+1);

    while(getline(file,str)){
		if(str[0] == 'a'){
            //split str for node1
            for(int i = 0; i < str.size(); i++){
                if(isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n1 = stoi(temp.substr(0,x));
            //split str for node2
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n2 = stoi(temp.substr(0,x));
            //split str for arc length
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            len = stoi(temp.substr(x));
            A[n1].push_back(Edge(n2, len));
    }}

    //Dijkstra
    int comparisons = 0; //nontrivial triple comparisons
    int sum_print = 0;

    //time computation
    clock_t start = clock();

    for(int loop = 1; loop <= n_it; loop++){
        vector<vector<int>> d(n+1, vector<int>(n+1, INF)); //distance
        for(int i = 1; i <= n; ++i){
            d[i][i] = 0;
        }

        for(int s = 1; s <= n; s++){
            priority_queue<HeapNode> H;
            H.push(HeapNode(s, 0));

            while(!H.empty()){
                HeapNode node = H.top();
                H.pop();

                if(node.dist > d[s][node.node]){continue;}

                for(const Edge& edge : A[node.node]){
                    int temp = d[s][node.node] + edge.weight;
                    if(temp < d[s][edge.to]){
                        comparisons++;
                        d[s][edge.to] = temp;
                        H.push(HeapNode(edge.to, temp));
        }}}}

        int sum = 0; //sum of all the ALL-ALL shortest path lengths
        for(int i = 1; i <= n; ++i){
            for(int j = 1; j <= n; ++j){
                if(d[i][j] != INF){
                    sum += d[i][j];
        }}}
        sum_print = sum;
    }

    clock_t stop = clock();
    double t = static_cast<double>(stop - start) / CLOCKS_PER_SEC;

    cout << "Sum of distances: " << sum_print << endl;
    cout << "Running time: " << t << endl;
    cout << "Total number of nontrivial triple comparisons: " << comparisons << endl;

	file.close();
	return 0;
}
