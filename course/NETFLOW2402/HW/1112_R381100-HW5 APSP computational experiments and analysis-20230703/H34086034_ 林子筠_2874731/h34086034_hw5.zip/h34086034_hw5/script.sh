#!/bin/bash

# Set the parameter values
x_values=(10 100 1000)
y_values=(10 50 100)
c1_ranges=("1 1000" "1000 10000")
c2_ranges=("1 1000" "1000 10000")
r_range=("0.1 1")
seed_values=(1 10 100 1000)
num=1

# Loop through the parameter combinations
for x in "${x_values[@]}"
do
	for y in "${y_values[@]}"
	do
		for c1 in "${c1_ranges[@]}"
		do
			for c2 in "${c2_ranges[@]}"
			do
				for r in "${r_range[@]}"
				do
					for seed in "${seed_values[@]}"
					do
						#command line
						./bin/spweb2 name $x $y $c1 $c2 $r $seed > ./reports/inputs/input$num.txt
						
						((num++))
					done
				done
			done
		done
	done
done