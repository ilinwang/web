
#include <iostream>
#include <fstream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/times.h>

using namespace std;

float mytimer()
{ struct tms hold;
 
 times(&hold);
 /*return  (float)(hold.tms_utime) / 60.0;*/
 return  (float)(hold.tms_utime);
}

struct arc {
    int from,to;
    float length;
};

struct ADL {
    int nod,dis;
};

struct node {
    int num;
    int pred;
};

int main(int argc, const char * argv[]) {
    
    int n,m;
    int n_it,Total = 0;
    string filename;
    ifstream file;
    cin >> filename >> n_it;
    file.open(filename,ios::in);
    string line,problem;
    arc * matrix;
    
    float t1=0.,t2=0.;
    t1=mytimer();

    int temp_i,temp_j;
    int * point;
    int * count;
    int * d;
    bool * check;
    node * N;
    int a = 1;
    vector<vector<ADL> > out, in, dist;
    while (getline(file,line)) {
        char head;
        file >> head;
        if (head == 'p') {
            file >> problem >> n >> m;
            matrix = new arc [m+1];
            point = new int [n+1];
            count = new int [n+1];
            check = new bool [n+1];
            d = new int [n+1];
            N = new node [n+1];
            for (int i=1; i<=n; i++){
                N[i].num = i;
                N[i].pred = 0;
                d[i] = 10000;
                check[i] = false;
                out.resize(n + 1);
                in.resize(n + 1);
                dist.resize(n + 1);
            }
            for (int i=0; i<=n; i++)
                count[i] = 0;
        }
        else if (head == 'a') {
            ADL inn,outt;
            file >> temp_i >> temp_j;
            count[temp_i]++;
            matrix[a].from = temp_i;
            matrix[a].to = temp_j;
            file >> matrix[a].length;
            inn.nod = temp_i;
            outt.nod = temp_j;
            inn.dis = matrix[a].length;
            outt.dis = matrix[a].length;
            out[temp_i].push_back(outt);
            in[temp_j].push_back(inn);
            a++;
        }
    }
    point[1] = 1;
    
    for (int i=2; i<n+1; i++) {
        point[i] = point[i-1] + count[i-1];
    }
    
    
    for (int aa=0; aa<n_it; aa++) {
        for (int k=1; k<=n; k++) {
            for (int i=0;i<in[k].size();++i) {
                for (int j=0;j<out[k].size();++j) {
                    int value = out[k][j].dis + in[k][i].dis;
                    bool check = false;
                    for (int g = 0;g<out[in[k][i].nod].size();++g) {
                        if (out[in[k][i].nod][g].nod == out[k][j].nod) {
                            if (out[in[k][i].nod][g].dis > value) {
                                out[in[k][i].nod][g].dis = value;
                            }
                            check = true;
                            break;
                        }
                    }
                    if (!check) {
                        ADL outtt;
                        outtt.dis = value;
                        outtt.nod = out[k][j].nod;
                        out[in[k][i].nod].push_back(outtt);
                    }
                    Total++;
                }
            }
        }
    }
//    for (int a=1; a<n+1; ++a) {
//        if (a != source) {
//            cout << source << "->" << a << ":[";
//            if (d[a] == 10000) {
//                cout << "can not reach]" << endl;
//            }
//            else {
//                cout << d[a] << "]" << a << "<-";
//                int temp = N[a].pred;
//                while (temp != source) {
//                    cout << temp << "<-";
//                    temp = N[temp].pred;
//                }
//                cout << source << endl;
//            }
//        }
//    }
    
    t2=mytimer();
    
    cout << t2-t1 << "\t" << Total << "\t";
    delete [] point;
    delete [] count;
    delete [] d;
    delete [] N;
    delete [] matrix;
    delete [] check;
    
    return 0;
}
