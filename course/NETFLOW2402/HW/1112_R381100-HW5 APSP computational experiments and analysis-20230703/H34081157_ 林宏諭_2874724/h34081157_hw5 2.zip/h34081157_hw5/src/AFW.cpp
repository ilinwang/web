
#include <iostream>
#include <fstream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/times.h>

using namespace std;

float mytimer()
{ struct tms hold;
 
 times(&hold);
 /*return  (float)(hold.tms_utime) / 60.0;*/
 return  (float)(hold.tms_utime);
}

struct arc {
    int from,to;
    float length;
};

struct node {
    int num;
    int pred;
};

int main(int argc, const char * argv[]) {
    
    int n,m;
    int n_it,Total = 0;
    string filename;
    ifstream file;
    cin >> filename >> n_it;
    file.open(filename,ios::in);
    string line,problem;
    int M = 10000;
    float t1=0.,t2=0.;
    t1=mytimer();

    int temp_i,temp_j;
    int ** D;
    int ** PRED;
    int a = 1;
    while (getline(file,line)) {
        char head;
        file >> head;
        if (head == 'p') {
            file >> problem >> n >> m;
            D = new int*[n+1];
            for (int i=0;i<=n;++i)
                D[i] = new int[n+1];
            PRED = new int*[n+1];
            for (int i=0;i<=n;++i)
                PRED[i] = new int[n+1];
            for (int i=1; i<=n; i++){
                for (int j=1;j<=n;++j){
                    D[i][j] = M;
                    PRED[i][j] = i;
                    
                }
            }
        }
        else if (head == 'a') {
            file >> temp_i >> temp_j;
            file >> D[temp_i][temp_j];
        }
    }
    
    for (int aa=0; aa<n_it; aa++) {
        for (int k=1; k<=n; k++) {
            for (int i=1; i<=n; i++) {
                for (int j=1; j<=n; j++) {
                    if (i!=k and j!= k) {
                        if (D[i][j]> D[i][k] + D[k][j] and D[i][k] != M and D[k][j] != M) {
                            Total++;
                            D[i][j] = D[i][k] + D[k][j];
                            PRED[i][j] = PRED[k][j];
                        }
                            
                    }
                }
            }
        }
    }
    
    t2=mytimer();
    cout << t2-t1 << "\t" << Total << "\t";
    for (int i = 0; i <= n; i++) {
        delete[] PRED[i];
        delete[] D[i];
    }
    delete[] D;
    delete[] PRED;
    
    return 0;
}
