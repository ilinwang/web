g++ src/BF.cpp -o BF
g++ src/PAPE.cpp -o PAPE
g++ src/DIKH.cpp -o DIKH
g++ src/DIKD.cpp -o DIKD
g++ src/AFW.cpp -o AFW
g++ src/GFW.cpp -o GFW

echo "\tBF\t\tPAPE\t\tDIKH\t\tDIKD\t\tAFW\t\tGFW" >> results/results1.txt

for x in 10 100 1000
do
    for y in 10 50 100
    do
        for issym in 0 1
        do
            for seed in 1 10 100 1000
            do
                printf "%s %s %s %s\t" "$x" "$y" "$issym" "$seed" >> results/results.txt
                ./spweb input $x $y 1 1000 $issym $seed > input.sp
                echo "input.sp 1" > input.txt
                ./BF < input.txt >> results/results.txt
                ./PAPE < input.txt >> results/results.txt
                ./DIKH < input.txt >> results/results.txt
                ./DIKD < input.txt >> results/results.txt
                ./AFW < input.txt >> results/results.txt
                ./GFW < input.txt >> results/results.txt
                echo " " >> results/results.txt
            done
        done
    done
done


for x in 10 100 1000
do
    for y in 10 50 100
    do
        for issym in 0 1
        do
            for seed in 1 10 100 1000
            do
                printf "%s %s %s %s\t" "$x" "$y" "$issym" "$seed" >> results/results1.txt
                ./spweb input $x $y 1000 10000 $issym $seed > input.sp
                echo "input.sp 1" > input.txt
                ./BF < input.txt >> results/results1.txt
                ./PAPE < input.txt >> results/results1.txt
                ./DIKH < input.txt >> results/results1.txt
                ./DIKD < input.txt >> results/results1.txt
                ./AFW < input.txt >> results/results1.txt
                ./GFW < input.txt >> results/results1.txt
                echo " " >> results/results1.txt
            done
        done
    done
done
