#include <iostream>
#include <fstream>
#include <sstream>
#include <ctime>
#include <vector>
#include <algorithm>
#include <sys/types.h>
#include <climits>
using namespace std;

struct edge{
    int head;
    int tail;
    int length;
};

struct node{
    int head;
    int distance;
    node* next = NULL;
};

class Graph{
    int node_num, arc_num;
    edge *arcs;
    int *point;
    int *heap, *pred, *d;
    int last = 0;

    public:
    Graph(string filename){
        ifstream readfile(filename);
        string Text;
        int temp = 1, latest_tail = 0;

        // read file line by line
        while (getline (readfile, Text)) {
            // initialize dynamic allocated array
            if(Text[0] == 'p'){
                Text = Text.substr(6);
                istringstream is(Text);
                is >> node_num >> arc_num;
                arcs = new edge[arc_num + 1];
                point = new int[node_num + 1];
            }
            // store arc info
            else if(Text[0] == 'a'){
                Text = Text.substr(2);
                istringstream is(Text);
                is >> arcs[temp].tail >> arcs[temp].head >> arcs[temp].length;
                if(latest_tail != arcs[temp].tail){
                    point[arcs[temp].tail] = temp;
                    latest_tail = arcs[temp].tail;
                }
                else if (temp == arc_num){
                    point[node_num] = arc_num + 1;
                }
                temp++;
            }
        }
        readfile.close();
    }

    void printGraph(){
        for(int i = 1; i < arc_num + 1; i++){
            printf("edge %i (%i -> %i): %i\n", i, arcs[i].tail, arcs[i].head, arcs[i].length);
        }
        for(int i = 1; i < node_num + 1; i++){
            printf("point %i: %i\n", i, point[i]);
        }
    }
    
    void printd(int s){
        for(int i = 1; i < node_num + 1; i++){
            if(i == s){
                continue;
            }
            if(d[i] != INT_MAX){
                printf("%i->%i: [%i] ", s, i, d[i]);
                int temp = i;
                while(temp != s){
                    cout << temp << "<-";
                    temp = pred[temp];
                }
                cout << s << endl;
            }
            else{
                printf("%i->%i: [can not reach]\n", s, i);
            }
        }
    }

    void floyd_warshell_alg(){
        int** dist = new int*[node_num + 1];
        for(int i = 1; i < node_num + 1; i++){
            dist[i] = new int[node_num + 1];
        }
        for(int i = 1; i < node_num + 1; i++){
            for(int j = 1; j < node_num + 1; j++){
                if (i == j){
                    dist[i][j] = 0;
                }
                else{
                    dist[i][j] = INT_MAX;
                }
            }
        }      
        for(int i = 1; i < arc_num + 1; i++){
            cout << arcs[i].tail << '\t' << arcs[i].head << '\t' << arcs[i].length << endl;
            dist[arcs[i].tail][arcs[i].head] = arcs[i].length; 
        }
        for(int i = 1; i < node_num + 1; i++){
            cout << i << '\t';
            for(int j = 1; j < node_num + 1; j++){
                cout << dist[i][j] << '\t';
            }
            cout << endl;
        }
        int count = 0;
        for(int k = 1; k < node_num + 1; k++){
            for(int i = 1; i < node_num + 1; i++){
                for(int j = 1; j < node_num + 1; j++){
                    if(i != j && i != k && j != k){
                        ++count;
                        if(dist[i][j] > dist[i][k] + dist[k][j] && dist[i][k] + dist[k][j] >= 0){
                            cout << dist[i][j] << " > " << dist[i][k] << " + "<< dist[k][j] << endl;
                            dist[i][j] = dist[i][k] + dist[k][j];
                        }
                    }
                }
            }
        }
        cout << "num of triple: " << count << endl;
        for(int i = 1; i < node_num + 1; i++){
            cout << i << '\t';
            for(int j = 1; j < node_num + 1; j++){
                cout << dist[i][j] << '\t';
            }
            cout << endl;
        }        


        for(int i = 1; i < node_num + 1; i++){
            delete[] dist[i];
        }
        delete[] dist;
    }

    void floyd_warshell_gra(){
        node** dist = new node*[node_num + 1];
        vector<vector<int>> out, in;
        out.resize(node_num + 1);
        in.resize(node_num + 1);


        for(int i = 1; i < node_num + 1; i++){
            node* head = new node;
            head->distance = 0;
            head->head = i;
            dist[i] = head;
        }
        // for(int i = 1; i < node_num + 1; i++){
        //     for(int j = 0; j < 1; j++){
        //         cout << dist[i][j].distance;
        //     }
        //     cout << endl;
        // }
        for(int i = 1; i < arc_num + 1; i++){
            // cout << "tail, head " << arcs[i].tail << " " << arcs[i].head << endl;
            node* cur = new node;
            cur->distance = arcs[i].length;
            cur->head = arcs[i].head;
            out[arcs[i].tail].push_back(arcs[i].head); // 把從tail出去到head的head index存進out[tail]
            in[arcs[i].head].push_back(arcs[i].tail); // 把從tail出去到head的tail index存進in[head]
            
            if(dist[arcs[i].tail][0].next == NULL){
                dist[arcs[i].tail][0].next = cur;
            }
            else{
                node* temp = dist[arcs[i].tail];
                // cout << "list append " << arcs[i].tail << endl;
                while(temp->next != NULL){
                    temp = temp->next;
                }
                temp->next = cur;
            }
        }

        // updating
        long long count = 0;
        for(int k = 1; k < node_num + 1; k++){
            // cout << k << " out: " << out[k].size() << " in: " << in[k].size() << endl;
            for(int i = 0; i < in[k].size(); i++){
                for(int j = 0; j < out[k].size(); j++){                    
                    node* temp = dist[in[k][i]];
                        while(temp->head != k){
                            temp = temp->next;
                        }
                        int temp_dist = temp->distance;

                        temp = dist[k];
                        while(temp->head != out[k][j]){
                            temp = temp->next;
                        }
                        temp_dist += temp->distance;
                    
                    bool found = find(out[in[k][i]].begin(), out[in[k][i]].end(), out[k][j]) != out[in[k][i]].end();
                    if(found){
                        ++count;
                        temp = dist[in[k][i]];
                        while(temp->head != out[k][j]){
                            temp = temp->next;
                        }
                        if(temp->distance > temp_dist){
                            temp->distance = temp_dist;
                        }
                    }
                    else{
                        temp = dist[in[k][i]];
                        while(temp->next != NULL){
                            temp = temp->next;
                        }
                        node* new_node = new node;
                        new_node->distance = temp_dist;
                        new_node->head = out[k][j];
                        temp->next = new_node;

                        out[in[k][i]].push_back(out[k][j]); // 把從tail出去到head的head index存進out[tail]
                        in[out[k][j]].push_back(in[k][i]); // 把從tail出去到head的tail index存進in[head]
                    }
                }
            }
        }
        
        // for(int i = 1; i < node_num + 1; i++){
        //     cout << "i: " << i << endl;
        //     node* temp = dist[i];
        //     while(temp->next != NULL){
        //         cout << "head, distance: " << temp->head << " " << temp->distance << endl;
        //         temp = temp->next;
        //     }
        //     cout << "head, distance: " << temp->head << " " << temp->distance << endl;
        // }
        cout << count << endl;

        for(int i = 1; i < node_num + 1; i++){
            delete[] dist[i];
        }
        delete[] dist;
    }



    ~Graph(){
        delete[] arcs, point, heap, pred, d;
    }
};


int main(){
    string filename = "input.sp";
    // printf("Please input network filename: ");
    // cin >> filename;
    double t1 = clock();
    Graph g(filename);
    // g.printGraph();
    // g.floyd_warshell_alg();
    g.floyd_warshell_gra();
    double t2 = clock();
    cout <<  (t2 - t1)/double(CLOCKS_PER_SEC) << endl;
    

    return 0;
}