
> resultDIKB.txt

n_it=1

for file in inputs/*; do
  echo "Processing $file..."
  
  filename=$(basename "$file")
  extension="${filename##*.}"

  if [[ $extension == "txt" ]]; then
  
    echo "$filename" >> resultDIKB.txt

    ./DIKB $file $n_it >> resultDIKB.txt
    
    echo "" >> resultDIKB.txt
    
    
  else
    echo "Ignoring $file (unsupported file format)"
  fi
done

echo "All files processed."




