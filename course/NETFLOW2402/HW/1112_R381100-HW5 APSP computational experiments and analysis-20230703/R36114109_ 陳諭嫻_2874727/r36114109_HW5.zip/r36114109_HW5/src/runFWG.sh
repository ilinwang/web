
> resultFWG.txt

n_it=1

for file in inputs/*; do
  echo "Processing $file..."
  
  filename=$(basename "$file")
  extension="${filename##*.}"

  if [[ $extension == "txt" ]]; then
  
    echo "$filename" >> resultFWG.txt

    ./FWG $file $n_it >> resultFWG.txt
    
    echo "" >> resultFWG.txt
    
    
  else
    echo "Ignoring $file (unsupported file format)"
  fi
done

echo "All files processed."




