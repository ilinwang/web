/*
    This code can be compiled and run okay.

    This code is to read a network file and to let the users input the numbers of interations they want
    the Bellman-Ford FIFO implementation.
    You can get the total numbers of the triple comparison + total run time of this algorithm.

    usage:
        BF.cpp xxx n_it
        where xxx is the input network filename, e.g. input1.txt
        n_it is the iteration time


    compile:
        g++ BF.cpp -o BF

    pseudocode:
        struct Arc tail, head, length
        ----- readFile(filename) 
        ifstream ifs(filename)
        if (type == "p") 
            iss >> problemType >> n >> m
            forward_star.resize(n)
        else if (type == "a") 
            iss >> arc.tail >> arc.head >> arc.length
            arcs.push_back(arc)
        
        ----- build forward star
        for (int i = 0; i < arcs.size(); i++) 
            forward_star[arc.tail].push_back(arc)

        ----- printPath(source, node, predecessor)
        if (node == source) 
            cout << node
            return
        cout << node << "<-"
        printPath(source, predecessor[node], predecessor)

        -----BF()
        for (int source = 1; source < n; source++) 
            dist[source] = 0
            Queue.push(source)

            while (!Queue.empty()) 
                u = Queue.front()
                Queue.pop()
                inQueue[u] = false

            for (i = 0 ~ forward_star[u].size()) 
                const Arc& arc = forward_star[u][i]
                int v = arc.head
                double weight = arc.length

                if (dist[u] != INT_MAX && dist[u] + weight < dist[v]) 
                    dist[v] = dist[u] + weight
                    tripleComparisons[v]++
                    if (!inQueue[v]) 
                        Queue.push(v)
                        inQueue[v] = true

    coded by Yu-Shian Chen, ID: r36114109, email: yushian99@gmail.com
    date: 2023.05.16
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <string>
#include <sstream>
#include <climits>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <map>
#include <chrono>

using namespace std;

struct Arc {
    int tail, head;
    double length;
};

const int MAX = 10000;

vector<vector<Arc> > forward_star(MAX);
vector<int> dist(MAX, INT_MAX);
queue<int> Queue;
vector<Arc> arcs;

void bf(int n,int n_it) {
    int iterations = 0;
    vector<int> tripleComparisons(forward_star.size(), 0);

    for (int source = 1; source < n; source++) {
        vector<bool> inQueue(MAX, false);
        dist[source] = 0;
        Queue.push(source);
        inQueue[source] = true;
        
        while (iterations < n_it){
            while (!Queue.empty()) {
                int u = Queue.front();
                Queue.pop();
                inQueue[u] = false;

                for (int i = 0; i < forward_star[u].size(); i++) {
                    const Arc& arc = forward_star[u][i];
                    int v = arc.head;
                    double weight = arc.length;

                    if (dist[u] != INT_MAX && dist[u] + weight < dist[v]) {
                        dist[v] = dist[u] + weight;
                        tripleComparisons[v]++;
                        if (!inQueue[v]) {
                            Queue.push(v);
                            inQueue[v] = true;
                        }
                    }
                }
            }
            iterations ++;
        }
    }
    cout << "Total nontrivial triple comparisons: " << accumulate(tripleComparisons.begin(), tripleComparisons.end(), 0) << endl;
}


int readFile(const string& filename) {
    ifstream ifs(filename);
    // while (ifs.fail()) {
        // cout << "Input file failed\n";
        // cout << "Please input network filename: ";
        // string input;
        // cin.ignore(numeric_limits<streamsize>::max(), '\n');  // Clear input buffer
    //     getline(cin, input);
    //     ifs.open(input);
    // }

    string line;
    int n = 0, m = 0;

    while (getline(ifs, line)) {
        istringstream iss(line);
        string type;
        iss >> type;

        if (type == "p") {
            string problemType;
            iss >> problemType >> n >> m;
            forward_star.resize(n + 1);  
        } else if (type == "a") {
            Arc arc;
            iss >> arc.tail >> arc.head >> arc.length;
            arcs.push_back(arc);
        }
    }

    for (int i = 0; i < arcs.size(); i++) {
        const Arc& arc = arcs[i];
        forward_star[arc.tail].push_back(arc);
    }
    return n;
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        // cout << "Usage: ./BF <filename> <n_it>" << endl;
        return 1;
    }
    string filename = argv[1];
    // cout << "Please input network filename: ";
    // cin >> filename;

    int n_it = stoi(argv[2]);

    int n = readFile(filename);

    // int n_it;
    // cout << "Please input the number of iterations: ";
    // cin >> n_it;

    auto start = chrono::high_resolution_clock::now();

    bf(n, n_it);

    auto end = chrono::high_resolution_clock::now();

    chrono::duration<double> runtime = end - start;

    cout << "Total time: " << runtime.count() << " seconds\n";


    return 0;
}
