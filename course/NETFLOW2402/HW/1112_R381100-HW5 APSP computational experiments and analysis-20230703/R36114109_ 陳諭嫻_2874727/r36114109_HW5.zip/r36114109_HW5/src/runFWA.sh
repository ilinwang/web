
> resultFWA.txt

n_it=1

for file in inputs/*; do
  echo "Processing $file..."
  
  filename=$(basename "$file")
  extension="${filename##*.}"

  if [[ $extension == "txt" ]]; then
  
    echo "$filename" >> resultFWA.txt

    ./FWA $file $n_it >> resultFWA.txt
    
    echo "" >> resultFWA.txt
    
    
  else
    echo "Ignoring $file (unsupported file format)"
  fi
done

echo "All files processed."




