
> resultBF.txt
> resultBFP.txt
> resultDIKH.txt

n_it=10

for file in inputs/*; do
  echo "Processing $file..."
  
  filename=$(basename "$file")
  extension="${filename##*.}"

  if [[ $extension == "txt" ]]; then
  
    echo "$filename" >> resultBF.txt

    ./BF $file $n_it >> resultBF.txt
    
    echo "" >> resultBF.txt
    
    echo "$filename" >> resultBFP.txt

    ./BFP $file $n_it >> resultBFP.txt
    
    echo "" >> resultBFP.txt
    
    echo "$filename" >> resultDIKH.txt

    ./DIKH $file $n_it >> resultDIKH.txt
    
    echo "" >> resultDIKH.txt
    
  else
    echo "Ignoring $file (unsupported file format)"
  fi
done

echo "All files processed."




