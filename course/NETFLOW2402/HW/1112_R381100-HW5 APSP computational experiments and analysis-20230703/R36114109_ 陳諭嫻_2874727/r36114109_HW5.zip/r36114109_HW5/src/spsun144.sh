

mkdir -p inputs

n_values=(50 100 200 400 800 1600)
l_values=(1 4)
c_values=("1 1000" "1000 10000")
issym_values=(0 1)
seed_values=(2 20 200 2000)

for n in "${n_values[@]}"; do
    for l in "${l_values[@]}"; do
        for c_range in "${c_values[@]}"; do
            IFS=', ' read -r cmin cmax <<< "$c_range"
            for issym in "${issym_values[@]}"; do
                for seed in "${seed_values[@]}"; do
                    output_file="graph_${n}_${l}_${cmin}_${cmax}_${issym}_${seed}.txt"
                    ./spsun name $n $l $cmin $cmax $issym $seed > "inputs/$output_file"
                done
            done
        done
    done
done
