/*
    This code can be compiled and run okay.

    This code is to read a network file and to let the users input the nodes they want to do 
    the Floyd-Warshall algebraic implementation.

    usage:
        FWA.cpp xxx n_it
        where xxx is the input network filename, e.g. test1.sp
        n_it is the iteration time

    input file:
        test1.sp
        test2.sp

    compile:
        g++ FWA.cpp -o FWA

    pseudocode:
        struct Arc tail, head, length
        ----- readFile(filename) 
        ifstream ifs(filename)
        if (type == "p") 
            iss >> problemType >> n >> m
            forward_star.resize(n)
        else if (type == "a") 
            iss >> arc.tail >> arc.head >> arc.length
            arcs.push_back(arc)
        
        ----- build forward star
        for (int i = 0; i < arcs.size(); i++) 
            forward_star[arc.tail].push_back(arc)

        ----- printPath(source, node, predecessor)
        if (node == source) 
            cout << node
            return
        cout << node << "<-"
        printPath(source, predecessor[node], predecessor)

        ----- FWA()
        for (int k = 1; k <= n; k++) 
            for (int i = 1; i <= n; i++) 
                for (int j = 1; j <= n; j++) 
                    if (dist[i][k] != INF && dist[k][j] != INF && dist[i][j] > dist[i][k] + dist[k][j]) 
                        dist[i][j] = dist[i][k] + dist[k][j]
                        tripleComparisons[i][j]++;


    coded by Yu-Shian Chen, ID: r36114109, email: yushian99@gmail.com
    date: 2023.06.01
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <limits>
#include <cmath>
#include <algorithm>
#include <numeric>

using namespace std;

const int MAX = 10000;
const double INF = numeric_limits<double>::infinity();

vector<vector<double> > dist(MAX, vector<double>(MAX, INF));

void floydWarshall(int n, int n_it) {

    int iterations = 0;
    vector<vector<int> > tripleComparisons(n + 1, vector<int>(n + 1, 0));
    
    while (iterations < n_it){
        for (int k = 1; k <= n; k++) {
            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= n; j++) {
                    if (dist[i][k] != INF && dist[k][j] != INF && dist[i][j] > dist[i][k] + dist[k][j]) {
                        dist[i][j] = dist[i][k] + dist[k][j];
                        tripleComparisons[i][j]++;
                    }
                }
            }
        }
        iterations ++;
    }
    
    int total = 0;
    for (int i = 1; i < n; i++) {
        for (int j = 1; j < n; j++) {
            total += tripleComparisons[i][j];
        }
    }
    std::cout << "Total nontrivial triple comparisons: " << total << std::endl;
}

void readFile(const string& filename) {
    ifstream ifs(filename);
    // while (ifs.fail()) {
        // cout << "Input file failed\n";
        // cout << "Please input network filename: ";
        // string input;
        // cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear input buffer
    //     getline(cin, input);
    //     ifs.open(input);
    // }

    string line;
    int n = 0, m = 0;

    while (getline(ifs, line)) {
        istringstream iss(line);
        string type;
        iss >> type;

        if (type == "p") {
            string problemType;
            iss >> problemType >> n >> m;
            dist.resize(n + 1, vector<double>(n + 1, INF));
            for (int i = 1; i <= n; i++) {
                dist[i][i] = 0; 
            }
        } else if (type == "a") {
            int tail, head;
            double length;
            iss >> tail >> head >> length;
            
            dist[tail][head] = min(dist[tail][head], max(length, 1.0));
        }
    }
}

int main(int argc, char* argv[]) {
    // string filename;
    // cout << "Please input network filename: ";
    // cin >> filename;


    if (argc < 3) {
        return 1;
    }
    // cout << "Please input network filename: ";
    string filename = argv[1];
    // cin >> filename;

    int n_it = stoi(argv[2]);

    readFile(filename);

    int n = dist.size() - 1;

    auto start_time = chrono::high_resolution_clock::now();

    floydWarshall(n, n_it);

    auto end_time = chrono::high_resolution_clock::now();

    chrono::duration<double> elapsed_time = end_time - start_time;

    cout << "Total time: " << elapsed_time.count() << " seconds\n";

    // int source_node;
    // cout << "Please input a source node: ";
    // cin >> source_node;


    return 0;
}
