#include <fstream>
#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <ctime>
#include <queue>

// Settings
using namespace std;
string user_filename ;
int user_source_node = 0;
int user_sink_node = 0;
string line; //readFile line by line
string title_of_problem_name;
string problem_type;
char row_label;
int num_nodes =0; //amount of nodes
int num_arcs =0; //amount of arcs
int **graph; //data_structure
int arc_index_count;
int point_index_count;
int *point; // node in graph
long long M = 999999999999999999;
long long **graph_matrix;
int **path;
long long trivial_triple_comparisons;
long long nontrivial_triple_comparisons;
priority_queue<vector<int>, vector<vector<int>>, greater<vector<int>> > pq;
vector<int> temp_pq;


clock_t my_timer;
std::ofstream ofs;
long long *d; //distance label
int *pred; //predecessor
fstream myFile;
void readFile();
void floyd_warshall();
void printgraph_matrix();


int main() {

    while(user_filename != "-1"){
        cout << "Please input network filename (or -1 to exit) : " ;
        cin >> user_filename ;
        myFile.open(user_filename);
        while(!myFile.is_open() && user_filename != "-1"){
            cout <<"failed. wrong filename."<<endl;
            cout << "Please input network filename (or -1 to exit) : " ;
            cin >> user_filename ;
            myFile.open(user_filename);
        }
        if(myFile.is_open()){
        	cout << "opened"<<endl;
        	readFile();
        	long long sum_d = 0;
        	int test_times = 30;
        	d = new long long[num_nodes];
            my_timer = clock();
            for (int i = 0; i < test_times; i++){	
	            floyd_warshall();
				//printgraph_matrix();
			}
			float process_time = float(clock() - my_timer)/test_times;
			for (int i = 0 ; i<num_nodes ; i++){
				for (int j = 0 ; j<num_nodes ; j++){
					if(graph_matrix[i][j] != M){
						sum_d += graph_matrix[i][j];
					}
	            }		
			}
            cout<<"Sum of distances: " << sum_d<<endl;
            cout<<"Running time of SP computation: " << process_time << " (ms)" <<endl;
            cout<<"trivial_triple_comparisons: " << trivial_triple_comparisons<<endl;
            cout<<"nontrivial_triple_comparisons: " << nontrivial_triple_comparisons<<endl;
            ofs.open("spc_fwg_output.txt",ios::app);
       		if (!ofs.is_open()) {
        		cout << "Failed to open file.\n";
        	return 1; // EXIT_FAILURE
    		}
    		ofs <<user_filename<<"     "<<sum_d <<"     "<<process_time<<"     "<<trivial_triple_comparisons<<"     "<<nontrivial_triple_comparisons<< "\n";
    		ofs.close();
		}
    }
    cout <<"exit"<< endl;
    return 0;
}

void readFile(){

    // Open file

    // Record file content
    //point[node]
    //graph[node][j] j=0 tail  j=1 head  j=2 length
    while (myFile.get(row_label)) {
        if(row_label == 'c'){
            getline(myFile, line);
        }
        else if (row_label == 't'){
            myFile >> title_of_problem_name;

        }
        else if(row_label == 'p'){
            //myFile << "\t" << 10;
            myFile>>problem_type >> num_nodes >> num_arcs;
            //initialize point & graph size
            point = new int[num_nodes+1];
            graph = new int*[num_arcs];
            arc_index_count = 0;
            point_index_count = 0;
            temp_pq.resize(3);

        }
        else if(row_label == 'n'){
            //myFile << "\t" << 10;
            getline(myFile, line);
            //myFile << "\t" << 10;
        }
        else if(row_label == 'a'){
            myFile >> temp_pq[0] >> temp_pq[1] >> temp_pq[2];
            pq.push(temp_pq);
        }
    }
    while (!pq.empty()){
        //set array_point & array_graph
        graph[arc_index_count] = new int[3];
        auto now = pq.top();
        pq.pop();
        //cout << now[0] << " " << now[1] << " "<< now[2] << endl;
        graph[arc_index_count][0] = now[0];
        graph[arc_index_count][1] = now[1];
        graph[arc_index_count][2] = now[2];
        for(int i = point_index_count; i<graph[arc_index_count][0]; i++){
            point[i] = arc_index_count;
        }
        point_index_count = graph[arc_index_count][0];
        arc_index_count++;
    }


    //forward star
    for(int i = graph[num_arcs-1][0]; i <= num_nodes;i++){
        point[i] = num_arcs;
    }

    //Close file
    myFile.close();
    return;
}

void floyd_warshall(){
    //Initialize
    graph_matrix = new long long*[num_nodes];
    path = new int*[num_nodes];
    trivial_triple_comparisons = 0;
	nontrivial_triple_comparisons = 0;
    for(int i = 0; i< num_nodes; i++){
    	graph_matrix[i] = new long long[num_nodes];
    	path[i] = new int[num_nodes];
    	for(int j = 0; j< num_nodes; j++){
    		path[i][j] = i;
    		if(i == j){
    			graph_matrix[i][j] = 0;
			}else{
				graph_matrix[i][j] = M;
			}
		}  			
	}
	for(int r=0; r<num_arcs; r++){
		graph_matrix[graph[r][0]-1][graph[r][1]-1] = graph[r][2];
	} 
	for (int k=0; k<num_nodes; k++){
		for (int i=0; i<num_nodes; i++){
			for (int j=0; j<num_nodes; j++){
				if (i == j || i == k ||k == j){
					
				}else if(graph_matrix[i][k] == M || graph_matrix[k][j] == M){
					nontrivial_triple_comparisons += 1;
				}else{
					trivial_triple_comparisons += 1;
					if (graph_matrix[i][k] + graph_matrix[k][j] < graph_matrix[i][j]){
						graph_matrix[i][j] = graph_matrix[i][k] + graph_matrix[k][j];
						path[i][j] = path[k][j];
					}
				}
			}
		}
	}
    return;
}


void printgraph_matrix(){
	cout<<endl;
    cout<<"Here is the output:"<<endl;
    cout<<endl;
    for(int i=0; i<num_nodes; i++)
    {
        for(int j=0; j<num_nodes; j++)
        {
            //cout<<adj_matrix[i][j]<<"  ";
            printf("%3d  ", graph_matrix[i][j]);
        }
        cout<<endl;
    }
    return;
}


