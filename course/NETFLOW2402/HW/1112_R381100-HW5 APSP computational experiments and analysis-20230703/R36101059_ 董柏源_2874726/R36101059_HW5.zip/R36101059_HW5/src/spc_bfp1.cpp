#include <fstream>
#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <ctime>
#include <queue>

// Settings
using namespace std;
string user_filename ;
int user_source_node = 0;
int user_sink_node = 0;
string line; //readFile line by line
string title_of_problem_name;
string problem_type;
char row_label;
int num_nodes =0; //amount of nodes
int num_arcs =0; //amount of arcs
int **graph; //data_structure
int arc_index_count;
int point_index_count;
int *point; // node in graph
long long M = 999999999999999999;
long long trivial_triple_comparisons;
long long nontrivial_triple_comparisons;
long long triple_comparisons;
long long total_triple_comparisons;
priority_queue<vector<int>, vector<vector<int>>, greater<vector<int>> > pq;
vector<int> temp_pq;

list<int> LIST; //BF_FIFO
clock_t my_timer;
std::ofstream ofs;
long long *d; //distance label
long long *one_to_all_distance;
long long *pred; //predecessor

fstream myFile;
void readFile();
void BF_PAPE();





int main() {

    while(user_filename != "-1"){
        cout << "Please input network filename (or -1 to exit) : " ;
        cin >> user_filename ;
        myFile.open(user_filename);
        while(!myFile.is_open() && user_filename != "-1"){
            cout <<"failed. wrong filename."<<endl;
            cout << "Please input network filename (or -1 to exit) : " ;
            cin >> user_filename ;
            myFile.open(user_filename);
        }
        if(myFile.is_open()){

            cout << "opened"<<endl;
            readFile();
            int test_times = 30;
            long long sum_d = 0;
            one_to_all_distance = new long long[num_nodes];
            my_timer = clock();
            for (int i = 0; i < test_times; i++){
            	trivial_triple_comparisons = 0;
				nontrivial_triple_comparisons = 0;
            	for (int j = 1; j <= num_nodes; j++){
            		one_to_all_distance[j-1] = 0;
            		user_source_node = j;
                	BF_PAPE(); //execute algorithm
            		for (int k = 0 ; k<num_nodes ; k++){
                		if(d[k] != M)
                		one_to_all_distance[j-1] += d[k];
            		}
				}
        	}
            float process_time = float(clock() - my_timer)/test_times;
        	for (int i = 0 ; i<num_nodes ; i++){
        		sum_d += one_to_all_distance[i];
			}
			triple_comparisons = (num_nodes) * (num_nodes - 1);
			total_triple_comparisons = triple_comparisons * (num_nodes - 2);
			nontrivial_triple_comparisons = total_triple_comparisons - trivial_triple_comparisons;
        	cout<<"Sum of distances: " << sum_d<<endl;
            cout<<"Running time of SP computation: " << process_time << " (ms)" <<endl;
            cout<<"trivial_triple_comparisons: " << trivial_triple_comparisons<<endl;
            cout<<"nontrivial_triple_comparisons: " << nontrivial_triple_comparisons<<endl;
            ofs.open("spc_bfp_output.txt",ios::app);
       		if (!ofs.is_open()) {
        		cout << "Failed to open file.\n";
        	return 1; // EXIT_FAILURE
    		}
    		ofs <<user_filename<<"     "<<sum_d <<"     "<<process_time<<"     "<<trivial_triple_comparisons<<"     "<<nontrivial_triple_comparisons<< "\n";
    		ofs.close();  
        }
    }
    cout <<"exit"<< endl;
    return 0;
}

void readFile(){

    // Open file

    // Record file content
    //point[node]
    //graph[node][j] j=0 tail  j=1 head  j=2 length
    while (myFile.get(row_label)) {
        if(row_label == 'c'){
            getline(myFile, line);
        }
        else if(row_label == 'p'){
            myFile>>problem_type >> num_nodes >> num_arcs;
            //initialize point & graph size
            point = new int[num_nodes+1];
            graph = new int*[num_arcs];
            arc_index_count = 0;
            point_index_count = 0;
            temp_pq.resize(3);
        }
        else if(row_label == 'n'){
            getline(myFile, line);
        }
        else if(row_label == 'a'){
            myFile >> temp_pq[0] >> temp_pq[1] >> temp_pq[2];
            pq.push(temp_pq);
        }
    }
    while (!pq.empty()){
        //set array_point & array_graph
        graph[arc_index_count] = new int[3];
        auto now = pq.top();
        pq.pop();
        //cout << now[0] << " " << now[1] << " "<< now[2] << endl;
        graph[arc_index_count][0] = now[0];
        graph[arc_index_count][1] = now[1];
        graph[arc_index_count][2] = now[2];
        for(int i = point_index_count; i<graph[arc_index_count][0]; i++){
            point[i] = arc_index_count;
        }
        point_index_count = graph[arc_index_count][0];
        arc_index_count++;
    }


    //forward star
    for(int i = graph[num_arcs-1][0]; i <= num_nodes;i++){
        point[i] = num_arcs;
    }

    //Close file
    myFile.close();
    return;
}



void BF_PAPE(){
    //Initialize
    d = new long long[num_nodes];
    pred = new long long[num_nodes];
    LIST.clear();
    for(int i= 0 ; i<num_nodes ;i++){
        d[i] = M;       //d[node_index] = length
        pred[i] = 0;    //pred[node_index] = node_number
    }
    d[user_source_node-1] = 0;
    LIST.push_back(user_source_node);
    int delete_node = 0;

    while(!LIST.empty()){
        delete_node = LIST.front();
        LIST.pop_front();
        for (int i = point[delete_node-1]; i<point[delete_node]; i++){
        	trivial_triple_comparisons += 1;
            if(d[graph[i][1]-1] > d[delete_node-1] + graph[i][2]){
                if(d[graph[i][1]-1] == M)
                    LIST.push_back(graph[i][1]);
                else
                    LIST.push_front(graph[i][1]);
                d[graph[i][1]-1] = d[delete_node-1] + graph[i][2];
                pred[graph[i][1]-1] = delete_node;
            }
        }
    }

    return;
}


