extern "C"{
#include "timer.c"
}
#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <climits>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <cstring>

using namespace std;

struct Edge {
    int source;
    int destination;
    int weight;
};

class Graph {
    int V; // 頂點數量
    int E; // 邊數量
    vector<Edge> edges; // 邊

public:
    // int total = 0;
    Graph(int V, int E) {
        this->V = V;
        this->E = E;
    }

    // 新增邊
    void addEdge(int u, int v, int w) {
        edges.push_back({u, v, w});
    }

    // PAPE演算法
    void pape(int start) {
        // 初始化距離
        vector<int> dist(V, INT_MAX);
        dist[start] = 0;

        // 使用 Prioirty Queue 來實現
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
        pq.push(make_pair(0, start));


        // 避免重複處理節點
        vector<bool> processed(V, false);

        while (!pq.empty()) {
            // 取出最小距離節點
            int u = pq.top().second;
            pq.pop();

            if (processed[u]) continue;
            processed[u] = true;

            for (auto edge : edges) {
                int v = edge.destination;
                int w = edge.weight;
                if (edge.source == u && dist[u] != INT_MAX && dist[v] > dist[u] + w) {
                    dist[v] = dist[u] + w;
                    pq.push(make_pair(dist[v], v));
                }
            }
        }

        // 檢查是否有負權回路
        for (auto edge : edges) {
            int u = edge.source;
            int v = edge.destination;
            int w = edge.weight;
            if (dist[u] != INT_MAX && dist[u] + w < dist[v]) {
                cout << "Graph contains negative weight cycle" << endl;
                return;
            }
        }

        // 輸出最短路徑
        // cout << "Vertex\tDistance from source" << endl;
        int sum=0;
        for (int i = 1; i < V; i++) {
            if(dist[i]==INT_MAX){
                // cout<<"can't reach"<< endl;
            }else{
                // cout<< dist[i] << endl;
                // sum+=dist[i];
            }
        }
        // cout<<"total: "<<sum<<endl;
        // total += sum;
    }
};

vector<string> split( string line, char x, char tab){
    vector<string> result;
    string tmp = "";

    for(int i=0; i<line.length(); i++){
        if(line[i] == x | line[i]==tab){
            if(tmp!=""){
                result.push_back(tmp);
                tmp = "";
            }
            
        }else{
            tmp += line[i];
            if (i+1 == line.length()){
                result.push_back(tmp);
            }
            
        }
    }
    return result;
}

int main(int argc , char *argv[]) {
    int n ,m;
    vector<string> tmp;
    ifstream myFile;
    string filename= argv[1];

    myFile.open(filename);
    string line;
    while (getline(myFile, line)) {
        if(line[0]=='p'){
            tmp = split(line,' ', '\t');
            n = stoi(tmp[2]);
            m = stoi(tmp[3]);
            break;
        }
    }
    myFile.close();
    Graph g(n+1, m+1);

    myFile.open(filename);
    
    while (getline(myFile, line)) {
        if(line[0]=='a'){
            tmp = split(line,' ', '\t');
            g.addEdge(stoi(tmp[1]), stoi(tmp[2]), stoi(tmp[3]));
        }
    }
    
    myFile.close();
    
    

    double time = 0;

    time = timer();

    for(int s=1; s<=n; s++){
        g.pape(s);
    }

    
    time = timer() - time;

    // cout<<"PAPE : Total: " << g.total;
    cout<<filename<<"," << time <<endl;


    return 0;
}