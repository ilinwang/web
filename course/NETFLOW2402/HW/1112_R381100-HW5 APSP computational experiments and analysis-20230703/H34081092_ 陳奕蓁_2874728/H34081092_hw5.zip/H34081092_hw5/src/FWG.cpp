extern "C"{
#include "timer.c"
}
#include <fstream>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <string>
#include <stdlib.h>
#include <climits>
using namespace std;

int ** graph;
int n ,m;

int bigM = 123456;
// int total = 0;

void printSolution(int ** dist) {
    // cout << "result：" << endl;
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            if(i != j){
                if (dist[i][j] == bigM) {
                    // cout << "INF\t";
                } else {
                    // cout << dist[i][j] << "\t";
                    // sum += dist[i][j];
                }
            }
        }
        // cout << endl;
    }
    // total += sum;
}


void floydWarshall(int ** graph) {
    // 對所有節點對進行比較，以查找更短的路徑
    for (int k = 1; k <= n; k++) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                // 如果存在更短的路徑，則更新距離矩陣
                if (graph[i][k] != bigM && graph[k][j] != bigM && graph[i][k] + graph[k][j] < graph[i][j]) {
                    graph[i][j] = graph[i][k] + graph[k][j];
                }
            }
        }
    }

    printSolution(graph);
}


vector<string> split( string line, char x, char tab){
    vector<string> result;
    string tmp = "";

    for(int i=0; i<line.length(); i++){
        if(line[i] == x | line[i]==tab){
            if(tmp!=""){
                result.push_back(tmp);
                tmp = "";
            }
            
        }else{
            tmp += line[i];
            if (i+1 == line.length()){
                result.push_back(tmp);
            }
            
        }
    }
    return result;
}



int main(int argc , char *argv[]) {

    string name, type;
    vector<string> tmp;
    ifstream myFile;
    string filename= argv[1];
    

    myFile.open(filename);
    string line;

    while (getline(myFile, line)) {
        if (line[0]=='t'){
            tmp = split(line,' ','\t');
            name = tmp[1];
        }
        else if(line[0]=='p'){
            tmp = split(line,' ', '\t');
            type = tmp[1];
            n = stoi(tmp[2]);
            m = stoi(tmp[3]);

            graph = new int * [n+1];
            for(int i=1; i<=n;i++){
                graph[i] = new int [n+1];
                for(int j=1; j<=n; j++){
                    graph[i][j] = bigM;
                }
            }

        }else if(line[0]=='a'){
            tmp = split(line,' ', '\t');
            int i = stoi(tmp[1]);
            int j = stoi(tmp[2]);
            graph[i][j] = stoi(tmp[3]);
        }
    }

    // Close file
    myFile.close();

    double time = timer();

    floydWarshall(graph);

    time = timer() - time;

    cout<<filename<<","<< time <<endl;
    
    return 0;
}
