#!/bin/bash

# x_values=(10 100 1000)
# y_values=(10 50 100)
# cmin_values=(1 1000)
# cmax_values=(1000 10000)
# issym_values=(0 1)
# seed_values=(2 20 200 1000)
# num=1

x_values=(10)
y_values=(10 50)
cmin_values=(1)
cmax_values=(1000)
issym_values=(0 1)
seed_values=(2 20)
num=0

for x in "${x_values[@]}"
do
    for y in "${y_values[@]}"
    do
        for (( i=0; i<=num; i++ ))
        do
            cmin=${cmin_values[$i]}
            cmax=${cmax_values[$i]}

            for issym in "${issym_values[@]}"
            do
                for seed in "${seed_values[@]}"
                do
                    ./bin/Dial ./inputs/data$x,$y,$cmin,$cmax,$issym,$seed >> output.csv
                done
            done
        done
    done
done

for x in "${x_values[@]}"
do
    for y in "${y_values[@]}"
    do
        for (( i=0; i<=num; i++ ))
        do
            cmin=${cmin_values[$i]}
            cmax=${cmax_values[$i]}

            for issym in "${issym_values[@]}"
            do
                for seed in "${seed_values[@]}"
                do
                    ./bin/Heap ./inputs/data$x,$y,$cmin,$cmax,$issym,$seed >> output.csv
                done
            done
        done
    done
done

for x in "${x_values[@]}"
do
    for y in "${y_values[@]}"
    do
        for (( i=0; i<=num; i++ ))
        do
            cmin=${cmin_values[$i]}
            cmax=${cmax_values[$i]}

            for issym in "${issym_values[@]}"
            do
                for seed in "${seed_values[@]}"
                do
                    ./bin/BF ./inputs/data$x,$y,$cmin,$cmax,$issym,$seed >> output.csv
                done
            done
        done
    done
done

for x in "${x_values[@]}"
do
    for y in "${y_values[@]}"
    do
        for (( i=0; i<=num; i++ ))
        do
            cmin=${cmin_values[$i]}
            cmax=${cmax_values[$i]}

            for issym in "${issym_values[@]}"
            do
                for seed in "${seed_values[@]}"
                do
                    ./bin/PAPE ./inputs/data$x,$y,$cmin,$cmax,$issym,$seed >> output.csv
                done
            done
        done
    done
done

for x in "${x_values[@]}"
do
    for y in "${y_values[@]}"
    do
        for (( i=0; i<=num; i++ ))
        do
            cmin=${cmin_values[$i]}
            cmax=${cmax_values[$i]}

            for issym in "${issym_values[@]}"
            do
                for seed in "${seed_values[@]}"
                do
                    ./bin/FWG ./inputs/data$x,$y,$cmin,$cmax,$issym,$seed >> output.csv
                done
            done
        done
    done
done


for x in "${x_values[@]}"
do
    for y in "${y_values[@]}"
    do
        for (( i=0; i<=num; i++ ))
        do
            cmin=${cmin_values[$i]}
            cmax=${cmax_values[$i]}

            for issym in "${issym_values[@]}"
            do
                for seed in "${seed_values[@]}"
                do
                    ./bin/FWA ./inputs/data$x,$y,$cmin,$cmax,$issym,$seed >> output.csv
                done
            done
        done
    done
done