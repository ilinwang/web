#!/bin/bash

x_values=(10 100 1000)
y_values=(10 50 100)
cmin_values=(1 1000)
cmax_values=(1000 10000)
issym_values=(0 1)
seed_values=(2 20 200 1000)
num=1

# 嵌套的 for 迴圈執行所有組合
for x in "${x_values[@]}"
do
    for y in "${y_values[@]}"
    do
        for (( i=0; i<=num; i++ ))
        do
            cmin=${cmin_values[$i]}
            cmax=${cmax_values[$i]}

            # echo $cmin

            for issym in "${issym_values[@]}"
            do
                for seed in "${seed_values[@]}"
                do
                    # 執行命令
                    ./bin/spweb name $x $y $cmin $cmax $issym $seed > ./inputs/data$x,$y,$cmin,$cmax,$issym,$seed
                done
            done
        done
    done
done