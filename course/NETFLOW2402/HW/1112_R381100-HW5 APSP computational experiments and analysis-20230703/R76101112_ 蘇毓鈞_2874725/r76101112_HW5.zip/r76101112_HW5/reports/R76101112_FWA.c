/*
	This program is the Floyd-Warshall algebraic ALL-ALL shortest path algorithm implementation .Output is the nontrivial triple comparison.
	compile:
		gcc -o R76101112_FWA R76101112_FWA.c
	run:
		./R76101112_FWA
		
	This code can be compiled and run ok on Ubuntu.
	coded by SU YU CHUN, ID: R76101112, email: R76101112@gs.ncku.edu.tw
	date: 2023/5/22
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/times.h>
float mytimer();
#define Infinite 1073741823
struct Node{
	int data;
	struct Node *next;
};
int first=1;
typedef struct Node QueueNode;
typedef QueueNode *QueueByLinkedList;
QueueByLinkedList front=NULL;
QueueByLinkedList rear=NULL;
void enqueue(int value){
	QueueByLinkedList node;
	node=(QueueByLinkedList)malloc(sizeof(QueueNode));
	node->data=value;
	node->next=NULL;
	if(rear==NULL)
		front=node;
	else
		rear->next=node;
	rear=node;
}
int dequeue(int action){
	int value;
	QueueByLinkedList tempNode,startNode;
	if(!(front==NULL) && action==1){
		if(front==rear)
			rear=NULL;
		value=front->data;
		front=front->next;
		return value;
	}else if(!(rear==NULL) && action==2){
		startNode=front;
		value=rear->data;
		tempNode=front;
		while(front->next!=rear && front->next!=NULL){
			front=front->next;
			tempNode=front;
		}
		front=startNode;
		rear=tempNode;
		if((front->next==NULL) || (rear->next==NULL)){
			front=NULL;
			rear=NULL;
		}
		return value;
	}
	else	return -1;
	
	if((front->next==NULL) || (rear->next==NULL)){
		front=NULL;
		rear=NULL;
	}
	return value;
}

int main(){
	FILE *fp;
	char s[1024],fileName[1024],problemName[1024],a,b,c;
	double **ptr=NULL;
	int nontrivalTripleComparison=0;
	int **A=NULL,*changed,**D,weight;
	int i,j,w,n,node,count,arc,u,t,sum=0;
	char k;
	float t1=0.,t2=0.;
	printf("Please input network filename:");
	scanf("%s",fileName);
	if((fp=fopen(fileName,"r"))==NULL) {
		printf("Open file error!!\n");
		system("pause");
		exit(0);
	}
	/*while(!feof(fp)) {
		fgets(s,1024,fp);
		
		if(s[0]=='n') {
			node=s[2]-48;
		
			ptr=(double **)malloc(sizeof(double *)*node);
			A=(int **)malloc(sizeof(int *)*node);
			for(i=0;i<node;i++) {
				ptr[i] = (double *)malloc(sizeof(double)*node);
				A[i]=(int *)malloc(sizeof(int)*node);
			}
			for(i=0;i<node;i++){
				for(j=0;j<node;j++){
					ptr[i][j]=0.0;
					A[i][j]=Infinite;
				}
			}  
			
			changed=(int *)malloc(sizeof(int)*node);
			D=(int *)malloc(sizeof(int)*node);
			break;
		}
		if(s[0]=='a') {
			
		}
		if(s[0]=='p'){
			arc=(s[8]-48);
		}
		if(s[0]=='t'){
			j=0;
			for(i=2;s[i]!='\n';i++){
				problemName[j]=s[i];
				j++;
			}
			
		}
		for(i=0;i<node;i++){
				for(j=0;j<node;j++){
					if(ptr[i][j]!=0.0)
					  A[i][j]=(int)ptr[i][j];
				}
		}
	}*/
	i=0;
	while(!feof(fp)){
		fgets(s,1024,fp);
		if(i<6)	i++;
		else	break;
			
	}
	fscanf(fp,"%c %c%c %d %d",&a,&b,&c,&node,&j);
	ptr=(double **)malloc(sizeof(double *)*node);
			A=(int **)malloc(sizeof(int *)*node);
			D=(int **)malloc(sizeof(int *)*node);
			for(i=0;i<node;i++) {
				ptr[i] = (double *)malloc(sizeof(double)*node);
				A[i]=(int *)malloc(sizeof(int)*node);
				D[i]=(int *)malloc(sizeof(int)*node);
			}
			for(i=0;i<node;i++){
				for(j=0;j<node;j++){
					ptr[i][j]=0.0;
					A[i][j]=Infinite;
				}
			}  
			
			changed=(int *)malloc(sizeof(int)*node);
			
			for(i=0;i<node;i++){
				for(j=0;j<node;j++){
					if(ptr[i][j]!=0.0)
					  A[i][j]=(int)ptr[i][j];
				}
		}
	i=0;
	while(!feof(fp)){
		fgets(s,1024,fp);
		if(i<3)	i++;
		else	break;
			
	}
	for(i=0;i<node;i++){
				
				changed[i]=Infinite;
	}
	
	while(fscanf(fp,"%c	%d	%d	%d",&k,&i,&j,&weight)!=EOF){
		A[i-1][j-1]=weight;
	}
	for(i=0;i<node;i++){
		for(j=0;j<node;j++){
			D[i][j]=A[i][j];
		}
		D[i][i]=0;
	}
	//first=0;
	t1=mytimer();
	for(w=0;w<node;w++){
		for(i=0;i<node;i++){
			for(j=0;j<node;j++){
				if(D[i][w]!=Infinite&& D[w][j]!=Infinite){
					nontrivalTripleComparison++;
					if((D[i][w]+D[w][j])<D[i][j]){
					D[i][j]=D[i][w]+D[w][j];
				}
				}
				
			}
		}
	}
	t2=mytimer();
	printf("nontrivalTripleComparison=%d\n",nontrivalTripleComparison);
	printf("totally takes time= %f\n",t2-t1);	
	fclose(fp);
	
	return 0;
}
float mytimer()
{ struct tms hold;
 
 times(&hold);
 /*return  (float)(hold.tms_utime) / 60.0;*/
 return  (float)(hold.tms_utime);
}
