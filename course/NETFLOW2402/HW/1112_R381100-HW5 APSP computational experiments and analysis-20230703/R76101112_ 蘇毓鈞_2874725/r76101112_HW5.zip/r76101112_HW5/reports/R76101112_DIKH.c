/*
	This program is the dijk heap implementation.output is he shortest path from V1 to V6
	compile:
		gcc -o R76101112_dijk R76101112_dijk.c
	run:
		./R76101112_dijk
	This code can be compiled and run ok on Ubuntu.
	coded by SU YU CHUN, ID: R76101112, email: R76101112@gs.ncku.edu.tw
	date: 2023/5/23
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/times.h>
float mytimer();
#define MAXV 6401
#define Infinite 1073741823
#define VISITED 1
#define NOTVISITED 0
int **A=NULL,*changed,*D,weight=0,*S=NULL,*P=NULL,source,step,*Stack,top=-1,*bucket,lastIndex=0,*heapTree;

int minD(int node){
	int i,t;
	int minimum=Infinite;
	for(i=1;i<=node;i++){
		if((S[i]==NOTVISITED) && D[i]<minimum){
			minimum=D[i];
			t=i;
		}
	} 
	return t;
}
void Push(int value){
	Stack[++top]=value;
}
int Pop(){
	return Stack[top--];
}
void outputPath(int sink){
	int n=sink;
	if((sink==source)||D[sink]==Infinite){
		printf("no path\n");
		return;
	}
	printf("The shortest path from V%d to V%d:",source,sink);
	printf(" V%d",source);
	while(n!=source){
		Push(n);
		n=P[n];
	}
	while(n!=sink){
		n=Pop();
		printf("--%d-->",A[P[n]][n]);
		printf("V%d",n);
	}
	printf("\nTotal length:%d\n",D[sink]);
}


void exchange(int *id1,int *id2){
	int idTemp;
	idTemp=*id1;
	*id1=*id2;
	*id2=idTemp;
}

void adjustU(int *temp,int index){
	while(index>1){
		if(temp[index]<=temp[index]/2)
			break;
		else
			exchange(&temp[index],&temp[index/2]);
		index/=2;
	}
}
void insert(int t){
bucket[++lastIndex]=t;
	adjustU(bucket,lastIndex);
} 

int main(){
	FILE *fp;
	char s[1024],fileName[1024],problemName[1024],k,a,b,c;
	double **ptr=NULL;
float t1=0.,t2=0.;

	int i,j,w,n,node,count,arc,u,t,sum=0,I;
	
	printf("Please input network filename:");
	scanf("%s",fileName);
	if((fp=fopen(fileName,"r"))==NULL) {
		printf("Open file error!!\n");
		system("pause");
		exit(0);
	}
	/*while(!feof(fp)) {
		fgets(s,1024,fp);
		
		if(s[0]=='n') {
			node=s[2]-48;
		
			ptr=(double **)malloc(sizeof(double *)*node);
			A=(int **)malloc(sizeof(int *)*node);
			for(i=0;i<node;i++) {
				ptr[i] = (double *)malloc(sizeof(double)*node);
				A[i]=(int *)malloc(sizeof(int)*node);
			}
			for(i=0;i<node;i++){
				for(j=0;j<node;j++){
					ptr[i][j]=0.0;
					A[i][j]=Infinite;
				}
			}  
			
			changed=(int *)malloc(sizeof(int)*node);
			D=(int *)malloc(sizeof(int)*node);
			break;
		}
		if(s[0]=='a') {
			
		}
		if(s[0]=='p'){
			arc=(s[8]-48);
		}
		if(s[0]=='t'){
			j=0;
			for(i=2;s[i]!='\n';i++){
				problemName[j]=s[i];
				j++;
			}
			
		}
		for(i=0;i<node;i++){
				for(j=0;j<node;j++){
					if(ptr[i][j]!=0.0)
					  A[i][j]=(int)ptr[i][j];
				}
			}
	}
	for(i=0;i<node;i++){
				D[i]=Infinite;
				changed[i]=0;
	}*/ 
	i=0;
	while(!feof(fp)){
		fgets(s,1024,fp);
		if(i<6)	i++;
		else	break;
			
	}
	fscanf(fp,"%c %c%c %d %d",&a,&b,&c,&node,&arc);
	ptr=(double **)malloc(sizeof(double *)*(node+1));
			A=(int **)malloc(sizeof(int *)*(node+1));
			for(i=1;i<=node;i++) {
				ptr[i] = (double *)malloc(sizeof(double)*(node+1));
				A[i]=(int *)malloc(sizeof(int)*(node+1));
			}
			for(i=1;i<=node;i++){
				for(j=1;j<=node;j++){
					ptr[i][j]=0.0;
					A[i][j]=Infinite;
				}
			} 
			
			changed=(int *)malloc(sizeof(int)*(node+1));
			D=(int *)malloc(sizeof(int)*(node+1));
			S=(int *)malloc(sizeof(int)*(node+1));
			P=(int *)malloc(sizeof(int)*(node+1));
			bucket=(int *)malloc(sizeof(int)*10000000);
			Stack=(int *)malloc(sizeof(int)*(node+1));
			for(i=1;i<=node;i++){
				for(j=1;j<=node;j++){
					if(ptr[i][j]!=0.0)
					  A[i][j]=(int)ptr[i][j];
				}
		}
		
	i=0;
	while(!feof(fp)){
		fgets(s,1024,fp);
		if(i<3)	i++;
		else	break;
			
	}
	for(i=1;i<=node;i++){
				D[i]=Infinite;
				changed[i]=Infinite;
	}
	

	while(fscanf(fp,"%c	%d	%d	%d",&k,&i,&j,&weight)!=EOF){
		A[i][j]=weight;
	
	}
	t1=mytimer();
	printf("Please input a source node:");
		scanf("%d",&source);
		for(i=1;i<=node;i++){
			S[i]=NOTVISITED;
			D[i]=A[source][i];
			P[i]=source;
			if(D[i]!=Infinite){
				insert(D[i]);
			}
		}
		S[source]=VISITED;
		D[source]=0; 
for(step=2;step<=node;step++){
	t=minD(node);
	S[t]=VISITED;
	for(I=1;I<=node;I++){
		if((S[I]==NOTVISITED) && (D[t]+A[t][I]<=D[I])){
			D[I]=D[t]+A[t][I];
			P[I]=t;
		}
	}
}
outputPath(6);
t2=mytimer();
  printf("totally takes time= %f\n",t2-t1);
	fclose(fp);
	
	return 0;
}
float mytimer()
{ struct tms hold;
 
 times(&hold);
 /*return  (float)(hold.tms_utime) / 60.0;*/
 return  (float)(hold.tms_utime);
}

