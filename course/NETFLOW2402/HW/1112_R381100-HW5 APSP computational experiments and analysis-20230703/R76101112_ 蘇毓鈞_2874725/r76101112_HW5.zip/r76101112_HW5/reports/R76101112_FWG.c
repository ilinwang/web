/*
	This program is the Floyd-Warshall graphic algorithm pape implementation.Output is the non trivial Triple Comparison. 
	compile:
		gcc -o R76101112_FWG R76101112_FWG.c
	run:
		./R76101112_FWG
	This code can be compiled and run ok on Ubuntu.
	coded by SU YU CHUN, ID: R76101112, email: R76101112@gs.ncku.edu.tw
	date: 2023/5/22 
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/times.h>
#define MAXV 6401
#define Infinite 1073741823
float mytimer();
typedef struct nodeTag{
	int vertex;
	int weight;

	struct nodeTag *link;
}Node;
Node *adjlist[MAXV+1];
Node *adjlist1[MAXV+1];
Node *searchlast(Node *linklist){
	Node *pt;
	pt=linklist;
	while(pt->link!=NULL)
		pt=pt->link;
	return pt;
}
void showAdjlist(int node){
	int index;
	Node *pt;
	printf("Head adjacency nodes\n");
	for(index=0;index<node;index++){
		printf("V%-2d ",adjlist[index]->vertex+1);
		pt=adjlist[index]->link;
		while(pt!=NULL){
			printf("--> V%dW%d ",pt->vertex+1,pt->weight);
			pt=pt->link;
		}
		printf("\n");
	}
}
int findWeight(int i,int j){
	if(i==j)
		return 0;
	Node *pt;
	pt=adjlist[i]->link;
	while(pt!=NULL){
		if(pt->vertex==j)
			return pt->weight;
		pt=pt->link;
	}
	return Infinite;
}
int findWeight1(int i,int j){
	if(i==j)
		return 0;
	Node *pt;
	pt=adjlist1[i]->link;
	while(pt!=NULL){
		if(pt->vertex==j)
			return pt->weight;
		pt=pt->link;
	}
	return Infinite;
}
void setWeight(int i,int j,int w){
	Node *pt,*n,*l;
	pt=adjlist[i]->link;
	while(pt!=NULL){
		if(pt->vertex==j){
			pt->weight=w;
			return;
		}
		pt=pt->link;
	}
	n=(Node *)malloc(sizeof(Node));
	n->vertex=j;
	n->weight=w;
	n->link=NULL;
	l=searchlast(adjlist[i]);
	l->link=n;
}
void setWeight1(int i,int j,int w){
	Node *pt,*n,*l;
	pt=adjlist1[i]->link;
	while(pt!=NULL){
		if(pt->vertex==j){
			pt->weight=w;
			return;
		}
		pt=pt->link;
	}
	n=(Node *)malloc(sizeof(Node));
	n->vertex=j;
	n->weight=w;
	n->link=NULL;
	l=searchlast(adjlist1[i]);
	l->link=n;
}
void showAdjlist1(int node){
	int index;
	Node *pt;
	printf("Head adjacency nodes\n");
	for(index=0;index<node;index++){
		printf("V%-2d ",adjlist1[index]->vertex);
		pt=adjlist1[index]->link;
		while(pt!=NULL){
			printf("--> V%dW%d ",pt->vertex,pt->weight);
			pt=pt->link;
		}
		printf("\n");
	}
}

int main(){
	FILE *fp;
	float t1=0.,t2=0.;
	char s[1024],fileName[1024],problemName[1024],k,a,b,c;
	double **ptr=NULL;
	int nontrivalTripleComparison=0,n_loop=9;
	Node *no,*lastnode,*p,*pp;
	int **A=NULL,*changed,*D,weight=0,temp,temp1;
	int i,j,w,n,node,count,arc,u,t,sum=0;
	int vi,vj,wei;
	printf("Please input network filename:");
	scanf("%s",fileName);
	if((fp=fopen(fileName,"r"))==NULL) {
		printf("Open file error!!\n");
		system("pause");
		exit(0);
	}
	/*while(!feof(fp)) {
		fgets(s,1024,fp);
		
		if(s[0]=='n') {
			node=s[2]-48;
		
			ptr=(double **)malloc(sizeof(double *)*node);
			A=(int **)malloc(sizeof(int *)*node);
			for(i=0;i<node;i++) {
				ptr[i] = (double *)malloc(sizeof(double)*node);
				A[i]=(int *)malloc(sizeof(int)*node);
			}
			for(i=0;i<node;i++){
				for(j=0;j<node;j++){
					ptr[i][j]=0.0;
					A[i][j]=Infinite;
				}
			}  
			
			changed=(int *)malloc(sizeof(int)*node);
			D=(int *)malloc(sizeof(int)*node);
			break;
		}
		if(s[0]=='a') {
			
		}
		if(s[0]=='p'){
			arc=(s[8]-48);
		}
		if(s[0]=='t'){
			j=0;
			for(i=2;s[i]!='\n';i++){
				problemName[j]=s[i];
				j++;
			}
			
		}
		for(i=0;i<node;i++){
				for(j=0;j<node;j++){
					if(ptr[i][j]!=0.0)
					  A[i][j]=(int)ptr[i][j];
				}
			}
	}
	for(i=0;i<node;i++){
				D[i]=Infinite;
				changed[i]=0;
	}*/ 
	i=0;
	while(!feof(fp)){
		fgets(s,1024,fp);
		if(i<6)	i++;
		else	break;
			
	}
	fscanf(fp,"%c %c%c %d %d",&a,&b,&c,&node,&arc);
	ptr=(double **)malloc(sizeof(double *)*node);
			A=(int **)malloc(sizeof(int *)*node);
			for(i=0;i<node;i++) {
				ptr[i] = (double *)malloc(sizeof(double)*node);
				A[i]=(int *)malloc(sizeof(int)*node);
			}
			for(i=0;i<node;i++){
				for(j=0;j<node;j++){
					ptr[i][j]=0.0;
					A[i][j]=Infinite;
				}
			}  
		
			
			changed=(int *)malloc(sizeof(int)*node);
			D=(int *)malloc(sizeof(int)*node);
			for(i=0;i<node;i++){
				for(j=0;j<node;j++){
					if(ptr[i][j]!=0.0)
					  A[i][j]=(int)ptr[i][j];
				}
		}
	i=0;
	while(!feof(fp)){
		fgets(s,1024,fp);
		if(i<3)	i++;
		else	break;
			
	}
	for(i=0;i<node;i++){
				D[i]=Infinite;
				changed[i]=Infinite;
	}
	changed[0]=0;
	D[0]=0;

	while(fscanf(fp,"%c	%d	%d	%d",&k,&i,&j,&weight)!=EOF){
		A[i-1][j-1]=weight;
	
	}
	for(vi=0;vi<node;vi++){
		adjlist[vi]=(Node *)malloc(sizeof(Node));
		adjlist[vi]->vertex=vi;
		adjlist[vi]->link=NULL;
	}
	t1=mytimer();
	for(vi=0;vi<node;vi++){
		for(vj=0;vj<node;vj++){
			if(A[vi][vj]!=Infinite){
				no=(Node *)malloc(sizeof(Node));
				no->vertex=vj;
				no->weight=A[vi][vj];
				no->link=NULL;
				lastnode=searchlast(adjlist[vi]);
				lastnode->link=no;
			}
		}
	}


for(vi=0;vi<node;vi++){
	adjlist1[vi]=(Node *)malloc(sizeof(Node));
	adjlist1[vi]->vertex=vi;
	adjlist1[vi]->link=NULL;
}
	for(vi=0;vi<node;vi++){
		for(vj=0;vj<node;vj++){
			if(A[vj][vi]!=Infinite && vi!=vj){
				no=(Node *)malloc(sizeof(Node));
				no->vertex=vj;
				no->weight=A[vj][vi];
				no->link=NULL;
				lastnode=searchlast(adjlist1[vi]);
				lastnode->link=no;
			}
		}
	}



	for(i=0;i<node;i++){
		p=adjlist1[i]->link;
		temp=0;
	
		while(p!=NULL){
			temp=findWeight1(i,p->vertex);
			pp=adjlist[i]->link;
			while(pp!=NULL){
				
			 
				if(temp+pp->weight<findWeight(p->vertex,pp->vertex)){
					nontrivalTripleComparison++;
					setWeight(p->vertex,pp->vertex,temp+pp->weight);
					setWeight1(pp->vertex,p->vertex,temp+pp->weight);
				
				
				}
				pp=pp->link;
			}
			p=p->link;
		}

	
}
t2=mytimer();
	printf("nontrivalTripleComparison:%d\n",nontrivalTripleComparison);
printf("totally takes time= %f\n",t2-t1);	

	fclose(fp);
	
	return 0;
}
float mytimer()
{ struct tms hold;
 
 times(&hold);
 /*return  (float)(hold.tms_utime) / 60.0;*/
 return  (float)(hold.tms_utime);
}

