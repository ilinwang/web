/*
   This code can be compiled and run ok.

   Purpose:
     This code can first read a network file and source node(s),
     then output ALL-ALL shortest path with its total running time and non-trivial comparison by Floyd-Warshall algebraic algorithm.

   Usage:
     Firstly, user request to input a filename. If filename is invalid, it will print error message and terminate.
     Secondly, user request to input a source node. If source node is invalid, it will print error message and terminate,
     else, it will print out the result of ALL-ALL shortest path.

   Input file:
     144 cases of spgrid

   Output files:
     None.

   Compile:
     g++ -o ../bin/fwa ../src/fwa.cpp
     ../bin/fwa spg1.txt > ../results/outputs_fwa_1.txt
     
 Pseudocode:
  Begin
     Initialization: D:=C; PRED_ij:=i for each (i,j);
     for k=1 to |V| do
        for i=1 to |V| do
            for j=1 to |V| do
                if d_ij > d_ik + d_kj then
                    d_ij = d_ik + d_kj; PRED_ij = PRED_kj
   End

   coded by 李佳哲, ID: h34091160, email: h34091160@gs.ncku.edu.tw
   date: 2023.06.11
*/

#include <string>
#include <chrono>
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <iostream>

using namespace std;

// Define the structure of node
struct Nodes {
    int node_index;    // record the index of the node
    int pred;    // record the predecessor of the node
    int arc_len;    // record arc length (only used in adjacency list)
    int arc_index;    // record arc index (only used in adjacency list)
    int d;    // record the distance label of the node
    Nodes* next;   // pointer
};

// Define the structure of node
struct Arcs {
    int arc_index;    // record the index of the arc
    int s;    // record the tail node of the arc
    int t;    // record the head node of the arc
    int distance;    // record the length of the arc
};

// Define a class that implement adjacency list
class AdjacencyList {
    Nodes* head;
public:
    AdjacencyList() {    // Initialize
        head = nullptr;
    }

    void addNode(int num, int arc_index, int arc_distance) {    // Add node to the adj. list
        Nodes* newNode = new Nodes;
        newNode->node_index = num;
        newNode->arc_len = arc_distance;
        newNode->arc_index = arc_index;
        newNode->next = nullptr;

        if (head == nullptr) {
            head = newNode;
        }
        else {
            Nodes* curr = head;
            while (curr->next != nullptr) {
                curr = curr->next;
            }
            curr->next = newNode;
        }
    }

    int* outdegree_nodes(int outdegree_num){    // Return the outdegree nodes of node i (by array)
        int* out = new int[outdegree_num];
        Nodes* curr = head;

        for(int y=0;y<outdegree_num;y++){
            out[y] = curr->node_index;
            curr = curr->next;
        }
        return out;
    }

    int* outdegree_arcs(int outdegree_num){    // Return the outdegree arcs of node i (by array)
        int* out = new int[outdegree_num];
        Nodes* curr = head;

        for(int y=0;y<outdegree_num;y++){
            out[y] = curr->arc_index;
            curr = curr->next;
        }

        return out;
    }
};

// Shortest path algorithm based on Floyd-Warshall (algebraic)
int fwa(int n, int m, Nodes* node, Arcs* arc){

    // 1. Initialized
    int** D = new int*[n];  // D is adj. matrix
    int** PRED = new int*[n];  // PRED is adj. matrix

    for (int i = 0; i < n; i++) {
        D[i] = new int[n];
        PRED[i] = new int[n];
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i == j) { D[i][j] = 0; }
            else { D[i][j] = 1000000000; }
            PRED[i][j] = 0;
        }
    }

    for (int i=0;i<m;i++){
        D[arc[i].s - 1][arc[i].t - 1] = arc[i].distance;
        PRED[arc[i].s - 1][arc[i].t - 1] = arc[i].s;
    }

    // 2. for loop
    int non_trivial = 0;

    for (int k = 0 ; k < n ; k++) {
        for (int i = 0 ; i < n ; i++) {
            for (int j = 0 ; j < n ; j++) {
                if (D[i][k] != 1000000000 && D[k][j] != 1000000000) {
                    non_trivial++;
                    if (D[i][j] > D[i][k] + D[k][j]) {
                        D[i][j] = D[i][k] + D[k][j];
                        PRED[i][j] = PRED[k][j];
                    }
                }
            }
        }
    }


    // Print out the results
    int sum = 0;

    int itr_sum = 0;
    for (int i = 0; i < n; i++) {
        int itr_sum = 0;
        for (int j = 0; j < n; j++) {
            if (D[i][j] != 1000000000) {
                sum += D[i][j];
                itr_sum += D[i][j];
            }
        }
    }

    cout << "c Total number of nontrivial triple comparisons:\nn " << non_trivial << endl;



    // Clear memory
    for (int i = 0; i < n; i++) {
        delete[] D[i];
        delete[] PRED[i];
    }
    delete[] D;
    delete[] PRED;

    return sum;
}

int main(int argc, char* argv[]) {
    string first, problem_type, problem_name;
    int n = 0;    // Number of nodes
    int m = 0;    // Number of arcs
    int CC = 0;    // Maximum c_ij in A (Dial's sp)
    int start_node = 0;    // Starting node of the arc
    int end_node = 0;    // Ending node of the arc
    int distance = 0;    // Distance of the arc
    int index = 0;    // Index of the arc
    bool counter = true;

    Arcs* arc;    // Record arcs
    Nodes* node;    // Record nodes
    AdjacencyList* adjList_out;    // Record adjacency list by outdegree
    int* outdegree_num;    // Record outdegree number of each node

    
    if (argc < 2) {
        cerr << "Please provide the input filename as a command-line argument." << endl;
        return 1;
    }
    
    string filename = argv[1];
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Failed to open " << filename << endl;
        return 1;
    }

    string s;
    
    
    
    while (getline(file, s)) {
        istringstream stringfile(s);
        stringfile >> first;    // Read the first word of the line

        if(first[0]=='t'){    // Case 1: When read 't', record title of the problem name
            stringfile >> problem_name;
        }
        else if(first[0]=='p'){    // Case 2: When read 'p', record problem type, # of node and arc
            stringfile >> problem_type >> n >> m;

            // Dynamically allocating memory
            outdegree_num = new int[n];
            node = new Nodes[n];
            arc = new Arcs[m];
            adjList_out = new AdjacencyList[n];

            // Save the nodes
            for(int i=0;i<n;i++){
                node[i].node_index = i + 1;
            }
        }
        else if(first[0]=='a'){    // Case 3: When read 'a', record start node, end node and the distance between them
            stringfile >> start_node >> end_node >> distance;

            // Save the arc information
            arc[index].arc_index = index + 1;
            arc[index].s = start_node;
            arc[index].t = end_node;
            arc[index].distance = distance;

            // Check the outdegree number of each node
            if (counter){
                for(int i=0;i<n;i++){
                    outdegree_num[i] = 0;  // Initialized
                }
                counter = 0;
                outdegree_num[start_node-1]++;
            }
            else{   // Record outdegree number
                outdegree_num[start_node-1]++;
            }

            // Check the maximum arc length
            if(distance > CC){
                CC = distance;
            }

            // Add into adjacency list
            adjList_out[start_node].addNode(arc[index].t, arc[index].arc_index, arc[index].distance);
            index++;
        }
    }




    // APSP
    int sum = 0;

    auto start = chrono::high_resolution_clock::now();
    sum = fwa(n, m, node, arc);  // Execute Dial's SP algorithm
    auto stop = chrono::high_resolution_clock::now();

    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);

    cout << "c Running time of fwa APSP computation:\nt "
    << duration.count() << " microseconds" << endl;


    delete[] node;   // Clear the memory
    delete[] arc;
    delete[] outdegree_num;
    delete[] adjList_out;

    file.close();    // Close file

    return 0;
}


