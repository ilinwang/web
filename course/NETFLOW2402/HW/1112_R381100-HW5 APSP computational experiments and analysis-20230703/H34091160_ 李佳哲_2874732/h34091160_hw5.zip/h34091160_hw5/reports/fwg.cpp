/*
   This code can be compiled and run ok.

   Purpose:
     This code can first read a network file and source node(s),
     then output ALL-ALL shortest path with its total running time and non-trivial comparison by Floyd-Warshall graphical algorithm.

   Usage:
     Firstly, user request to input a filename. If filename is invalid, it will print error message and terminate.
     Secondly, user request to input a source node. If source node is invalid, it will print error message and terminate,
     else, it will print out the result of ALL-ALL shortest path.

   Input file:
     144 cases of spgrid

   Output files:
     None.

   Compile:
     g++ -o ../bin/fwg ../src/fwg.cpp
     ../bin/fwg spg1.txt > ../results/outputs_fwg_1.txt
     
 Pseudocode:
  Begin
     Initialization List_out and List_in;
     for k=1 to |V| do
        for i=1 to |V| do
            for j=1 to |V| do
                if node i and node j is not connected
                    List_out[i].addNode(j, d_ik, d_kj);
                    List_in[j].addNode(i, d_ik, d_kj);
                else
                    if d_ij > d_ik + d_kj then d_ij = d_ik + d_kj;
   End

   coded by 李佳哲, ID: h34091160, email: h34091160@gs.ncku.edu.tw
   date: 2023.06.11
*/

#include <string>
#include <chrono>
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <iostream>

using namespace std;

// Define the structure of node
struct Nodes {
    int node_index;    // record the index of the node
    int pred;    // record the predecessor of the node
    int arc_len;    // record arc length (only used in adjacency list)
    int arc_index;    // record arc index (only used in adjacency list)
    int d;    // record the distance label of the node
    Nodes* next;   // pointer
};

// Define the structure of node
struct Arcs {
    int arc_index;    // record the index of the arc
    int s;    // record the tail node of the arc
    int t;    // record the head node of the arc
    int distance;    // record the length of the arc
};

// Define a class that implement adjacency list
class AdjacencyList {
    Nodes* head;
public:
    AdjacencyList() {    // Initialize
        head = nullptr;
    }

    void addNode(int num, int arc_index, int arc_distance) {    // Add node to the adj. list
        Nodes* newNode = new Nodes;
        newNode->node_index = num;
        newNode->arc_len = arc_distance;
        newNode->arc_index = arc_index;
        newNode->next = nullptr;

        if (head == nullptr) {
            head = newNode;
        }
        else {
            Nodes* curr = head;
            while (curr->next != nullptr) {
                curr = curr->next;
            }
            curr->next = newNode;
        }
    }

    int* outdegree_nodes(int outdegree_num){    // Return the outdegree nodes of node i (by array)
        int* out = new int[outdegree_num];
        Nodes* curr = head;

        for(int y=0;y<outdegree_num;y++){
            out[y] = curr->node_index;
            curr = curr->next;
        }
        return out;
    }

    int* outdegree_arcs(int outdegree_num){    // Return the outdegree arcs of node i (by array)
        int* out = new int[outdegree_num];
        Nodes* curr = head;

        for(int y=0;y<outdegree_num;y++){
            out[y] = curr->arc_index;
            curr = curr->next;
        }

        return out;
    }
};

struct fwg_node {
    int node_num;
    int node_disance;
    fwg_node* next;
};

// Define a class that implement Floyd-Warshall adjacency list
class fwg_list_outdeg {
    fwg_node* head;
public:
    fwg_list_outdeg() {    // Initialize
        head = nullptr;
    }

    void addNode(int num, int dis) {    // Add node to the adj. list
        fwg_node* newNode = new fwg_node;
        newNode->node_num = num;
        newNode->node_disance = dis;
        newNode->next = nullptr;

        if (head == nullptr) {
            head = newNode;
        }
        else {
            fwg_node* curr = head;
            while (curr->next != nullptr) {
                curr = curr->next;
            }
            curr->next = newNode;
        }
    }

    int size_outdeg() {  // return the size of adj. list
        fwg_node* curr = head;
        int n = 0;
        while (curr != nullptr) {
            n++;
            curr = curr->next;
        }
        return n;
    }

    int curr_node_num(int n) {  // return the node index of the i'th adj.list
        fwg_node* curr = head;
        int counter = 1;
        while (curr != nullptr) {
            if (counter == n) {
                return curr->node_num;
            }
            else {
                curr = curr->next;
                counter++;
            }
        }
        return 0;
    }

    int curr_node_dis(int n) {  // return the node distance of the i'th adj.list
        fwg_node* curr = head;
        int counter = 1;
        while (curr != nullptr) {
            if (counter == n) {
                return curr->node_disance;
            }
            else {
                curr = curr->next;
                counter++;
            }
        }
        return 0;
    }

    int index_dis(int id) {  // return the node's distance of the adj.list
        fwg_node* curr = head;
        while (curr != nullptr) {
            if (curr->node_num == id) {
                return curr->node_disance;
            }
            else {
                curr = curr->next;
            }
        }
        return 0;
    }

    void update_index_dis(int id, int d_ik, int d_kj) {  // update the distance, if the node isn't exist, then add the node to the tail
        fwg_node* curr = head;
        bool have_node = false;
        while (curr != nullptr) {
            if (curr->node_num == id) {
                if (curr->node_disance > d_ik + d_kj) {
                    curr->node_disance = d_ik + d_kj;
                }
                have_node = true;
                break;
            }
            else {
                curr = curr->next;
            }
        }
        if (!have_node){
            addNode(id, d_ik + d_kj);
        }
    }

};

// Define a class that implement Floyd-Warshall adjacency list
class fwg_list_indeg {
    fwg_node* head;
public:
    fwg_list_indeg() {    // Initialize
        head = nullptr;
    }

    void addNode(int num, int dis) {    // Add node to the adj. list
        fwg_node* newNode = new fwg_node;
        newNode->node_num = num;
        newNode->node_disance = dis;
        newNode->next = nullptr;

        if (head == nullptr) {
            head = newNode;
        }
        else {
            fwg_node* curr = head;
            while (curr->next != nullptr) {
                curr = curr->next;
            }
            curr->next = newNode;
        }
    }

    int size_indeg() {  // return the size of adj. list
        fwg_node* curr = head;
        int n = 0;
        while (curr != nullptr) {
            n++;
            curr = curr->next;
        }
        return n;
    }

    int curr_node_num(int n) {  // return the node index of the i'th adj.list
        fwg_node* curr = head;
        int counter = 1;
        while (curr != nullptr) {
            if (counter == n) {
                return curr->node_num;
            }
            else {
                curr = curr->next;
                counter++;
            }
        }
        return 0;
    }

    int curr_node_dis(int n) {  // return the node distance of the i'th adj.list
        fwg_node* curr = head;
        int counter = 1;
        while (curr != nullptr) {
            if (counter == n) {
                return curr->node_disance;
            }
            else {
                curr = curr->next;
                counter++;
            }
        }
        return 0;
    }

    void update_index_dis(int id, int d_ik, int d_kj) {  // update the distance, if the node isn't exist, then add the node to the tail
        fwg_node* curr = head;
        bool have_node = false;
        while (curr != nullptr) {
            if (curr->node_num == id) {
                if (curr->node_disance > d_ik + d_kj) {
                    curr->node_disance = d_ik + d_kj;
                }
                have_node = true;
                break;
            }
            else {
                curr = curr->next;
            }
        }
        if (!have_node){
            addNode(id, d_ik + d_kj);
        }
    }

};

// Shortest path algorithm based on Floyd-Warshall (algebraic)
int fwg(int n, int m, Nodes* node, Arcs* arc){

    // 1. Initialized

    fwg_list_outdeg* List_out = new fwg_list_outdeg[n + 1];
    fwg_list_indeg* List_in = new fwg_list_indeg[n + 1];
    for (int i = 0; i < m; i++) {
        int start_node = arc[i].s;
        int end_node = arc[i].t;
        int distance = arc[i].distance;
        List_out[start_node].addNode(end_node, distance);
        List_in[end_node].addNode(start_node, distance);
    }

    // 2. for loop
    int non_trivial = 0;

    for (int k = 1 ; k <= n ; k++) {
        for (int i = 1 ; i <= List_in[k].size_indeg() ; i++) {
            for (int j = 1 ; j <= List_out[k].size_outdeg() ; j++) {
                non_trivial++;
                int d_ik = List_in[k].curr_node_dis(i);
                int d_kj = List_out[k].curr_node_dis(j);
                int curr_i_index = List_in[k].curr_node_num(i);
                int curr_j_index = List_out[k].curr_node_num(j);

                List_out[curr_i_index].update_index_dis(curr_j_index, d_ik, d_kj);
                List_in[curr_j_index].update_index_dis(curr_i_index, d_ik, d_kj);
            }
        }
    }


    // Print out the results
    cout << "c Total number of nontrivial triple comparisons:\nn " << non_trivial << endl;

    // Clear memory
    delete[] List_out;
    delete[] List_in;


    return 0;
}

int main(int argc, char* argv[]) {
    string first, problem_type, problem_name;
    int n = 0;    // Number of nodes
    int m = 0;    // Number of arcs
    int CC = 0;    // Maximum c_ij in A (Dial's sp)
    int start_node = 0;    // Starting node of the arc
    int end_node = 0;    // Ending node of the arc
    int distance = 0;    // Distance of the arc
    int index = 0;    // Index of the arc
    bool counter = true;

    Arcs* arc;    // Record arcs
    Nodes* node;    // Record nodes
    AdjacencyList* adjList_out;    // Record adjacency list by outdegree
    int* outdegree_num;    // Record outdegree number of each node

    
    if (argc < 2) {
        cerr << "Please provide the input filename as a command-line argument." << endl;
        return 1;
    }
    
    string filename = argv[1];
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Failed to open " << filename << endl;
        return 1;
    }

    string s;
    
    
    
    while (getline(file, s)) {
        istringstream stringfile(s);
        stringfile >> first;    // Read the first word of the line

        if(first[0]=='t'){    // Case 1: When read 't', record title of the problem name
            stringfile >> problem_name;
        }
        else if(first[0]=='p'){    // Case 2: When read 'p', record problem type, # of node and arc
            stringfile >> problem_type >> n >> m;

            // Dynamically allocating memory
            outdegree_num = new int[n];
            node = new Nodes[n];
            arc = new Arcs[m];
            adjList_out = new AdjacencyList[n];

            // Save the nodes
            for(int i=0;i<n;i++){
                node[i].node_index = i + 1;
            }
        }
        else if(first[0]=='a'){    // Case 3: When read 'a', record start node, end node and the distance between them
            stringfile >> start_node >> end_node >> distance;

            // Save the arc information
            arc[index].arc_index = index + 1;
            arc[index].s = start_node;
            arc[index].t = end_node;
            arc[index].distance = distance;

            // Check the outdegree number of each node
            if (counter){
                for(int i=0;i<n;i++){
                    outdegree_num[i] = 0;  // Initialized
                }
                counter = 0;
                outdegree_num[start_node-1]++;
            }
            else{   // Record outdegree number
                outdegree_num[start_node-1]++;
            }

            // Check the maximum arc length
            if(distance > CC){
                CC = distance;
            }

            // Add into adjacency list
            adjList_out[start_node].addNode(arc[index].t, arc[index].arc_index, arc[index].distance);
            index++;
        }
    }

    // APSP
    auto start = chrono::high_resolution_clock::now();
    fwg(n, m, node, arc);  // Execute Dial's SP algorithm
    auto stop = chrono::high_resolution_clock::now();

    auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);

    cout << "c Running time of fwg APSP computation:\nt "
    << duration.count() << " microseconds" << endl;


    delete[] node;   // Clear the memory
    delete[] arc;
    delete[] outdegree_num;
    delete[] adjList_out;

    file.close();    // Close file

    return 0;
}
