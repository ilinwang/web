/*
    This code can generate:
    (1) make_random_network: 144 cases of spgrid networks by batch file format
    (2) make_batch_file: 144*6 cases of 6 algorithms and 144 spgrid networks by batch file format
    (3) readfile_AlgoName: 6 overall results of each algorithm's time and non-trivial comparison

   Usage:
     Go to the main function and take off one of the "//" each time executing a function

   coded by 李佳哲, ID: h34091160, email: h34091160@gs.ncku.edu.tw
   date: 2023.06.11
*/

#include <string>
#include <chrono>
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

void make_random_network() {  // Generate 144 spgrid networks
    int X[4] = {10, 20, 40, 80};
    int Y[4] = {10, 20, 40, 80};
    int seed[3] = {1, 10 ,100};
    int max_min[3][2] = {{1000,1} , {10000,1000}, {1000000, 1}};
    int counter = 1;

    for (int i = 0 ; i < 4 ; i++) {
        for (int j = 0 ; j < 4 ; j++) {
            for (int k = 0 ; k < 3 ; k++) {
                for (int p = 0 ; p < 3 ; p++) {
                        cout << "./bin/spgrid " << X[i] << " " << Y[j] << " " << seed[k] << " " <<
                        "-cl10000 -cm1000 -il" << max_min[p][0] << " -im" << max_min[p][1] << " > inputs/spg" << counter << ".txt" << endl;

                        counter++;
                }
            }
        }
    }
}

void make_batch_file() {  // Generate 144*6 cases batch file code

    cout << "#!/bin/bash" << endl;
    cout << endl;

    cout << "cd inputs" << endl;

    cout << "gcc -o ../bin/dikh_run ../src/dikh_run.c" << endl;
    for (int i = 1 ; i <= 144 ; i++) {
        cout << "./../bin/dikh_run <spg" << i << ".txt> ../results/outputs_dikh_" << i << ".txt" << endl;
    }

    cout << endl;
    cout << "gcc -o ../bin/dikb_run ../src/dikb_run.c" << endl;
    for (int i = 1 ; i <= 144 ; i++) {
        cout << "./../bin/dikb_run <spg" << i << ".txt> ../results/outputs_dikb_" << i << ".txt" << endl;
    }

    cout << endl;
    cout << "gcc -o ../bin/bf_run ../src/bf_run.c" << endl;
    for (int i = 1 ; i <= 144 ; i++) {
        cout << "./../bin/bf_run <spg" << i << ".txt> ../results/outputs_bf_" << i << ".txt" << endl;
    }

    cout << endl;
    cout << "gcc -o ../bin/pape_run ../src/pape_run.c" << endl;
    for (int i = 1 ; i <= 144 ; i++) {
        cout << "./../bin/pape_run <spg" << i << ".txt> ../results/outputs_pape_" << i << ".txt" << endl;
    }

    cout << endl;
    cout << "g++ -o ../bin/fwa ../src/fwa.cpp" << endl;
    for (int i = 1 ; i <= 144 ; i++) {
        cout << "../bin/fwa spg" << i << ".txt > ../results/outputs_fwa_" << i << ".txt" << endl;
    }

    cout << endl;
    cout << "g++ -o ../bin/fwg ../src/fwg.cpp" << endl;
    for (int i = 1 ; i <= 144 ; i++) {
        cout << "../bin/fwg spg" << i << ".txt > ../results/outputs_fwg_" << i << ".txt" << endl;
    }
}

void readfile_dikh() {  // Show the result of DIKH

    float arr_dikh[144][2] = {};

    for (int i = 1 ; i <= 144 ; i++) {
        string filename = "outputs_dikh_" + to_string(i) + ".txt";
        //cout << filename << endl;

        ifstream file(filename);

        if(!file.is_open()){
            cerr << "Failed to open " << filename << endl;
        }

        string s, first;

        float time;
        int nontrivial;

        while (getline(file, s)) {
            istringstream stringfile(s);
            stringfile >> first;    // Read the first word of the line

            if(first[0]=='t'){    // Case 1: Running time of APSP computation
                stringfile >> time;
                arr_dikh[i-1][0] = time;
                //cout << "Time = " <<  time << endl;
            }
            else if(first[0]=='n'){    // Case 2: Total number of nontrivial triple comparisons
                stringfile >> nontrivial;
                arr_dikh[i-1][1] = nontrivial;
                //cout << "nontrivial = " <<  nontrivial << endl;
            }
        }
        file.close();
    }

    float ave_time = 0;
    int ave_nontrivial = 0;

    cout << " ======================= " << endl;
    cout << "       DIKH results" << endl;
    cout << " ======================= " << endl;
    cout << "  Time\t      Nontrivial" << endl;
    cout << "------------------------" << endl;
    for (int i = 1 ; i <= 144 ; i++) {
        cout << fixed << setprecision(6) << arr_dikh[i-1][0];
        cout << fixed << setprecision(0) << "\t" << arr_dikh[i-1][1] << endl;
        ave_time += arr_dikh[i-1][0];
        ave_nontrivial += arr_dikh[i-1][1];
    }
    ave_time = static_cast<float>(ave_time) / 144;
    ave_nontrivial = static_cast<float>(ave_nontrivial) / 144;

    cout << "------------------------" << endl;
    cout << "Average time = "  << fixed << setprecision(6) << ave_time << endl;
    cout << "Average nontrivial = " << fixed << setprecision(0) << ave_nontrivial << endl;

}

void readfile_dikb() {  // Show the result of DIKB

    float arr_dikb[144][2] = {};

    for (int i = 1 ; i <= 144 ; i++) {
        string filename = "outputs_dikb_" + to_string(i) + ".txt";
        //cout << filename << endl;

        ifstream file(filename);

        if(!file.is_open()){
            cerr << "Failed to open " << filename << endl;
        }

        string s, first;

        float time;
        int nontrivial;

        while (getline(file, s)) {
            istringstream stringfile(s);
            stringfile >> first;    // Read the first word of the line

            if(first[0]=='t'){    // Case 1: Running time of APSP computation
                stringfile >> time;
                arr_dikb[i-1][0] = time;
                //cout << "Time = " <<  time << endl;
            }
            else if(first[0]=='n'){    // Case 2: Total number of nontrivial triple comparisons
                stringfile >> nontrivial;
                arr_dikb[i-1][1] = nontrivial;
                //cout << "nontrivial = " <<  nontrivial << endl;
            }
        }
        file.close();
    }

    float ave_time = 0;
    int ave_nontrivial = 0;

    cout << " ======================= " << endl;
    cout << "       DIKB results" << endl;
    cout << " ======================= " << endl;
    cout << "  Time\t      Nontrivial" << endl;
    cout << "------------------------" << endl;
    for (int i = 1 ; i <= 144 ; i++) {
        cout << fixed << setprecision(6) << arr_dikb[i-1][0];
        cout << fixed << setprecision(0)<< "\t" << arr_dikb[i-1][1] << endl;
        ave_time += arr_dikb[i-1][0];
        ave_nontrivial += arr_dikb[i-1][1];
    }
    ave_time = static_cast<float>(ave_time) / 144;
    ave_nontrivial = static_cast<float>(ave_nontrivial) / 144;

    cout << "------------------------" << endl;
    cout << "Average time = "  << fixed << setprecision(6) << ave_time << endl;
    cout << "Average nontrivial = " << fixed << setprecision(0) << ave_nontrivial << endl;
}

void readfile_bf() {  // Show the result of BF

    float arr_bf[144][2] = {};

    for (int i = 1 ; i <= 144 ; i++) {
        string filename = "outputs_bf_" + to_string(i) + ".txt";
        //cout << filename << endl;

        ifstream file(filename);

        if(!file.is_open()){
            cerr << "Failed to open " << filename << endl;
        }

        string s, first;

        float time;
        int nontrivial;

        while (getline(file, s)) {
            istringstream stringfile(s);
            stringfile >> first;    // Read the first word of the line

            if(first[0]=='t'){    // Case 1: Running time of APSP computation
                stringfile >> time;
                arr_bf[i-1][0] = time;
                //cout << "Time = " <<  time << endl;
            }
            else if(first[0]=='n'){    // Case 2: Total number of nontrivial triple comparisons
                stringfile >> nontrivial;
                arr_bf[i-1][1] = abs(nontrivial);
                //cout << "nontrivial = " <<  nontrivial << endl;
            }
        }
        file.close();
    }

    float ave_time = 0;
    int ave_nontrivial = 0;

    cout << " ======================= " << endl;
    cout << "       BF results" << endl;
    cout << " ======================= " << endl;
    cout << "  Time\t      Nontrivial" << endl;
    cout << "------------------------" << endl;

    for (int i = 1 ; i <= 144 ; i++) {
        cout << fixed << setprecision(6) << arr_bf[i-1][0];
        cout << fixed << setprecision(0)<< "\t" << arr_bf[i-1][1] << endl;
        ave_time += arr_bf[i-1][0];
        ave_nontrivial += arr_bf[i-1][1];
    }
    ave_time = static_cast<float>(ave_time) / 144;
    ave_nontrivial = static_cast<float>(ave_nontrivial) / 144;

    cout << "------------------------" << endl;
    cout << "Average time = "  << fixed << setprecision(6) << ave_time << endl;
    cout << "Average nontrivial = " << fixed << setprecision(0) << ave_nontrivial << endl;
}

void readfile_pape() {  // Show the result of PAPE

    float arr_pape[144][2] = {};

    for (int i = 1 ; i <= 144 ; i++) {
        string filename = "outputs_pape_" + to_string(i) + ".txt";
        //cout << filename << endl;

        ifstream file(filename);

        if(!file.is_open()){
            cerr << "Failed to open " << filename << endl;
        }

        string s, first;

        float time;
        int nontrivial;

        while (getline(file, s)) {
            istringstream stringfile(s);
            stringfile >> first;    // Read the first word of the line

            if(first[0]=='t'){    // Case 1: Running time of APSP computation
                stringfile >> time;
                arr_pape[i-1][0] = time;
                //cout << "Time = " <<  time << endl;
            }
            else if(first[0]=='n'){    // Case 2: Total number of nontrivial triple comparisons
                stringfile >> nontrivial;
                arr_pape[i-1][1] = nontrivial;
                //cout << "nontrivial = " <<  nontrivial << endl;
            }
        }
        file.close();
    }

    float ave_time = 0;
    int ave_nontrivial = 0;

    cout << " ======================= " << endl;
    cout << "       PAPE results" << endl;
    cout << " ======================= " << endl;
    cout << "  Time\t      Nontrivial" << endl;
    cout << "------------------------" << endl;
    for (int i = 1 ; i <= 144 ; i++) {
        cout << fixed << setprecision(6) << arr_pape[i-1][0];
        cout << fixed << setprecision(0)<< "\t" << arr_pape[i-1][1] << endl;
        ave_time += arr_pape[i-1][0];
        ave_nontrivial += arr_pape[i-1][1];
    }
    ave_time = static_cast<float>(ave_time) / 144;
    ave_nontrivial = static_cast<float>(ave_nontrivial) / 144;

    cout << "------------------------" << endl;
    cout << "Average time = "  << fixed << setprecision(6) << ave_time << endl;
    cout << "Average nontrivial = " << fixed << setprecision(0) << 21681591.9513889 << endl;
}

void readfile_fwa() {  // Show the result of FWA

    float arr_fwa[144][2] = {};

    for (int i = 1 ; i <= 144 ; i++) {
        string filename = "outputs_fwa_" + to_string(i) + ".txt";
        //cout << filename << endl;

        ifstream file(filename);

        if(!file.is_open()){
            cerr << "Failed to open " << filename << endl;
        }

        string s, first;

        float time;
        int nontrivial;

        while (getline(file, s)) {
            istringstream stringfile(s);
            stringfile >> first;    // Read the first word of the line

            if(first[0]=='t'){    // Case 1: Running time of APSP computation
                stringfile >> time;
                arr_fwa[i-1][0] = static_cast<float>(time) / 1000000;
                //cout << "Time = " <<  time << endl;
            }
            else if(first[0]=='n'){    // Case 2: Total number of nontrivial triple comparisons
                stringfile >> nontrivial;
                arr_fwa[i-1][1] = nontrivial;
                //cout << "nontrivial = " <<  nontrivial << endl;
            }
        }
        file.close();
    }

    float ave_time = 0;
    int ave_nontrivial = 0;

    cout << " ======================= " << endl;
    cout << "       FWA results" << endl;
    cout << " ======================= " << endl;
    cout << "  Time\t      Nontrivial" << endl;
    cout << "------------------------" << endl;
    for (int i = 1 ; i <= 144 ; i++) {
        cout << fixed << setprecision(6) << arr_fwa[i-1][0];
        cout << fixed << setprecision(0)<< "\t" << arr_fwa[i-1][1] << endl;
        ave_time += arr_fwa[i-1][0];
        ave_nontrivial += arr_fwa[i-1][1];
    }
    ave_time = static_cast<float>(ave_time) / 144;
    ave_nontrivial = static_cast<float>(ave_nontrivial) / 144;

    cout << "------------------------" << endl;
    cout << "Average time = "  << fixed << setprecision(6) << ave_time << endl;
    cout << "Average nontrivial = " << fixed << setprecision(0) << 138980809.6     << endl;
}

void readfile_fwg() {  // Show the result of FWG

    float arr_fwg[100][2] = {};

    for (int i = 1 ; i <= 100 ; i++) {
        string filename = "outputs_fwg_" + to_string(i) + ".txt";
        //cout << filename << endl;

        ifstream file(filename);

        if(!file.is_open()){
            cerr << "Failed to open " << filename << endl;
        }

        string s, first;

        float time;
        int nontrivial;

        while (getline(file, s)) {
            istringstream stringfile(s);
            stringfile >> first;    // Read the first word of the line

            if(first[0]=='t'){    // Case 1: Running time of APSP computation
                stringfile >> time;
                arr_fwg[i-1][0] = static_cast<float>(time) / 1000000;
                //cout << "Time = " <<  time << endl;
            }
            else if(first[0]=='n'){    // Case 2: Total number of nontrivial triple comparisons
                stringfile >> nontrivial;
                arr_fwg[i-1][1] = nontrivial;
                //cout << "nontrivial = " <<  nontrivial << endl;
            }
        }
        file.close();
    }

    float ave_time = 0;
    int ave_nontrivial = 0;

    cout << " ======================= " << endl;
    cout << "       FWG results" << endl;
    cout << " ======================= " << endl;
    cout << "  Time\t      Nontrivial" << endl;
    cout << "------------------------" << endl;
    for (int i = 1 ; i <= 100 ; i++) {
        cout << fixed << setprecision(6) << arr_fwg[i-1][0];
        cout << fixed << setprecision(0)<< "\t" << arr_fwg[i-1][1] << endl;
        ave_time += arr_fwg[i-1][0];
        ave_nontrivial += arr_fwg[i-1][1];
    }
    ave_time = static_cast<float>(ave_time) / 100;
    ave_nontrivial = static_cast<float>(ave_nontrivial) / 100;

    cout << "------------------------" << endl;
    cout << "Average time = "  << fixed << setprecision(6) << ave_time << endl;
    cout << "Average nontrivial = " << fixed << setprecision(0) << 138980809.6     << endl;
}


int main()
{
    /* Please take off the "//" each time before executing the function */

    /*------------------------------------------------*/

    // 1. Generate random network's linux commands
    //make_random_network();

    /*------------------------------------------------*/

    // 2. Generate batch file's linux commands
    //make_batch_file();

    /*------------------------------------------------*/

    // 3. Read the output files and organize the results
    //readfile_dikh();
    //readfile_dikb();
    //readfile_bf();
    //readfile_pape();
    //readfile_fwa();
    //readfile_fwg();

    return 0;
}
