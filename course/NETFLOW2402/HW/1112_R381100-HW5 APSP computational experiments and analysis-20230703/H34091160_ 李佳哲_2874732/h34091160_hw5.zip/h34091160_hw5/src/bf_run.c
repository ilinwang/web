#include <stdio.h>
#include <stdlib.h>

#define YES 1
#define NO  0
#define STATISTIC YES

/* statistical variables */
long n_scans;
long n_impr;

/* definitions of types: node & arc */

#include "types_bf.h"

/* parser for getting extended DIMACS format input and transforming the
   data to the internal representation */

#include "parser_dh.c"

/* function 'timer()' for mesuring processor time */
#include "timer.c"

/* function for constructing shortest path tree */

#include "bf.c"

int main (){

    double t;
    arc *arp, *ta;
    node *ndp, *source, *k;
    long n, m, nmin, i;
    char name[21];
    double sum_d = 0;

    int source_node = 0;
    double elapsed_time = 0;
    double Total_APSP_dist = 0;
    double Total_APSP_time = 0;
    int Total_nontrivial = 0;
    int itr_nontrivial = 0;

    

    int num = 1;

    parse( &n, &m, &ndp, &arp, &source, &nmin, name, source_node + 10 );

    for ( int i = 1 ; i <= n ; i++ ){
        parse( &n, &m, &ndp, &arp, &source, &nmin, name, i);

        num = n;
        float t=0.0;

        t = timer();
        itr_nontrivial = bf ( n, ndp, source );

        t = timer() - t;

        elapsed_time = 0;
        elapsed_time = (float)(t);

        sum_d = 0;
        for ( k= ndp; k< ndp + n; k++ )
            if ( k -> parent != (node*) NULL )
                sum_d += (double) (k -> dist);
        
        Total_APSP_dist += sum_d;
        Total_APSP_time += elapsed_time;
        Total_nontrivial += itr_nontrivial;

        //printf ("---------------------------\n");
        //printf ("Sum of distances: %.0f\n", sum_d);
        //printf ("Running time of dikb computation: %.6f", elapsed_time);
        //printf ("\n---------------------------");
        
    }

    //printf("---------------------------\n");
    //printf ("Sum of distances: %.0f\n", Total_APSP_dist);
    printf ("c Running time of bf APSP computation:");
    printf ("\nt %.6f\n", Total_APSP_time);
    printf ("c Total number of nontrivial triple comparisons:");
    printf ("\nn %d", Total_nontrivial);
    //printf("\n---------------------------");
    



}
