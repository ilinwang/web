/***********************************************************/
/*                                                         */
/*               Executor of SP codes                      */
/*               (for bucket Dijkstra)                      */
/*                                                         */
/***********************************************************/


#include <stdio.h>
#include <stdlib.h>

/* statistical variables */
long n_scans = 0;
long n_impr = 0;

/* definitions of types: node & arc */

#include "types_db.h"

/* parser for getting extended DIMACS format input and transforming the
   data to the internal representation */

#include "parser_db.c"

/* function 'timer()' for mesuring processor time */

#include "timer.c"

/* function for constructing shortest path tree */

#include "dikb.c"

int main ()

{

    float t;
    arc *arp, *ta;
    node *ndp, *source, *k;
    long n, m, nmin, i;
    char name[21];
    long mlen;
    double sum_d = 0;
    int cc;
    int source_node = 0;
    float elapsed_time = 0.0;
    double Total_APSP_dist = 0;
    float Total_APSP_time = 0.0;
    
    int num = 1;
    int Total_nontrivial = 0;
    int itr_nontrivial = 0;

    parse( &n, &m, &ndp, &arp, &source, &nmin, name, &mlen, source_node + 10 );

    for ( int i = 1 ; i <= n ; i++ ){
        parse( &n, &m, &ndp, &arp, &source, &nmin, name, &mlen, i);

        num = n;

        float t=0.0;

        t = timer();

        itr_nontrivial = dikb ( n, ndp, source, mlen );

        t = timer() - t;

        elapsed_time = 0;
        elapsed_time = (float)(t);

        sum_d = 0;
        for ( k= ndp; k< ndp + n; k++ )
            if ( k -> parent != (node*) NULL )
                sum_d += (double) (k -> dist);
        
        Total_APSP_dist += sum_d;
        Total_APSP_time += elapsed_time;
        Total_nontrivial += itr_nontrivial;
        
    }

    printf ("c Running time of dikb APSP computation:");
    printf ("\nt %.6f\n", Total_APSP_time);
    printf ("c Total number of nontrivial triple comparisons:");
    printf ("\nn %d", Total_nontrivial);

#define nd(ptr) (int)(ptr-ndp+nmin)

}
