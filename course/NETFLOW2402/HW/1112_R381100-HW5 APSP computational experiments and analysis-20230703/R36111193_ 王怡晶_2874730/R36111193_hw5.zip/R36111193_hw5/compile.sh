#!/bin/bash
echo "compile..."
g++ -o bin/spheap1 src/spheap1.cpp
echo "spheap1 finish compiled."
g++ -o bin/spdial1 src/spdial1.cpp
echo "spdial1 finish compiled."
g++ -o bin/spbf src/spbf.cpp
echo "spbf finish compiled."
g++ -o bin/spbfp src/spbfp.cpp
echo "spbfp finish compiled."
g++ -o bin/spfwa src/spfwa.cpp
echo "spfwa finish compiled."
g++ -o bin/spfwg src/spfwg.cpp
echo "spfwg finish compiled."
echo "you can exit."
read -p "Press enter to continue"
