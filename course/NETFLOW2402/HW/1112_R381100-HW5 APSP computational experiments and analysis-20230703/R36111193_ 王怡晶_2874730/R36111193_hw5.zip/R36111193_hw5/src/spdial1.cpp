/*
 This code can be compiled and run ok.
 
 
 compile:
     visual studio code

 pseudo-code:
 
 
 void dial(){
     //Initialize

     d = new int[node_quantity];
     pred = new int[node_quantity];
     mark = new int[node_quantity];
     bucket_vaule_lowbound = new int[node_quantity];
     int num_bucket = ceil(log((node_quantity-1)*C)/log(2));
     dial_bucket.resize(ceil(log((node_quantity-1)*C)/log(2)));
     int max_distance;
     int min_distance;
     int min_distance_index;
     int first_bucket_distance_label = 0;
     current_bucket = 0;
     for(int i= 0 ; i<node_quantity ;i++){
         d[i] = M;
         pred[i] = 0;
         mark[i] = M;
         bucket_vaule_lowbound[i] = first_bucket_distance_label + pow(2,i-1);
     }
     dial_bucket[0].push_back(source);
     d[source-1] = 0;
     while(!(current_bucket == dial_bucket.size()-1 && dial_bucket[current_bucket].empty())){
         if(dial_bucket[current_bucket].size() == 1  || (!dial_bucket[0].empty()) ){
             deleted_node = dial_bucket[current_bucket][0];
             dial_bucket[current_bucket].erase(dial_bucket[current_bucket].begin());
             for(int i = point[deleted_node-1]; i < point[deleted_node]; i++){
                 num_nontrivial_triple_comparisons++;
                 if(d[_array[i][1]-1] > d[deleted_node-1] + _array[i][2] ){
                     if(mark[_array[i][1]-1] != M){
                         dial_bucket[mark[_array[i][1]-1]].erase(
                             find(dial_bucket[mark[_array[i][1]-1]].begin(),dial_bucket[mark[_array[i][1]-1]].end(),_array[i][1])
                         );
                     }
                     d[_array[i][1]-1] = d[deleted_node-1]+ _array[i][2];
                     pred[_array[i][1]-1] = deleted_node;
                     for(int j = 0; j < dial_bucket.size()-1; j++){
                         if(bucket_vaule_lowbound[j] <= d[_array[i][1]-1] & d[_array[i][1]-1] < bucket_vaule_lowbound[j+1]){
                             mark[_array[i][1]-1] = j;
                             break;
                         }
                     }
                     if(d[_array[i][1]-1] > bucket_vaule_lowbound[dial_bucket.size()-1]){
                         mark[_array[i][1]-1] = dial_bucket.size()-1;
                     }
                     dial_bucket[mark[_array[i][1]-1]].push_back(_array[i][1]);
                 }
             }
         }
         else{
             while(dial_bucket[current_bucket].empty() & current_bucket < dial_bucket.size()-1){
                 current_bucket++;
             }
             if(dial_bucket[current_bucket].size() > 1 ){
                 min_distance = d[dial_bucket[current_bucket][0]-1];
                 max_distance = d[dial_bucket[current_bucket][0]-1];
                 min_distance_index = 0;
                 for(int k=1; k<dial_bucket[current_bucket].size(); k++){
                     if(min_distance > d[dial_bucket[current_bucket][k]-1]){
                         min_distance = d[dial_bucket[current_bucket][k]-1];
                         min_distance_index = k;
                     }
                     if(max_distance < d[dial_bucket[current_bucket][k]-1])
                         max_distance = d[dial_bucket[current_bucket][k]-1];
                 }
                 first_bucket_distance_label = min_distance;
                
                 dial_bucket[0].push_back(dial_bucket[current_bucket][min_distance_index]);
                 dial_bucket[current_bucket].erase(dial_bucket[current_bucket].begin()+min_distance_index);
                 int null_bucket_index = M;
               
                 for(int i = 0; i <= current_bucket; i++){
                     bucket_vaule_lowbound[i] = first_bucket_distance_label + pow(2,i-1);
                     if( bucket_vaule_lowbound[i] >= bucket_vaule_lowbound[current_bucket+1]){
                         null_bucket_index = i;
                         break;
                     }
                 }
                 for(int j=dial_bucket[current_bucket].size()-1; j>=0; j--){
                    
                     for(int k = 0; k < dial_bucket.size()-1; k++){
                         if(bucket_vaule_lowbound[k] <= d[dial_bucket[current_bucket][j]-1] & d[dial_bucket[current_bucket][j]-1] < bucket_vaule_lowbound[k+1]){
                             mark[dial_bucket[current_bucket][j]-1] = k;
                             break;
                         }
                     }
                     if(d[dial_bucket[current_bucket][j]-1] > bucket_vaule_lowbound[dial_bucket.size()-1]){
                         mark[dial_bucket[current_bucket][j]-1] = dial_bucket.size()-1;
                     }
                     if(mark[dial_bucket[current_bucket][j]-1] != current_bucket){
                         dial_bucket[mark[dial_bucket[current_bucket][j]-1]].push_back(dial_bucket[current_bucket][j]);
                         dial_bucket[current_bucket].erase(dial_bucket[current_bucket].begin()+j);
                     }
                 }
                 if(null_bucket_index != M){
                     for(int j = current_bucket; j>= null_bucket_index; j--){
                         dial_bucket.erase(dial_bucket.begin()+j);
                         
                     }
                     for(int j = 0; j<node_quantity; j++){
                         if(mark[j] >= null_bucket_index & mark[j]!= M){
                             mark[j] = mark[j] - (current_bucket - null_bucket_index + 1);
                         }
                     }
                     for(int j = null_bucket_index; j<dial_bucket.size(); j++){
                         bucket_vaule_lowbound[j] = bucket_vaule_lowbound[j+(current_bucket - null_bucket_index + 1)];
                     }
                 }
                 current_bucket = 0 ;
             }
         }
     }
     return;
 }

 coded by Yi-Jing Wang, ID: r36111193, email: sandy19980920@gmail.com
 date: 2023.06.13
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <ctime>
#include <queue>
#include <cstdlib>
#include <algorithm>
#include <math.h>

// Settings
using namespace std;
string filename ;
int source = 0;
int sink = 0;
string line; 
string _problem;
string gar;
char row_label;
int node_quantity =0;
int arc_quantity =0;
int **_array;
int aa;
int pp;
int *point;
int M = 99999999;
priority_queue<vector<int>, vector<vector<int> >, greater<vector<int> > > pq;
vector<int> temp_pq;
int num_nontrivial_triple_comparisons;

clock_t start_timer;

int *d;
int *pred;


vector<int> H;
//dial
vector<vector<int> > dial_bucket;
int C = 0;
int unlimited_index;
int current_bucket;
int deleted_node;
//Radix
vector<int> unlimited_bucket;
int *mark;
int *bucket_vaule_lowbound;
list<int> LIST; //BF_FIFO

fstream myFile;
void readFile();
void dial();
void print_out_path();

int main(int argc, char** argv) {
    int sum_d = 0;
    filename = argv[1];
    int test_times = atoi(argv[2]);
    float process_time = 0 ;
    myFile.open(filename);
    readFile();
    int counter = 0;
    start_timer = clock();
    int tet = 0;


    if(test_times <= 1){
        do{
            num_nontrivial_triple_comparisons = 0;
            sum_d = 0;
            for (int i = 0; i<node_quantity; i++){
                if(point[i] != point[i+1]){
                    source = i+1;
                    dial();
                    /*
                    for (int j = 0 ; j<node_quantity ; j++){
                        if(d[j] != M){
                            sum_d += d[j];
                        }
                    }
                    */
                }
            }
            process_time = float (clock() - start_timer);
            counter++;
        }while(process_time/counter <= 0);
    }
    //print_out_path();
    //cout<<"Sum of distances: " << sum_d<<endl;
    cout
    <<filename
    <<"\t Sum of num_nontrivial_triple_comparisons: \t" << num_nontrivial_triple_comparisons
    <<"\t Running time of SP computation (ms/run): \t" << process_time/counter
    <<endl;

    return 0;
}

void readFile(){


    while (myFile.get(row_label)) {
        if(row_label == 'c'){
            getline(myFile, line);
        }
        else if (row_label == 't'){
            myFile >> _problem;

        }
        else if(row_label == 'p'){
            myFile>>gar >> node_quantity >> arc_quantity;
            point = new int[node_quantity+1];
            _array = new int*[arc_quantity];
            aa = 0;
            pp = 0;
            temp_pq.resize(3);

        }
        else if(row_label == 'n'){
            getline(myFile, line);
        }
        else if(row_label == 'a'){
            myFile >> temp_pq[0] >> temp_pq[1] >> temp_pq[2];
            pq.push(temp_pq);
        }
    }
    while (!pq.empty()){
        _array[aa] = new int[3];
        auto now = pq.top();
        pq.pop();
        _array[aa][0] = now[0];
        _array[aa][1] = now[1];
        _array[aa][2] = now[2];
        for(int i = pp; i<_array[aa][0]; i++){
            point[i] = aa;
        }
        pp = _array[aa][0];
        if(_array[aa][2] > C){
            C = _array[aa][2];
        }
        aa++;
    }


    //forward star
    for(int i = _array[arc_quantity-1][0]; i <= node_quantity;i++){
        point[i] = arc_quantity;
    }
    vector<int>().swap(temp_pq); //release memory
    priority_queue<vector<int>, vector<vector<int> >, greater<vector<int> > >().swap(pq);
    //Close file
    myFile.close();
    return;
}



void print_out_path(){
    for (int i = 1; i<=node_quantity; i++){
        if(i != source){
            cout<< source <<"->"<<i<<": ";

            if(pred[i-1] == 0){
                cout<< "[can not reach]"<<endl;
            }
            else{
                cout<<"["<<d[i-1]<<"] "<< i <<"<-";
                int pass_node = i ;
                while(pred[pass_node-1] != source){
                    cout<< pred[pass_node-1] << "<-";
                    pass_node = pred[pass_node-1];
                }
                cout<<source<<endl;
            }
        }
    }
}

void dial(){
    //Initialize

    d = new int[node_quantity];
    pred = new int[node_quantity];
    mark = new int[node_quantity];
    bucket_vaule_lowbound = new int[node_quantity];
    int num_bucket = ceil(log((node_quantity-1)*C)/log(2));
    dial_bucket.resize(ceil(log((node_quantity-1)*C)/log(2)));
    int max_distance;
    int min_distance;
    int min_distance_index;
    int first_bucket_distance_label = 0;
    current_bucket = 0;
    for(int i= 0 ; i<node_quantity ;i++){
        d[i] = M;
        pred[i] = 0;
        mark[i] = M;
        bucket_vaule_lowbound[i] = first_bucket_distance_label + pow(2,i-1);
    }
    dial_bucket[0].push_back(source);
    d[source-1] = 0;
    while(!(current_bucket == dial_bucket.size()-1 && dial_bucket[current_bucket].empty())){
        if(dial_bucket[current_bucket].size() == 1  || (!dial_bucket[0].empty()) ){
            deleted_node = dial_bucket[current_bucket][0];
            dial_bucket[current_bucket].erase(dial_bucket[current_bucket].begin());
            for(int i = point[deleted_node-1]; i < point[deleted_node]; i++){
                num_nontrivial_triple_comparisons++;
                if(d[_array[i][1]-1] > d[deleted_node-1] + _array[i][2] ){
                    if(mark[_array[i][1]-1] != M){
                        dial_bucket[mark[_array[i][1]-1]].erase(
                            find(dial_bucket[mark[_array[i][1]-1]].begin(),dial_bucket[mark[_array[i][1]-1]].end(),_array[i][1])
                        );
                    }
                    d[_array[i][1]-1] = d[deleted_node-1]+ _array[i][2];
                    pred[_array[i][1]-1] = deleted_node;
                    for(int j = 0; j < dial_bucket.size()-1; j++){
                        if(bucket_vaule_lowbound[j] <= d[_array[i][1]-1] & d[_array[i][1]-1] < bucket_vaule_lowbound[j+1]){
                            mark[_array[i][1]-1] = j;
                            break;
                        }
                    }
                    if(d[_array[i][1]-1] > bucket_vaule_lowbound[dial_bucket.size()-1]){
                        mark[_array[i][1]-1] = dial_bucket.size()-1;
                    }
                    dial_bucket[mark[_array[i][1]-1]].push_back(_array[i][1]);
                }
            }
        }
        else{
            while(dial_bucket[current_bucket].empty() & current_bucket < dial_bucket.size()-1){
                current_bucket++;
            }
            if(dial_bucket[current_bucket].size() > 1 ){
                min_distance = d[dial_bucket[current_bucket][0]-1];
                max_distance = d[dial_bucket[current_bucket][0]-1];
                min_distance_index = 0;
                for(int k=1; k<dial_bucket[current_bucket].size(); k++){
                    if(min_distance > d[dial_bucket[current_bucket][k]-1]){
                        min_distance = d[dial_bucket[current_bucket][k]-1];
                        min_distance_index = k;
                    }
                    if(max_distance < d[dial_bucket[current_bucket][k]-1])
                        max_distance = d[dial_bucket[current_bucket][k]-1];
                }
                first_bucket_distance_label = min_distance;
               
                dial_bucket[0].push_back(dial_bucket[current_bucket][min_distance_index]);
                dial_bucket[current_bucket].erase(dial_bucket[current_bucket].begin()+min_distance_index);
                int null_bucket_index = M;
              
                for(int i = 0; i <= current_bucket; i++){
                    bucket_vaule_lowbound[i] = first_bucket_distance_label + pow(2,i-1);
                    if( bucket_vaule_lowbound[i] >= bucket_vaule_lowbound[current_bucket+1]){
                        null_bucket_index = i;
                        break;
                    }
                }
                for(int j=dial_bucket[current_bucket].size()-1; j>=0; j--){
                   
                    for(int k = 0; k < dial_bucket.size()-1; k++){
                        if(bucket_vaule_lowbound[k] <= d[dial_bucket[current_bucket][j]-1] & d[dial_bucket[current_bucket][j]-1] < bucket_vaule_lowbound[k+1]){
                            mark[dial_bucket[current_bucket][j]-1] = k;
                            break;
                        }
                    }
                    if(d[dial_bucket[current_bucket][j]-1] > bucket_vaule_lowbound[dial_bucket.size()-1]){
                        mark[dial_bucket[current_bucket][j]-1] = dial_bucket.size()-1;
                    }
                    if(mark[dial_bucket[current_bucket][j]-1] != current_bucket){
                        dial_bucket[mark[dial_bucket[current_bucket][j]-1]].push_back(dial_bucket[current_bucket][j]);
                        dial_bucket[current_bucket].erase(dial_bucket[current_bucket].begin()+j);
                    }
                }
                if(null_bucket_index != M){
                    for(int j = current_bucket; j>= null_bucket_index; j--){
                        dial_bucket.erase(dial_bucket.begin()+j);
                        
                    }
                    for(int j = 0; j<node_quantity; j++){
                        if(mark[j] >= null_bucket_index & mark[j]!= M){
                            mark[j] = mark[j] - (current_bucket - null_bucket_index + 1);
                        }
                    }
                    for(int j = null_bucket_index; j<dial_bucket.size(); j++){ 
                        bucket_vaule_lowbound[j] = bucket_vaule_lowbound[j+(current_bucket - null_bucket_index + 1)];
                    }
                }
                current_bucket = 0 ;
            }
        }
    }
    return;
}

