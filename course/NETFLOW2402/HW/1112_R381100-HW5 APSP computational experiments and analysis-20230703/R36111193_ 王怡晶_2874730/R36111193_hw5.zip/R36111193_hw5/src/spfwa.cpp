
/*
 This code can be compiled and run ok.
 
 
 compile:
     visual studio code

 pseudo-code:
 void FWA(){
     FWA_d = new int*[node_quantity];
     for(int i = 0; i<node_quantity; i++){
         FWA_d[i] = new int[node_quantity];
         for(int j = 0; j<node_quantity; j++){
             FWA_d[i][j] = M;
         }
         for(int k = point[i]; k<point[i+1]; k++){
             FWA_d[i][_array[k][1]-1] = _array[k][2];
         }
     }

     for(int k = 0; k<node_quantity; k++){
         for(int i = 0; i<node_quantity; i++){
             if(FWA_d[i][k] != M & i != k){
                 for(int j = 0; j<node_quantity; j++){
                     if(i != j & j != k & FWA_d[k][j] != M){
                         num_nontrivial_triple_comparisons++;
                         if(FWA_d[i][j] > FWA_d[i][k] + FWA_d[k][j]){
                             FWA_d[i][j] = FWA_d[i][k] + FWA_d[k][j];
                         }
                     }
                 }
             }
         }
     }

     return;
 }
 
 coded by Yi-Jing Wang, ID: r36111193, email: sandy19980920@gmail.com
 date: 2023.06.13

*/

#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <ctime>
#include <queue>
#include <cstdlib>
#include <algorithm>
#include <math.h>

// Settings
using namespace std;
string filename ;
int source = 0;
int sink = 0;
string line;
string _problem;
string gar;
char row_label;
int node_quantity =0;
int arc_quantity =0; 
int **_array;
int aa;
int pp;
int *point; 
int M = 999999999;
priority_queue<vector<int>, vector<vector<int> >, greater<vector<int> > > pq;
vector<int> temp_pq;
long long num_nontrivial_triple_comparisons;
clock_t start_timer;
fstream myFile;


int *d; 
int *pred; 
int **FWA_d; 
vector<int> H; 
int C = 0;



void readFile();
void print_out_path();
void FWA();

int main(int argc, char** argv) {
    int sum_d = 0;
    filename = argv[1];
    int test_times = atoi(argv[2]);
    float process_time = 0 ;
    myFile.open(filename);
    readFile();
    int counter = 0;
    start_timer = clock();

    if(test_times <= 1){
        do{
            num_nontrivial_triple_comparisons = 0;
            FWA();
            process_time = float (clock() - start_timer);
            counter++;
        }while(process_time/counter <= 0);
    }
    else{
    }

    /*
    for(int i = 0; i<node_quantity; i++){
        for(int j = 0; j<node_quantity; j++){
            if(FWA_d[i][j] != M){
                sum_d += FWA_d[i][j];
            }
        }
    }
    cout<<"Sum of distances: " << sum_d<<endl;
    */

    cout
    <<filename
    <<"\t Sum of num_nontrivial_triple_comparisons: \t" << num_nontrivial_triple_comparisons
    <<"\t Running time of SP computation (ms/run): \t" << process_time/counter
    <<endl;

    return 0;
}

void readFile(){

  
    while (myFile.get(row_label)) {
        if(row_label == 'c'){
            getline(myFile, line);
        }
        else if (row_label == 't'){
            myFile >> _problem;

        }
        else if(row_label == 'p'){
            myFile>>gar >> node_quantity >> arc_quantity;
            point = new int[node_quantity+1];
            _array = new int*[arc_quantity];
            aa = 0;
            pp = 0;
            temp_pq.resize(3);

        }
        else if(row_label == 'n'){
            getline(myFile, line);
        }
        else if(row_label == 'a'){
            myFile >> temp_pq[0] >> temp_pq[1] >> temp_pq[2];
            pq.push(temp_pq);
        }
    }
    while (!pq.empty()){
        _array[aa] = new int[3];
        auto now = pq.top();
        pq.pop();
        _array[aa][0] = now[0];
        _array[aa][1] = now[1];
        _array[aa][2] = now[2];
        for(int i = pp; i<_array[aa][0]; i++){
            point[i] = aa;
        }
        pp = _array[aa][0];
        if(_array[aa][2] > C){
            C = _array[aa][2];
        }
        aa++;
    }


    for(int i = _array[arc_quantity-1][0]; i <= node_quantity;i++){
        point[i] = arc_quantity;
    }
    vector<int>().swap(temp_pq);
    priority_queue<vector<int>, vector<vector<int> >, greater<vector<int> > >().swap(pq);
    myFile.close();
    return;
}


void FWA(){
    FWA_d = new int*[node_quantity];
    for(int i = 0; i<node_quantity; i++){
        FWA_d[i] = new int[node_quantity];
        for(int j = 0; j<node_quantity; j++){
            FWA_d[i][j] = M;
        }
        for(int k = point[i]; k<point[i+1]; k++){
            FWA_d[i][_array[k][1]-1] = _array[k][2];
        }
    }

    for(int k = 0; k<node_quantity; k++){
        for(int i = 0; i<node_quantity; i++){
            if(FWA_d[i][k] != M & i != k){
                for(int j = 0; j<node_quantity; j++){
                    if(i != j & j != k & FWA_d[k][j] != M){
                        num_nontrivial_triple_comparisons++;
                        if(FWA_d[i][j] > FWA_d[i][k] + FWA_d[k][j]){
                            FWA_d[i][j] = FWA_d[i][k] + FWA_d[k][j];
                        }
                    }
                }
            }
        }
    }

    return;

}

//void print_out_path(){
//    for (int i = 1; i<=node_quantity; i++){
//        if(i != source){
//            cout<< source <<"->"<<i<<": ";
//
//            if(pred[i-1] == 0){
//                cout<< "[can not reach]"<<endl;
//            }
//            else{
//                cout<<"["<<d[i-1]<<"] "<< i <<"<-";
//                int pass_node = i ;
//                while(pred[pass_node-1] != source){
//                    cout<< pred[pass_node-1] << "<-";
//                    pass_node = pred[pass_node-1];
//                }
//                cout<<source<<endl;
//            }
//        }
//    }
//}

