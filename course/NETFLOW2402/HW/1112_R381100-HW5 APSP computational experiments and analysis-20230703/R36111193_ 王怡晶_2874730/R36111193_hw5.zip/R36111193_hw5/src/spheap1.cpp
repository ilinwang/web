/*
 This code can be compiled and run ok.
 
 
 compile:
     visual studio code

 pseudo-code:

 void heap(){
     
     
     H.resize(1);
     d = new int[node_quantity];
     pred = new int[node_quantity];
     for(int i= 0 ; i<node_quantity ;i++){
         d[i] = M;
         pred[i] = 0;
     }
     d[source-1] = 0;
     _delete = 0;
     H.push_back(source);

     while(H.size() != 1){

         _delete = H[1];
         H[1] = H[H.size()-1];
         H.pop_back();
         minHeapify(1,H.size());
         for(int i = point[_delete-1]; i < point[_delete]; i++){
             num_nontrivial_triple_comparisons++;
             if( _array[i][2]+d[_delete-1] < d[ _array[i][1]-1]){
                 if(d[ _array[i][1]-1] == M){
                     H.push_back( _array[i][1]);
                     decrease(H.size()-1, _array[i][2]+d[_delete-1]);
                 }
                 else{
                     for(int j = 1; j<H.size(); j++){
                         if( _array[i][1] == H[j]){
                             decrease(j, _array[i][2]+d[_delete-1]);
                             break;
                         }
                     }
                 }
                 pred[ _array[i][1]-1] = _delete;
             }
         }
     }

     return;
 }
 
 coded by Yi-Jing Wang, ID: r36111193, email: sandy19980920@gmail.com
 date: 2023.06.13

*/

#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <ctime>
#include <queue>
#include <cstdlib>
#include <algorithm>
#include <math.h>

using namespace std;


//readFile
string filename ;
int source = 0;
string line;
string _problem;
string gar;
char _test;
int node_quantity =0;
int arc_quantity =0;
int ** _array;
int aa;
int pp;
int *point;
int M = 99999999;
priority_queue<vector<int>, vector<vector<int> >, greater<vector<int> > > pq;
vector<int> temp_pq;
int num_nontrivial_triple_comparisons;
fstream infile;
clock_t start_timer;



//Heap
vector<int> H;
int *d;
int *pred;
int C = 0;
int _delete;
void readFile();
void minHeapify(int,int);
void decrease(int,int);
void heap();
void print_out_path();



int main(int argc, char** argv) {
    int sum_d = 0;
    filename = argv[1];
    int test_times = atoi(argv[2]);
    float process_time = 0 ;
    infile.open(filename);
    readFile();
    int counter = 0;
    start_timer = clock();
    int tet = 0;


    if(test_times <= 1){
        do{
            num_nontrivial_triple_comparisons = 0;
            sum_d = 0;
            for (int i = 0; i<node_quantity; i++){
                if(point[i] != point[i+1]){
                    source = i+1;
                    heap();
                    /*
                    for (int j = 0 ; j<node_quantity ; j++){
                        if(d[j] != M){
                            sum_d += d[j];
                        }
                    }
                    */
                }
            }
            process_time = float (clock() - start_timer);
            counter++;
        }while(process_time/counter <= 0);
    }
    //print_out_path();
    //cout<<"Sum of distances: " << sum_d<<endl;
    cout
    <<filename
    <<"\t Sum of num_nontrivial_triple_comparisons: \t" << num_nontrivial_triple_comparisons
    <<"\t Running time of SP computation (ms/run): \t" << process_time/counter
    <<endl;

    return 0;
}

void readFile(){

    while (infile.get(_test)) {
        if(_test == 'c'){
            getline(infile, line);
        }
        else if (_test == 't'){
            infile >> _problem;

        }
        else if(_test == 'p'){
            infile>>gar >> node_quantity >> arc_quantity;
            point = new int[node_quantity+1];
            _array = new int*[arc_quantity];
            aa = 0;
            pp = 0;
            temp_pq.resize(3);

        }
        else if(_test == 'n'){
            getline(infile, line);
        }
        else if(_test == 'a'){
            infile >> temp_pq[0] >> temp_pq[1] >> temp_pq[2];
            pq.push(temp_pq);
        }
    }
    while (!pq.empty()){
        _array[aa] = new int[3];
        auto now = pq.top();
        pq.pop();
        _array[aa][0] = now[0];
        _array[aa][1] = now[1];
        _array[aa][2] = now[2];
        for(int i = pp; i< _array[aa][0]; i++){
            point[i] = aa;
        }
        pp =  _array[aa][0];
        if( _array[aa][2] > C){
            C =  _array[aa][2];
        }
        aa++;
    }


    for(int i =  _array[arc_quantity-1][0]; i <= node_quantity;i++){
        point[i] = arc_quantity;
    }
    vector<int>().swap(temp_pq);
    priority_queue<vector<int>, vector<vector<int> >, greater<vector<int> > >().swap(pq);
    infile.close();
    return;
}

void minHeapify(int quantity,int length){

    int left_child = 2*quantity;
    int right_child = 2*quantity+1;
    int small;

    if ( left_child <= length && d[H[left_child]-1] <= d[H[quantity]-1])
        small= left_child;
    else
        small= quantity;

    if (right_child <= length && d[H[right_child]-1] <= d[H[small]-1])
        small= right_child;

    if (small!= quantity) {
        swap(H[small], H[quantity]);
        minHeapify(small,length);
    }
}

void decrease(int quantity, int new_d){

    d[H[quantity]-1] = new_d;
    while (quantity > 1 && d[H[quantity/2]-1] > d[H[quantity]-1]) {
        swap(H[quantity], H[quantity/2]);
        quantity = quantity/2;
    }

}

void heap(){
    
    
    H.resize(1);
    d = new int[node_quantity];
    pred = new int[node_quantity];
    for(int i= 0 ; i<node_quantity ;i++){
        d[i] = M;
        pred[i] = 0;
    }
    d[source-1] = 0;
    _delete = 0;
    H.push_back(source);

    while(H.size() != 1){

        _delete = H[1];
        H[1] = H[H.size()-1];
        H.pop_back();
        minHeapify(1,H.size());
        for(int i = point[_delete-1]; i < point[_delete]; i++){
            num_nontrivial_triple_comparisons++;
            if( _array[i][2]+d[_delete-1] < d[ _array[i][1]-1]){
                if(d[ _array[i][1]-1] == M){
                    H.push_back( _array[i][1]);
                    decrease(H.size()-1, _array[i][2]+d[_delete-1]);
                }
                else{
                    for(int j = 1; j<H.size(); j++){
                        if( _array[i][1] == H[j]){
                            decrease(j, _array[i][2]+d[_delete-1]);
                            break;
                        }
                    }
                }
                pred[ _array[i][1]-1] = _delete;
            }
        }
    }

    return;
}

//void print_out_path(){
//    for (int i = 1; i<=node_quantity; i++){
//        if(i != source){
//            cout<< source <<"->"<<i<<": ";
//
//            if(pred[i-1] == 0){
//                cout<< "[can not reach]"<<endl;
//            }
//            else{
//                cout<<"["<<d[i-1]<<"] "<< i <<"<-";
//                int pass_node = i ;
//                while(pred[pass_node-1] != source){
//                    cout<< pred[pass_node-1] << "<-";
//                    pass_node = pred[pass_node-1];
//                }
//                cout<<source<<endl;
//            }
//        }
//    }
//}
