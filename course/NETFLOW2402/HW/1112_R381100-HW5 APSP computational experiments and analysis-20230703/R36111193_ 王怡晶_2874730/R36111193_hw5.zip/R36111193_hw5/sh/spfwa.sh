#!/bin/bash

cd ..
for ((i=1; i<=144; i++)); do
	./bin/spfwa ./inputs/$i.txt 1 >> ./reports/results/spfwa.xls
	echo "$i finished."
done
