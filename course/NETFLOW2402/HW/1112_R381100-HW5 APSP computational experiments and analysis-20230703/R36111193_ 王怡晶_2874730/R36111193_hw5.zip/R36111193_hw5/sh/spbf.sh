#!/bin/bash

cd ..
for ((i=1; i<=144; i++)); do
	./bin/spbf ./inputs/$i.txt 1 >> ./reports/results/spbf.xls
	echo "$i finished."
done
