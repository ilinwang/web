#!/bin/bash

cd ..
for ((i=1; i<=144; i++)); do
	./bin/spbfp ./inputs/$i.txt 1 >> ./reports/results/spbfp.xls
	echo "$i finished."
done
