#!/bin/bash

cd ..
for ((i=1; i<=144; i++)); do
	./bin/spheap1 ./inputs/$i.txt 1 >> ./reports/results/spheap.xls
	echo "$i finished."
done
