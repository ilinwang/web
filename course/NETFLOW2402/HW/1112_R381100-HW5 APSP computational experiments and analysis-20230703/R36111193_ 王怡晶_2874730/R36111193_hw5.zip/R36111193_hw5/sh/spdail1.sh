#!/bin/bash

cd ..
for ((i=1; i<=144; i++)); do
	./bin/spdial1 ./inputs/$i.txt 1 >> ./reports/results/spdial.xls
	echo "$i finished."
done
