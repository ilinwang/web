#!/bin/bash

cd ..
for ((i=1; i<=144; i++)); do
	./bin/spfwg ./inputs/$i.txt 1 >> ./reports/results/spfwg.xls
	echo "$i finished."
done
