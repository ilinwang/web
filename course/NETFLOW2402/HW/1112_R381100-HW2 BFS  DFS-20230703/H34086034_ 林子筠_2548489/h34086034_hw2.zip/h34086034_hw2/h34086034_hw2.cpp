/*
    This code can be compiled, run ok for test1, test2 will have bad alloc error.

    purpose:
        Read test1.sp file, print out all the reachable nodes from s by BFS labeling order and the distance label,
		print out all the paths and lengths from s to t, based on the idea of DFS; mark shortest path with "*".

    usage:
        h34086034_hw2  no output file  text1.sp

    input file:
        text1.sp

    output file:
        no

    compile:
        g++ -o h34086034_hw2 h34086034_hw2.cpp

    pseudocode:
    void DFS(int u, vector<bool> visited_d, vector<int> path_node)
        visited_d[u] = true;
        path_node[path_index] = u;
        path_index++;

        if u == t then
            for i = 0 to path_index-1
                store path from s to t into vector (to print out)
                path_str.push_back(vector<int>());
                path_str[path_count].push_back(path_node[i]);
            path_count += 1; //get 1 path
        else u != t
            for i = 0 to m-1
                if tail[i] == u and !visited_d[head[i]] then
                    DFS(head[i], visited_d, path_node); //recursive
        path_index--;
        visited_d[u] = false;
    ------
    read m,n (hw1)
    ------
    read tail and head
    ------
    input s and t
    ------
    //BFS
    q.push(s);
    visited_b[s] = true;
    distance[s] = 0;

    while q is not empty
        cur = q.front(); //current node
        q.pop();
        order.push_back(cur);

        for i = 0 to m-1
            if tail[i] == cur and !visited_b[head[i]] then
                q.push(head[i]);
                visited_b[head[i]] = true;
                distance[head[i]] = distance[cur] + 1; // distance from s to head[i]
    ------
    //DFS
    call DFS(s, visited_d, path_node) function;

    if there exists path from s to t then
        min_path = path_str[0].size()-1; //set initial min path
        for i = 1 to path_count-1
            if path_str[i].size()-1 < min_path then
                min_path = path_str[i].size()-1; //update min path

        for i = 0 to path_count-1
            if is min path, then
                print "*[" path_str[i].size()-1 "]: ";
            else is not min path, then
                print "[" path_str[i].size()-1 "]: ";

            for j = 0 to path_str[i].size()-1
                if j is not the last node in the path
                    print path_str[i][j] "-";
                else j is the last node in the path
                    print path_str[i][j];

    else there is no path from s to t then
        print "No path from " s " to " t;

    coded by Zi-Yun Lin, ID: H34086034, email: celine20001024@gmail.com
    date: 2023.03.12
*/

#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<queue>
using namespace std;

int n = 0, m = 0, s = 1, t = 1;

//forward star
vector<int> tail;
vector<int> head;

int path_index = 0; //index of path node
int path_count = 0; //total # paths from s to t
vector<vector<int>> path_str; //store all paths from s to t

void DFS(int u, vector<bool> visited_d, vector<int> path_node){
    visited_d[u] = true;
    path_node[path_index] = u;
    path_index++;

    if(u == t){
        path_str.push_back(vector<int>());
        for(int i = 0; i < path_index; i++){
            path_str[path_count].push_back(path_node[i]);
        }
        path_count += 1;
    }
    else{
        for(int i = 0; i < m; i++){
            if(tail[i] == u && !visited_d[head[i]]){
                DFS(head[i], visited_d, path_node);
    }}}

    path_index--;
    visited_d[u] = false;
}

int main(){

	string fname; //file name

	cout << "Please input network filename: ";
	cin  >> fname;
	cout << endl;

	ifstream file; //read file
	file.open(fname.c_str());

	string str, temp; //str: each line in file, temp: temporary
    int x = 0; //x is used for substr()

	while(getline(file,str)){
        //read m
        if(str[0] == 'p'){
		    for (int i = 0; i < str.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for (int i = 0; i < temp.size(); i++){
                if (isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            m = stoi(temp.substr(x+1));
        }
        //read n
        if(str[0] == 'n'){
		    n = stoi(str.substr(2));
		    break;
        }
    }

    while(getline(file,str)){
		if(str[0] == 'a'){
            //split str for tail
            for(int i = 0; i < str.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            tail.push_back(stoi(temp.substr(0,x)));
            //split str for head
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            head.push_back(stoi(temp.substr(0,x)));
    }}

    /*forward star point
    vector<int> point(n+1);
    point[0] = 1; //node 1
    point[n] = m+1; //node n
    for(int i = n-1; i > 0; i--){
        for(int j = 0; j < m; j++){
            if(i+1 == tail[j]){
                point[i] = j+1;
                break;
            }
            else{point[i] = point[i+1];}
    }}*/

    cout << "Please input a source node: ";
	cin  >> s;
	while(s > n){
        cout << endl << "!!Warning!!: node " << s << " does not exist." << endl << "Please input a source node: ";
        cin  >> s;
	}

	cout << endl << "Please input a sink node: ";
	cin  >> t;
	while(t > n){
        cout << endl << "!!Warning!!: node " << t << " does not exist." << endl << "Please input a sink node: ";
        cin  >> t;
	}
	cout << endl;

	//BFS
	vector<bool> visited_b(n+1, false);
    vector<int> order;
    vector<int> distance(n+1, 0);
    queue<int> q;

    q.push(s);
    visited_b[s] = true;
    distance[s] = 0;

    while(!q.empty()){
        int cur = q.front(); //current node
        q.pop();
        order.push_back(cur);

        for(int i = 0; i < m; i++){
            if(tail[i] == cur && !visited_b[head[i]]){
                q.push(head[i]);
                visited_b[head[i]] = true;
                distance[head[i]] = distance[cur] + 1;
    }}}

    cout << "BFS: ";
    for(int i = 0; i < order.size(); i++){
        cout << order[i] << "[" << distance[order[i]] << "]" << " ";
    }
    cout << endl;

    //DFS
    vector<bool> visited_d(n+1, false);
    vector<int> path_node(n+1); //store all paths from s to t

    DFS(s, visited_d, path_node);

    cout << s << "->" << t << ": " << path_count << " paths";

    if(path_count != 0){
        int min_path = path_str[0].size()-1;
        for(int i = 1; i < path_count; i++){
            if(path_str[i].size()-1 < min_path){
                min_path = path_str[i].size()-1;
        }}

        for(int i = 0; i < path_count; i++){
            if(path_str[i].size()-1 == min_path){
                cout << endl << "*[" << path_str[i].size()-1 << "]: ";
            }
            else{
                cout << endl << "[" << path_str[i].size()-1 << "]: ";
            }

            for(int j = 0; j < path_str[i].size(); j++){
                if(j != path_str[i].size()-1){
                    cout << path_str[i][j] << "-";
                }
                else{
                    cout << path_str[i][j];
    }}}}
    else{
        cout << endl << "No path from " << s << " to " << t;
    }

	file.close();
	return 0;
}
