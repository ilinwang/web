/*
    This code can be compiled in input test1.sp, but when I run it with input test2.sp,
    it sometimes can't output DFS, such that all the paths from s to t,
    but BFS can still work appropriate under test2.sp.

   Purpose:
     This code can read a network file, source node(s) and sink node(t),
     then print out:
        (1) all the reachable nodes and their distance labels from s by the BFS labeling order.
        (2) all the paths from s to t.

   Usage:
     Firstly, user request to input a filename. If filename is invalid, it will print error message and terminate.
     Secondly, user request to input a source node and sink node. If source node or sink node is invalid, it will print error message and terminate,
     else, it will print out the result of BFS and DFS.

   Input file:
     test1.sp
     test2.sp

   Output files:
     None.

   Compile:
     g++ -o h34091160_hw2 h34091160_hw2.cpp

 Pseudocode:
 (1) BFS
    Begin
      Initialize
      while QUEUE != {} do
      begin
        select a node i in QUEUE;
        find all the admissible arc;
        if node i is incident to an admissible arc(i,j) then
        begin
          mark node j;
          pred(j) := i;
          next := next + 1;
          order(j) := next;
          add node j to QUEUE;
          delete arc(i,j) in admissible arc
        end
        else delete node i from QUEUE
      end
      for i in node
        if i is source node then
        begin
          distance(i) := 0;
          total_num := total_num + 1 {total number of reachable nodes}
        end
        else if ndoe i is marked then
        begin
          total_num := total_num + 1
          while pred(i) != source node then
          begin
            node i := pred(i);
            counter := counter + 1;
          end
          counter := counter + 1;
          distance(i) := counter;
        end
      end
      BFS_order := 1;
      while total_num > 0 then
      begin
        for k in n do
        begin
          if order(i) = BFS_order then print node and its distance label
          break;
        end
        total_num := total_num - 1
      end
    end

 (2) DFS
    Begin
      Initialize
      for i in n do currentArc[i] = 0;
      while STACK != {} do
      begin
        select a node i in STACK;
        if i = sink node do
        begin
          curr := node(i);
          path_num := path_num + 1 {total number of paths}
          save node(i) into path
          while pred(curr) != source node do
          begin
            save pred(curr) into path
            curr := pred(curr);
            path_length := path_length + 1;
          end
          save source node into path
          path length := path_length;
          add path into answer {answer is a stack of paths}
          currentArc(i) := 0;
          pred(i) := 0;
          unmark node i
          delete node i from STACK
        end
        else if currentArc(i) >= outdegree_num(i) then
        begin
          currentArc(i) := 0;
          pred(i) := 0;
          unmark node i
          delete node i from STACK
        end
        else if arc(i,j) is admissible then
        begin
          mark node j
          pred(j) = i;
          add node j to STACK
          currentArc(i) := currentArc(i) + 1;
        end
        else if arc(i,j) isn't admissible then
        begin
          currentArc(i) := currentArc(i) + 1;
          if arc(i,j) is admissible then
          begin
            mark node j
            pred(j) = i;
            add node j to STACK
            currentArc(i) := currentArc(i) + 1;
          end
        end
        else do
        begin
          currentArc(i) := 0;
          pred(i) := 0;
          unmark node i
          delete node i from STACK
        end
      end
      print all the paths from s to t
    end

 (3) main()
   Begin
    Input filename
    Let n=0, m=0
    While reading each line in the file
      Read first word
      If first[0] = 't', then Problem name <- first
      Else if first[0] = 'p', then
      Begin
        Problem type, n, m <- first[1]
      End
      Else if first[0] = 'a', then do
        index+=1
        start_node, end_node, distance <- first
        Add node to the list
    End
    Input source node
    If source node <=0 or source node > n, then print warning message
    Else do
      print BFS
      print DFS
  End

   coded by 李佳哲, ID: h34091160, email: h34091160@gs.ncku.edu.tw
   date: 2023.03.13
*/

#include <queue>
#include <stack>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>

using namespace std;

struct Nodes {  // Define the structure of node
    int node_index = 0;  // record the index of the node
    bool mark = 0;  // 1: marked; 0: unmarked
    int pred = 0;  // record the predecessor of the node
    int order = 0;  // record the (BFS/DFS) order of the node
    int distance_Label = 0;  // record the distance label of the node
};

struct Arcs {  // Define the structure of node
    int arc_index = 0;  // record the index of the arc
    int s = 0;  // record the tail node of the arc
    int t = 0;  // record the head node of the arc
    int distance = 0;  // record the length of the arc
};

struct Paths {  // record the path by DFS
    int length = 0;  // length of the path
    stack<int> path_node;  // record the nodes of the path
    Paths* next;  // connect paths by linked list
};

struct adj_node {  // Define the structure of adjacency list
    int number;  // record the index of the node
    double distance;  // record the arc length between the nodes
    int index;  // record the index of the arc
    adj_node* next;  // using linked list data structure
};

class AdjacencyList {  // Define a class that implement adjacency list
    adj_node* head;
public:
    AdjacencyList() {  // Initialize
        head = nullptr;
    }

    void addNode(int num, int arc_index, int arc_distance) {  // Add node to the adj. list
        adj_node* newNode = new adj_node;
        newNode->number = num;
        newNode->distance = arc_distance;
        newNode->index = arc_index;
        newNode->next = nullptr;

        if (head == nullptr) {
            head = newNode;
        }
        else {
            adj_node* curr = head;
            while (curr->next != nullptr) {
                curr = curr->next;
            }
            curr->next = newNode;
        }
    }

    void printList_indeg(int i){  // print out the adj. list of node i by indegree
        adj_node* curr = head;
        while (curr != nullptr) {
            cout << "arc[" << curr->index << "]: " << curr->number << "-" << i + 1 << " : " << curr->distance << endl;
            curr = curr->next;
        }
    }

    void printList_outdeg(int i){  // print out the adj. list of node i by outdegree
        adj_node* curr = head;
        while (curr != nullptr) {
            cout << "arc[" << curr->index << "]: " << i + 1 << "-" << curr->number << " : " << curr->distance << endl;
            curr = curr->next;
        }
    }
};

void BFS (int source_node, int n, Nodes* node, Arcs* arc, int fs_point[]) {
    // initialize
    queue<int> list;  // record BFS LIST queue
    queue<int> admissible_arc;  // record admissible arcs
    int next = 1;  // next is a counter
    int i = 0;
    int j = 0;

    for(int w=0;w<n;w++){
        node[w].mark = 0;  // unmark all nodes in N
    }

    node[source_node-1].mark = 1;  // mark node s
    node[source_node-1].pred = 0;  // s has no predecessor
    node[source_node-1].order = next;  // order(s)=next
    list.push(source_node);  // LIST = {s}

    // BFS algorithm
    while(list.size() != 0){  // while LIST != {}
        i = list.front();  // select a node i in list

        // Find admissible arc using forward star fs_point[i]
        if(admissible_arc.size() == 0){
            for(int j = fs_point[i-1];j<fs_point[i];j++){
                if(node[i-1].mark == 1 && node[arc[j-1].t-1].mark == 0){  // admissible arc: node i is marked but mode j isn't marked yet
                    admissible_arc.push(node[arc[j-1].t-1].node_index);
                }
            }
        }

        if(admissible_arc.size() > 0){  // if there still have admissible arc
            node[admissible_arc.front()-1].mark = 1;  // Mark node j
            node[admissible_arc.front()-1].pred = i - 1;  // pred(j) = i
            next++;  // next = next + 1
            node[admissible_arc.front()-1].order = next;  // order(j) = next
            list.push(node[admissible_arc.front() -1].node_index);  // Add node j to LIST
            admissible_arc.pop();  // arc(i,j) isn't admissible now
        }
        else{
            list.pop();  // Delete node i from LIST
        }
    }

    // record distance label
    int total_num = 0;  // record the total number of reachable nodes
    for(int k=n-1;k>=0;k--){
        int counter = 0;  // record distance label of node k

        if(node[k].node_index == source_node){
            node[k].distance_Label = 0;  // distance label of source node = 0
            total_num++;
        }
        else if(node[k].mark == 1){  // check whether node is reachable from source node
            total_num++;
            Nodes curr = node[k];
            while (curr.pred != source_node-1) {  // Find the path to source node
                curr = node[curr.pred];
                counter++;  // take a step back and increase the length by one
            }
            counter++;  // take a step back and increase the length by one
            node[k].distance_Label = counter;  // record the distance label
        }
    }

    // print all the reachable nodes and their distance label form s by th BFS labeling order
    int BFS_order = 1;  // start from order = 1
    cout << "\nBFS: ";
    while(total_num > 0){  // total number of reachable nodes > 0
        for(int k=0;k<n;k++){
            if(node[k].order == BFS_order){  // print out nodes in label order
                cout << node[k].node_index << "[" << node[k].distance_Label << "] ";
                BFS_order++;
                break;
            }
        }
        total_num--;
    }
    cout << endl;
}

class DFS_path {  // Define a class of DFS, storing all the paths
    Paths* head;
public:
    DFS_path() {  // Initialize
        head = nullptr;
    }

    void addPath(int len, Paths* p) {  // Add a path to the DFS_path
        Paths* newPath = new Paths;
        newPath->length = len;

        while(p->path_node.size() > 0){
            newPath->path_node.push(p->path_node.top());
            p->path_node.pop();
        }

        if (head == nullptr) {
            head = newPath;
        }
        else {
            Paths* curr = head;
            while (curr->next != nullptr) {
                curr = curr->next;
            }
            curr->next = newPath;
        }
    }

    void printPath(){  // print out all the path by DFS
        // 1. Find the shortest path length
        int sp_length = 10000;
        Paths* current = head;

        while(current != nullptr){
            if(current->length < sp_length){
                sp_length = current->length;
            }
            current = current->next;
        }

        // 2. Print out all the path
        current = head;
        while(current != nullptr){
            // because I save the path's node by stack, and I have already take out all the nodes at recording path into DFS_path, so the order is reverse
            stack<int> reverse_the_path;  // reverse the order
            int first = 1;

            if(current->length == sp_length){  // if path length is equal to shortest path, print out "*" in the front
                cout << "*";
            }
            else{
                cout << " ";
            }
            cout << "[" << current->length << "]: ";  // print out the length of the path
            while(current->path_node.size() > 0){
                reverse_the_path.push(current->path_node.top());  // reverse the order of node
                current->path_node.pop();
            }
            while(reverse_the_path.size() > 0){
                if(first == 1){
                    cout << reverse_the_path.top();  // print the actual order
                    reverse_the_path.pop();
                    first++;
                }
                else{
                    cout << "-" << reverse_the_path.top();  // print the actual order
                    reverse_the_path.pop();
                }
            }
            first = 0;
            current = current->next;
            cout << endl;
        }
    }
};

void DFS (int source_node, int sink_node, int n, Nodes* node, Arcs* arc, int fs_point[], int outdegree_num[]) {
    // Initialized
    stack<int> list;  // record DFS stack
    int i = 0;
    int j = 0;
    int path_num = 0;  // record the total number of path

    for(int w=0;w<n;w++){
        node[w].mark = 0;  // unmark all nodes in N
    }

    node[source_node-1].mark = 1;  // mark node s
    node[source_node-1].pred = 0;  // s has no predecessor
    list.push(source_node);  // LIST = {s}

    int currentArc[n];  // placeholder when one scans through arc list A(i)
    for(int y=0;y<n;y++){  // initialize
        currentArc[y] = 0;
    }
    Paths* head;  // record one path
    DFS_path answer;  // record the DFS solutions

    // DFS algorithm
    while(list.size() != 0){  // While LIST != {}
        i = list.top();  // Select a node i in list

        if(i == sink_node){  // the path is reachable, record the path
            int path_len = 1;  // record the length of path
            path_num++;  // number of paths plus one
            Nodes curr = node[i-1];  // sink node

            head = new Paths;
            head->path_node.push(i);  // save node i into path

            while (curr.pred != source_node-1) {  // Find the path to source node, and record into head
                head->path_node.push(node[curr.pred].node_index);  // save node to the path
                curr = node[curr.pred];
                path_len++;  // length of paths plus one
            }
            head->path_node.push(node[curr.pred].node_index);  // save the last node to the path
            head->length = path_len;  // save the path length

            answer.addPath(head->length, head);  // save the path into answer

            // already check all the arcs, so go back
            currentArc[list.top()-1] = 0;  // reset currentArc[i]
            node[list.top()-1].pred = 0;  // reset node[i].pred
            node[list.top()-1].mark = 0;  // reset node[i].mark
            list.pop();  // Delete node i from LIST

        }
        else if(currentArc[i-1] >= outdegree_num[i-1]){  // go back condition 1: all the arcs have already checked, so go back one step

            currentArc[list.top()-1] = 0;  // reset currentArc[i]
            node[list.top()-1].pred = 0;  // reset node[i].pred
            node[list.top()-1].mark = 0;  // reset node[i].mark
            list.pop();  // Delete node i from LIST

        }
        else if(node[i-1].mark == 1 && node[arc[fs_point[i-1] + currentArc[i-1]-1].t-1].mark == 0){  // keep going when arc(i,j) is admissible
            // Find admissible arc using forward star data structure (fs_point[i])
            node[arc[fs_point[i-1]+currentArc[i-1]-1].t-1].mark = 1;  // Mark node j
            node[arc[fs_point[i-1]+currentArc[i-1]-1].t-1].pred = i - 1;  // pred(j) = i
            list.push(node[arc[fs_point[i-1]+currentArc[i-1]-1].t-1].node_index);  // Add node j to LIST
            currentArc[i-1]++;  // currentArc[i] plus 1
        }
        else if(node[i-1].mark == 1 && node[arc[fs_point[i-1]+currentArc[i-1]-1].t-1].mark == 1){    // when arc(i,j) isn't admissible, scan next arc
            while(currentArc[i-1] + 1 <= outdegree_num[i-1]){  // there still have arc that haven't been gone
                currentArc[i-1]++;
                if(node[i-1].mark == 1 && node[arc[fs_point[i-1] + currentArc[i-1]-1].t-1].mark == 0){  // keep going when arc(i,j) is admissible
                    node[arc[fs_point[i-1]+currentArc[i-1]-1].t-1].mark = 1;  // Mark node j
                    node[arc[fs_point[i-1]+currentArc[i-1]-1].t-1].pred = i - 1;  // pred(j) = i

                    list.push(node[arc[fs_point[i-1]+currentArc[i-1]-1].t-1].node_index);  // Add node j to LIST
                    currentArc[i-1]++;
                    break;
                }
            }
        }
        else{  // Go back condition 2: there is no arc to go, so go back one step
            currentArc[list.top() - 1] = 0;  // reset currentArc[i]
            node[list.top() - 1].pred = 0;  // reset node[i].pred
            node[list.top() - 1].mark = 0;
            list.pop();  // Delete node i from LIST
        }
    }

    // Print the DFS answer
    if(path_num < 2){
        cout << source_node << "->" << sink_node << ": " << path_num << " path" << endl;
    }
    else{
        cout << source_node << "->" << sink_node << ": " << path_num << " paths" << endl;

    }
    answer.printPath();
    cout << endl;
}

int main () {
    string filename;
    cout << "Please input network filename: ";    // user input filename
    getline(cin, filename);
    ifstream file(filename);

    if(!file.is_open()){
        cerr << "Failed to open " << filename << endl;
        return 1;
    }

    string s, first, problem_type, problem_name;
    int n = 0;    // number of nodes
    int m = 0;    // number of arcs
    int start_node = 0;    // starting node of the arc
    int end_node = 0;    // ending node of the arc
    int distance = 0;    // distance of the arc
    int index = 0;    // index of the arc
    bool counter = true;

    Arcs* arc;  // record arcs
    Nodes* node;  // record nodes
    AdjacencyList* adjList_in;  // record adjacency list by indegree
    AdjacencyList* adjList_out;  // record adjacency list by outdegree
    int* outdegree_num;  // record outdegree number of each node

    while (getline(file, s)) {
        istringstream stringfile(s);
        stringfile >> first;    // Read the first word of the line

        if(first[0]=='t'){    // Case 1: When read 't', record title of the problem name
            stringfile >> problem_name;
        }
        else if(first[0]=='p'){    // Case 2: When read 'p', record problem type, # of node and arc
            stringfile >> problem_type >> n >> m;

            // dynamically allocating memory
            outdegree_num = new int[n];
            node = new Nodes[n];
            arc = new Arcs[m];
            adjList_in = new AdjacencyList[n];
            adjList_out = new AdjacencyList[n];

            // save the nodes
            for(int i=0;i<n;i++){
                node[i].node_index = i + 1;
            }
        }
        else if(first[0]=='a'){    // Case 3: When read 'a', record start node, end node and the distance between them
            stringfile >> start_node >> end_node >> distance;

            // save the arc information
            arc[index].arc_index = index + 1;
            arc[index].s = start_node;
            arc[index].t = end_node;
            arc[index].distance = distance;

            // check the outdegree number of each node
            if (counter){
                for(int i=0;i<n;i++){
                    outdegree_num[i] = 0;  // Initialized
                }
                counter = 0;
                outdegree_num[start_node-1]++;
            }
            else{   // Record outdegree number
                outdegree_num[start_node-1]++;
            }

            // Add into adjacency list
            adjList_in[end_node-1].addNode(arc[index].s, arc[index].arc_index, arc[index].distance);
            adjList_out[start_node-1].addNode(arc[index].t, arc[index].arc_index, arc[index].distance);

            index++;
        }
    }


    //using data structure forward star
    int fs_point[n];  // point[i] in forward star
    fs_point[0] = 1;

    for(int i=1;i<n;i++){  // record forward star
        fs_point[i] = fs_point[i-1] + outdegree_num[i-1];
    }
    
    int source_node = 0;
    int sink_node = 0;
    cout << "Please input a source node: ";    // user input source node
    cin >> source_node;
    cout << "Please input a sink node: ";    // user input sink node
    cin >> sink_node;

    if(source_node <= 0 || source_node > n){    // print warning message
        cout << "\n!!Warning!!: Node " << source_node << " does not exist." << endl;
    }
    else if(sink_node <= 0 || sink_node > n){
        cout << "\n!!Warning!!: Node " << sink_node << " does not exist." << endl;
    }
    else {
        BFS(source_node, n, node, arc, fs_point);  // do the BFS
        DFS(source_node, sink_node, n, node, arc, fs_point, outdegree_num);  // do the DFS
    }

    delete[] node;   // Clear the memory
    delete[] arc;
    delete[] outdegree_num;
    delete[] adjList_in;
    delete[] adjList_out;

    file.close();    // Close file

    return 0;
}
