/*
    This code can be compiled and run ok.

    This code is to read a network and output reachable node, path and shortest path base on source node and sink node.

    usage:
        you may input a file which contains a network data and enter a source node, 
        the code will output as follows.
        Output:
    1. reachable nodes from s by the BFS labeling order
    2. path from source node to sink node
    3. shortest path with '*'

    input file:
        test1.sp
        test2.sp
        
    output files:
        No output file
        
    compile:
        g++ -o ./nf6101036_hw2.cpp

    pseudocode:

    tokenize(str,del,out)
    --------
    out = split(str,del)
    return out
    --------

    printpath(vec,shortest)
    --------
    if vec.size() == shortest 
        print('*')
    print(vec)
    --------

    int isNotVisited(x, vec)
    --------
    if x in vec
        return 1
    else
        return 0
    --------

    DFS(vec, src, dst, sh_path)
    --------
    vector<int> S
    vecror<int> index[vec.size] = {0}
    s.push_back(src)
    cur_node = src
    while ( S is not empty):
        next_node = vec[src]
        if next_node == Null:
            index[S.last] = 0
            S.pop_back()
            cur_node = S.last

        if next_node not in S:
            s.push_back(next_node)
            cur_node = next_node
    
        if S.last = dst
            print(S)
    --------

    find_idx(vec,i)
    --------
    if i in vec
        return 1
    return 0
    --------


    --------
    input file name
    read in file

    while(get each line)
    {

        if first_letter = 'p'
        {
            get num_of_node, num_of_arc
        }

        built a dynamic array base on num_of_node
        built a dynamic array base on num_of_arc

        if first_letter = 'a'
        {
            get from_node, to_node, arc_length 
        }
    }

    input source node
    input sink node

    run BFS to get reachable node
    run DFS to get all the path from source node to sink node
    ------

    coded by Chun-An Chen, ID: nf6101036, email: nf6101036@gs.ncku.edu.tw
    date: 2023.03.17
*/
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <map>
#include <cstring>
#include <array>
#include <stdio.h>
#include <queue>
#include <stack>
#include <cstdio>

using namespace std;

void tokenize(string const &str, const char* delim,
            vector<string> &out)
{
    /*tokenize will read in a string, seperate base on delimiter and output a vector of seperated string*/
    char *token = strtok(const_cast<char*>(str.c_str()), delim);
    while (token != nullptr)
    {
        out.push_back(string(token));
        token = strtok(nullptr, delim);
    }
}

void printpath(vector<int>& path,int sh_path)
{

    int size = path.size();
    int arc_num = size-1;
    if(arc_num == sh_path)
    {
        printf("*");
    }

    printf("[%i]:",arc_num);
    for (int i = 0; i < size-1; i++)
    {
        printf("%i-",path[i]);
    }
    printf("%i\n",path[size-1]);
    
}
 
// utility function to check if current
// vertex is already present in path
int isNotVisited(int x, vector<int>& path)
{
    int size = path.size();
    for (int i = 0; i < size; i++)
        if (path[i] == x)
            return 0;//is visited
    return 1;//is not visited
}

// utility function for finding paths in graph
// from source to destination

int find_idx(vector<int> vec, int ii){

    for (int i = 0; i < vec.size(); i++){
        if (vec[i] == ii){
            return 1;
        }
    }
    return 0;
}

// void print_vec(vector<int> vec){

//     printf("Vec :");

//     for (int i = 0; i < vec.size(); i++){
//         printf("%i,",vec[i]);
//     }
//     printf("\n");
// }

void DFS(vector < vector < int > > & adj, int src, int dst, int sh_path) {
  
    int path_count = 0; //path counter
    vector<int> adj_list_idx_vec(adj.size(),0); //index vector
    // create a queue which stores
    // the paths
    vector <int> q;
    int cur_node = src;

    q.push_back(cur_node);

    //push index of src
    while (!q.empty()){

        int next_node = adj[cur_node][adj_list_idx_vec[cur_node]];
        
        if (adj[cur_node].size() == 0 or adj[cur_node].size() == adj_list_idx_vec[cur_node]){
            // Ｎo node to stack
            int l_node = q[q.size()-1];
            adj_list_idx_vec[l_node] = 0;
            q.pop_back();
            cur_node = q[q.size()-1];
            adj_list_idx_vec[cur_node]++;
            // printf("Current node = node %i, Current idx = %i \n",cur_node,adj_list_idx_vec[cur_node]);
        }
        else{
            //keep stacking
            //check if is next node in the stack
            while (find_idx(q,next_node)) {
                // in the satck
                adj_list_idx_vec[cur_node]++;
                next_node = adj[cur_node][adj_list_idx_vec[cur_node]];
                if (adj[cur_node].size() == adj_list_idx_vec[cur_node]-1){
                    int l_node = q[q.size()-1];
                    adj_list_idx_vec[l_node] = 0;
                    q.pop_back();
                    cur_node = q[q.size()-1];
                    adj_list_idx_vec[cur_node]++;
                    break;
                }
            }
            //not in stack
            q.push_back(next_node);
            cur_node = next_node;

            if(next_node == dst){
                printpath(q, sh_path);
                path_count++;
                int l_node = q[q.size()-1];
                adj_list_idx_vec[l_node] = 0;
                q.pop_back();
                cur_node = q[q.size()-1];
                adj_list_idx_vec[cur_node]++;
            }
        }
    }
  
    printf("%i->%i:%ipaths\n", src, dst, path_count);
}



int main() {
    
    //input file name
    string filename;
    cout<<"Enter a filename"<<endl;
    cin >> filename;
    // filename = "test1.sp";
    ifstream ifile(filename);
    if(!ifile.is_open())
    {
        printf("Error, file does not exist!!\n");
        exit(0);
    }

    vector<string> rr;
    string s;
    char symbol;
    int from_node, to_node, num_of_node, num_of_arc;
    float arc_len;
    vector<int>::iterator it_vec;
    vector<array<float,3> > arc_info_vec;
    vector<int> node_arc_index_vec;
    vector<vector<int> > adj_list; //record the adjacent list for each node
    
    

    //read each line
     while (getline(ifile, s))
    {
        // cout << s << "\n";
        rr.push_back(s);


        //extract the number of node and arc
        if(s[0] == 'p')
        {
            vector<string> result;
            const char* delim = "	, ,	";
            tokenize(s,delim,result);
                
            num_of_node = stoi(result[2]);
            num_of_arc = stoi(result[3]);
            printf("num of node : %i\n",num_of_node);
            printf("num of arc :  %i\n",num_of_arc);
        }

        adj_list.resize(num_of_node+1);


        //extract arc information
        if(s[0] == 'a')
        {
            // cout << "input arc" << endl;
            vector<string> result;
            const char* delim = "	";
            tokenize(s,delim,result);


            from_node = stoi(result[1]);
            to_node = stoi(result[2]);
            arc_len = stof(result[3]);
            adj_list[from_node].push_back(to_node);
            array<float,3> arc_array = {from_node,to_node,arc_len};
            arc_info_vec.push_back(arc_array);
        }

    }
    
    sort(arc_info_vec.begin(),arc_info_vec.end());

    node_arc_index_vec.push_back(0);
    int init_node = 1;

    //iterate over every node
    for(int i = 0; i < num_of_node; i++)
    {
        //find the first row index of the node
        for(int ii = 0; ii < arc_info_vec.size(); ii++)
        {
            if(arc_info_vec[ii][0] == init_node)
            {
                // cout<<"find first arc index of node " << init_node << endl;
                node_arc_index_vec.push_back(ii);
                init_node += 1;
                break;
            }
            if(init_node == num_of_node)//last node has no adjacent
            {
                node_arc_index_vec.push_back(num_of_arc);
            }
        }

    }

    ifile.close();

    while(true)
    {
        vector<pair<int,int> > bfs_vec; //vector of node_id and level
        bool is_source_node_bool = true;
        bool is_sink_node_bool = true;
        int source_node, sink_node;

        while(is_source_node_bool)
        {
            printf("Please input a source node\n");
            cin >> source_node;
            it_vec = find(node_arc_index_vec.begin(), node_arc_index_vec.end(), source_node);
            // if(it_vec == node_arc_index.end())
            if(source_node > num_of_node)
            {
                printf("!!Warning!!: node %i does not exist",source_node);
            }
            else
            {
                is_source_node_bool = false;
            }
        }

        while(is_sink_node_bool)
        {
            printf("Please input a sink node\n");
            cin >> sink_node;
            it_vec = find(node_arc_index_vec.begin(), node_arc_index_vec.end(), sink_node);
            // if(it_vec == node_arc_index.end())
            if(sink_node > num_of_node)
            {
                printf("!!Warning!!: node %i does not exist",sink_node);
            }
            else
            {
                is_sink_node_bool = false;
            }
        }


        //generate bfs vector
        int bfs_index = 0;
        int level = 0;
        bfs_vec.push_back(pair<int,float> (source_node,level));
        int node_arc_index = node_arc_index_vec[source_node];
        int current_node = source_node;
        int node_arc_start_index = node_arc_index;

        while(node_arc_start_index < num_of_arc)
        {
            level = bfs_vec[bfs_index].second + 1;
            
            //make sure arc_info_vec is current node
            while(arc_info_vec[node_arc_index][0] == current_node)
            {
                int to_node = arc_info_vec[node_arc_index][1];

                int match_index = -1;
                //make sure if head node isn't in the bfs list
                for (int i = 0; i < bfs_vec.size(); i++)
                {
                    
                    if(arc_info_vec[node_arc_index][1] == bfs_vec[i].first)//check if it appears before
                    {
                        match_index = i;
                    }

                }
                
                if(match_index == -1)
                {
                    
                    bfs_vec.push_back(pair<int,float> (to_node,level));
                }

                node_arc_index ++;

            }

            bfs_index += 1;
            current_node = bfs_vec[bfs_index].first;
            node_arc_start_index = node_arc_index_vec[current_node];
        }

        int max_level = bfs_vec[bfs_vec.size()-1].second;

        //print bfs list
        printf("BFS : ");
        for (int i = 0; i < bfs_vec.size(); i++)
        {
            printf("%i[%i] ",bfs_vec[i].first,bfs_vec[i].second);
            
        } 
        cout << endl;

        // function for finding the paths
        DFS(adj_list, source_node, sink_node, max_level);

    }

    return 0;
}