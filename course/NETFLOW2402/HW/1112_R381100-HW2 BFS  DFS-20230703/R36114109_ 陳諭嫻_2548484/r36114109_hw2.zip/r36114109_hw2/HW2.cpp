/*
    This code can be compiled and run okay.

    This code is to read a network file and to let the users input the nodes they want to find the shortest path.

    usage:
        HW2.cpp xxx
        where xxx is the input network filename, e.g. test1.sp

    input file:
        test1.sp
        test2.sp

    compile:
        g++ HW2.cpp -o hw2

    pseudocode:
        struct Arc tail, head, length
        struct Node distance, label
        ----- Read file
        ifstream ifs
        ifs.open(filename)
    
        ifs >> search
        if search == c
            continue
        if search == t
            pn = problem name
        if search == p
            pt = problem type
            n = # nodes
            m = # arcs
        if search == n
            n = # nodes
        if search == a
            Arc arc
            ifs >> arc.tail >> arc.head >> arc.length
            arcs.push_back(arc)
        ----- Forward star
        for i = 0 ~ arcs.size()-1
            forward_star[arcs[i].tail].push_back(arcs[i])

        point.push_back(1)
        for int i = 1 ~ n-1
            point.push_back(point[i-1] + forward_star[i].size())
        ----- User input source node and sink node
        ----- BFS 
        while !Bqueue.empty()
            f = Bqueue.front()
            for i = 0 ~ forward_star[f].size()-1
                h = forward_star[f][i].head
                if label[h] == -1
                    label[h] = label[f] + 1
                if distance[h] == -1
                    distance[h] = distance[f] + forward_star[f][i].length
                    Bqueue.push(h)
                Bqueue.pop()
        ----- DFS 
        DFS(n, numofnodeofpath, forward_star, visited, curr_node, sink_node, curr_length, path, shortestPathLength, path_count, Path, L)

        if curr_node == sink_node
            if curr_length < shortestPathLength
                shortestPathLength = curr_length

            Path.push_back(path)
            node_count = path.size()
            numofnodeofpath.push_back(node_count)
            L.push_back(curr_length)
            path_count = path_count+1
        else
            for i = 0 ~ forward_star[curr_node].size()-1
                next_node = forward_star[curr_node][i].head
                if visited[next_node] == false
                    next_length = curr_length + forward_star[curr_node][i].length
                    DFS()

        visited[curr_node] = false
        path.pop_back()

    coded by Yu-Shian Chen, ID: r36114109, email: yushian99@gmail.com
    date: 2023.02.28
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstring>
#include <sstream>
#include <queue>
#include <algorithm>

using namespace std;

struct Arc{
    int tail, head;
    double length;
};

struct Node{
    double distance;
    int label;
};


void DFS (int n, vector<int>& numofnodeofpath, vector<vector<Arc>>& forward_star, vector<bool>& visited, int curr_node, int sink_node, double curr_length, vector<int>& path, double& shortestPathLength, int& path_count, vector<vector<int>> &Path, vector<double> &L){
    visited[curr_node] = true; // mark the current node as visited
    path.push_back(curr_node); // add the current node to the path
    int node_count = 0;

    if (curr_node == sink_node){
        if (curr_length < shortestPathLength){
            shortestPathLength = curr_length; // get the shortest path's length
        }
        
        Path.push_back(path); // add the current path to paths
        node_count = path.size();
        numofnodeofpath.push_back(node_count); // get the number of nodes in this path
        L.push_back(curr_length); // add the current path length to path lengths
        path_count++; // cout the number of paths
    } 

    else{
        for (int i = 0; i < forward_star[curr_node].size(); i++){ // go through all the neighbors of the current node
            int next_node = forward_star[curr_node][i].head; // get the next node in the path
            if (!visited[next_node]){ // ff the next node hasn't been visited
                double next_length = curr_length + forward_star[curr_node][i].length; // update length of the path
                DFS(n, numofnodeofpath,forward_star, visited, next_node, sink_node, next_length, path, shortestPathLength, path_count, Path, L); // do DFS with the next node as the current node
            }
        }
    }

    visited[curr_node] = false;
    path.pop_back();
}


int main(){
    cout << "Please input network filename: "; // ask users to input files
    char filename[100];
    cin >> filename;

    ifstream ifs;
    ifs.open(filename);

    while (ifs.fail()){
        cout << "Input file failed\n";
        cout << "Please input network filename: ";
        cin >> filename;
        ifs.open(filename);
    }

    vector<string> T; // t: title of the problem_name
    vector<string> P; // p: problem type(sp), n (# nodes), m (# arcs)

    vector<Arc> arcs;

    string sall;
    string search; // the first letter for searching
    string pn;     // problem name

    string pt; // problem type
    int n = 0; // # nodes
    int m = 0; // # arcs

    int node1, node2;
    double length;
    int arcIndex = 0;

    while (getline(ifs, sall)){
        ifs >> search;
        // if the first letter is c, ignore
        if (search != "c"){ 
            if (search == "t"){ // if the first letter is t, save the problem name as pn
                ifs >> pn; // save the problem name as pn
                T.push_back(pn);
            }

            // if the first letter is p,
            if (search == "p"){  
                ifs >> pt >> n >> m; // save the problem type as pt, get the # nodes as n and # arcs as m
                P.push_back(pt);
            }

            // if the first letter is n, 
            if (search == "n"){ 
                ifs >> n; // save the # nodes as n
            }

            // if the first letter is a, 
            if (search == "a"){
                Arc arc;
                ifs >> arc.tail >> arc.head >> arc.length;
                arcs.push_back(arc);
            }
        }
    }
    ifs.close();
    

    // build forward star
    vector<vector<Arc>> forward_star(n + 1); // # nodes, +1 since it's more convenient to see what node

    for (int i = 0; i < arcs.size(); i++){ // store the arc info into forward_star
        forward_star[arcs[i].tail].push_back(arcs[i]);
    }

    vector<int> point;
    point.push_back(1);
    for (int i = 1; i <n; i ++){
        point.push_back(point[i-1] + forward_star[i].size());
    }


    /*   TEST ALL FIRWARD STAR

    cout << forward_star[2].size() << endl; // the point of the nodes
    cout << forward_star[2][1].tail << endl;
    cout << forward_star[2][1].head << endl;

    for (int i = 1; i <= n; i++) { 
        for (int j = 0; j < forward_star[i].size(); j++) {
            cout << "(" << forward_star[i][j].tail << ", " << forward_star[i][j].head << ", " << forward_star[i][j].length << ") ";
        }
        cout << endl;
    }

    */


    // user input source and sink nodes
    int source_node, sink_node;
    cout << "Please input a source node: ";
    cin >> source_node;
    cout << "Please input a sink node: ";
    cin >> sink_node;


    // BFS implement
    vector<int> distance(n + 1, -1);
    vector<int> label(n + 1, -1);
    queue<int> Bqueue; // queue to store nodes in the BFS order

    distance[source_node] = 0;
    label[source_node] = 0;
    Bqueue.push(source_node);

    while (!Bqueue.empty()){
        int f = Bqueue.front();
        for (int i = 0; i < forward_star[f].size(); i++){
            // Arc& arc = forward_star[f][i];
            int h = forward_star[f][i].head; // get the head of the ith arc in the forward_star of f, the front node in queue

            if (label[h] == -1){ // if it's not the source node, update label
                label[h] = label[f] + 1; 
            }

            if (distance[h] == -1){ // if it's not the source node, update distance
                distance[h] = distance[f] + forward_star[f][i].length; 
                Bqueue.push(h); // add head node to the queue
            }
        }
        Bqueue.pop(); // remove the front node from the queue
    }


    /* TEST PRINTING LABEL
    
    for (int i = 1; i <= n; i++ ) {
        if (distance[i] >= distance[source_node]) 
            cout << "node" << i << "  " << "dist" << distance[i] << "  " << "label" << label[i] << endl;
    }

    cout << "node " << source_node << "  ";
    for (int i = 1; i <= n; i++ ) {
        if (label[i] >= label[source_node])
            
            for (int j = 0; j < forward_star[i].size(); j++) {
                if (forward_star[i][j].head==forward_star[i][j].head)
                    cout << forward_star[i][j].head << " " << "label" << label[forward_star[i][j].head] << endl;
            }
    }
    */


    cout << "BFS: " << source_node << "[" << label[source_node] << "] ";
    for (int i = 1; i <= n; i++ ){
        for (int j = 1; j <= n; j++ ){
            if (label[j] == i){
                cout << j << "[" << label[j] << "] "; 
            }
        }
    }
    cout << endl;


    // DFS implement
    vector<bool> visited(n + 1, false);
    vector<int> path;
    vector<int> numofnodeofpath;
    double shortestPathLength = 1e9;
    int path_count = 0;

    vector<vector<int>> Path;
    vector<double> L;

    DFS(n, numofnodeofpath,forward_star, visited, source_node, sink_node, 0, path, shortestPathLength, path_count, Path, L);

    if (shortestPathLength == 10000) // if there is no path between source and sink nodes
        cout << source_node << " -> " << sink_node << ": "<< 0 << " path" << endl;
    else if (path_count == 1) 
        cout << source_node << " -> " << sink_node << ": "<< path_count << " path" << endl;
    else
        cout << source_node << " -> " << sink_node << ": "<< path_count << " paths" << endl;

    int min = numofnodeofpath[0]; 
    for (int i = 1; i < numofnodeofpath.size(); i++){ // to find the shortest path with fewest arcs
        if (numofnodeofpath[i] < min){
            min = numofnodeofpath[i];
        }
    } 

    for (int i = 0; i < path_count; i++){    
        if (numofnodeofpath[i]-1 == min-1) 
            cout << "*[" << numofnodeofpath[i] - 1 << "]" << ": "; // to mark the shortest path with fewest arcs
        else
            cout << "[" << numofnodeofpath[i] - 1 << "]" << ": "; // to get the number of arcs of each path

        for (int j = 0; j < Path[i].size(); j++){
            if (Path[i][j] != 0) {
                cout << Path[i][j]; // to get the path
                if (j != Path[i].size() - 1){ // check if it is not the last node in the path
                    cout << "-";
                }
            }
        }
        
        if (L[i] == shortestPathLength)
            cout << " length: " << L[i] << "*" << endl; // mark the shortest path length
        else
            cout << " length: " << L[i] << endl; // print out the length of each path
    }

    return 0;
}