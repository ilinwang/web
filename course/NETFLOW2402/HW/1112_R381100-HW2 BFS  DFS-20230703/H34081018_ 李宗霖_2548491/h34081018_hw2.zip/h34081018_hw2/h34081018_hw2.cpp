/*
This is to read a network, do BFS and DFS with forward star data structure.
   
    usage:
        read the network info, choose a source node and a sink node then see results

        execute h34081018_hw2
        input the file name and two node numbers
    
    input file:
        test1.sp or test2.sp
        
    output files:
        none
        
    compile:
        g++ -o h34081018_hw2 h34081018_hw2.cpp

    pseudocode:
    input filename to read file
    ------
    use struct and class to define arcs and Graphs
    ------
    BFS(start){
        create vector to store visit or not
        create queue to store the visited nodes;
        push the start node into queue
        while(queue is not empty){
            pop the first node in queue
            if(node == max index node){
                 return
            }
            for(the succesors of the node){
                if the successor is unvisited then visit it and 
                    push it to the queue
            }
        }
    }
    DFS(start, destination){
        create vector to store visit or not
        create vector to store paths
        DFS_visit(start, destination)
    }
    DFS_visit(node, destination){
        visit[node] = true
        push node to stack
        if(node == destination){
            store the path into vector
        }
        else if(node == max index node){
            return
        }
        else{
            for(the successors of the node){
                if the successor is unvisited then
                    DFS_visit(successor, destination)
                pop the current successor out of path
            }
        }
        visit[node] = false
    }
    ------

    coded by Tsung-Lin Li, ID: h34081018, email: h34081018@gs.ncku.edu.tw
    date: 2023.03.14
*/
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <queue>
#include <stack>
using namespace std;

struct edge{
    int head;
    int tail;
    float length;
};

class Graph{
    int node_num, arc_num;
    edge *arcs;
    int *point;

    public:
    Graph(string filename){
        ifstream readfile(filename);
        string Text;
        int temp = 0, latest_tail = 0;

        // read file line by line
        while (getline (readfile, Text)) {
            // initialize dynamic allocated array
            if(Text[0] == 'p'){
                Text = Text.substr(6);
                istringstream is(Text);
                is >> node_num >> arc_num;
                arcs = new edge[arc_num];
                point = new int[node_num];
            }
            // store arc info
            else if(Text[0] == 'a'){
                Text = Text.substr(2);
                istringstream is(Text);
                is >> arcs[temp].tail >> arcs[temp].head >> arcs[temp].length;
                if(latest_tail != arcs[temp].tail){
                    point[arcs[temp].tail - 1] = temp + 1;
                    latest_tail = arcs[temp].tail;
                }
                else if (temp == arc_num - 1){
                    point[node_num - 1] = arc_num + 1;
                }
                temp++;
            }
        }
        readfile.close();
    }

    void printGraph(){
        for(int i = 0; i < arc_num; i++){
            printf("edge %i (%i -> %i): %.1f\n", i + 1, arcs[i].tail, arcs[i].head, arcs[i].length);
        }
        for(int i = 0; i < node_num; i++){
            printf("point %i: %i\n", i + 1, point[i]);
        }
    }

    void BFS(int start, queue<int> &final_q){
        vector<bool> visited(node_num, false);
        queue<int> q;
        visited[start - 1] = true;
        q.push(start);
        final_q.push(start);
        while(!q.empty()){
            int cur = q.front();
            q.pop();
            if(cur == node_num){
                break;
            }
            for(int i = point[cur - 1] - 1; i < point[cur] - 1; i++){
                if(!visited[arcs[i].head - 1]){
                    visited[arcs[i].head - 1] = true;
                    q.push(arcs[i].head);
                    final_q.push(arcs[i].head);
                    // cout << "push: " << arcs[i].head << endl;
                }
            }
        }
    }

    void DFS(int start, int des, vector<vector <int>> &final_paths) {
        vector<bool> visited(node_num, false);
        vector<int> path;
        DFS_visit(start, des, visited, path, final_paths);
    }

    void DFS_visit(int node, int des, vector<bool> &visited, vector<int> &path, vector<vector <int>> &final_paths){
        visited[node - 1] = true;
        path.push_back(node);
        // cout << node << " ";
        if(node == des){
            // save the path when reach the destination node
            final_paths.push_back(path);
            // for(int i = 0; i < path.size(); i++){
            //     cout << path[i] << " ";
            // }
            // cout << endl;
        }
        else if(node == node_num){
            return;
        }
        else{
            for(int i = point[node - 1] - 1; i < point[node] - 1; i++){
                int next_node = arcs[i].head;
                // cout << "new head " << next_node << endl;
                if(!visited[next_node - 1]){
                    DFS_visit(next_node, des, visited, path, final_paths);
                    // cout << "remove " << path.back() << endl;
                    // remove the current node from the path
                    path.pop_back();
                }
            }
        }
        // mark the current node as unvisited
        visited[node - 1] = false;
        
    }
    // void DFS(int start) {
    //     vector<bool> visited(node_num, false);
    //     stack<int> s;
    //     s.push(start);
    //     while (!s.empty()) {
    //         int cur = s.top();
    //         s.pop();
    //         if(!visited[cur - 1]){
    //              cout << "pop: " << cur << endl;
    //              visited[cur - 1] = true;
    //         }
    //         for(int i = point[cur - 1] - 1; i < point[cur] - 1; i++){
    //             if(!visited[arcs[i].head - 1]){
    //                 s.push(arcs[i].head);
    //                 cout << "push: " << arcs[i].head << endl;
    //             }
    //         }
    //     }
    // }

    void shortest_path(int start, queue<int> final_queue){
        int temp = 0;
        vector<float> total_weight(final_queue.size());
        queue<int> dup(final_queue);

        while(!final_queue.empty()){
            int node = final_queue.front();
            // cout << "calculating node " << node << " shortest weights: ";
            vector<vector <int>> paths; 
            final_queue.pop();
            if(node == start){
                total_weight[temp] = 0;
            }
            else{
                DFS(start, node, paths);
                // cout << "after searching " << paths.size();
                vector<int> weights(paths.size());
                for(int i = 0; i < paths.size(); i++){
                    for(int j = 0; j < paths[i].size() - 1; j++){
                        float weight = 0;
                        for(int k = 0; k < arc_num; k++){
                            if(paths[i][j] == arcs[k].tail && paths[i][j + 1] == arcs[k].head){
                                weight = arcs[k].length;
                                // cout << "weight: " << weight << endl;
                                break;
                            }
                        }
                        // cout << "weight: " << weight << endl;
                        weights[i] = weights[i] + weight;
                        // cout << "weights[i]: " << weights[i] << endl;
                    }
                    if(total_weight[temp] == 0){
                        total_weight[temp] = weights[i];
                        // cout << "weights updated!" << endl;
                    }
                    else if(weights[i] <= total_weight[temp]){
                        total_weight[temp] = weights[i];
                        // cout << "weights updated!" << endl;
                    }
                }
            }
            // cout << total_weight[temp] << endl;
            temp++;
        }
        cout << "BFS: ";
        for(int i = 0; i < total_weight.size(); i++){
            printf("%i[%.1f] ", dup.front(), total_weight[i]);
            dup.pop();
        }
        cout << endl;
    }

    void all_paths(int start, int des, vector<vector <int>> final_paths){
        vector<int> weights(final_paths.size());
        float min;
        queue<int> min_index;
        for(int i = 0; i < final_paths.size(); i++){
            for(int j = 0; j < final_paths[i].size() - 1; j++){
                float weight = 0;
                for(int k = 0; k < arc_num; k++){
                    if(final_paths[i][j] == arcs[k].tail && final_paths[i][j + 1] == arcs[k].head){
                        weight = arcs[k].length;
                        // cout << "weight: " << weight << endl;
                        break;
                    }
                }
                // cout << "weight: " << weight << endl;
                weights[i] = weights[i] + weight;
                // cout << "weights[i]: " << weights[i] << endl;
            }
            if(i == 0){
                min = weights[i];
                min_index.push(i);
            }
            else if(min > weights[i]){
                min = weights[i];
                min_index.pop();
                min_index.push(i);
            }
            else if(min == weights[i]){
                min = weights[i];
                min_index.push(i);
            }
        }
        printf("%i->%i: %ipath(s)\n", start, des, final_paths.size());
        for(int i = 0; i < final_paths.size(); i++){
            if(min_index.front() == i){
                cout << "*";
                min_index.pop();
            }
            printf("[%i]: ", weights[i]);
            for(int j = 0; j < final_paths[i].size() - 1; j++){
                cout << final_paths[i][j] << "-";
            }
            cout << final_paths[i][final_paths[i].size() - 1] << endl;
        }
    }

    ~Graph(){
        delete[] arcs, point;
    }
};


int main(){
    string filename;
    printf("Please input network filename: \n");
    cin >> filename;

    Graph g(filename);
    // g.printGraph();

    int start, des;
    printf("Please input the source node: \n");
    cin >> start;
    printf("Please input the sink node: \n");
    cin >> des;

    queue<int> final_q;
    vector<vector <int>> final_paths;

    g.BFS(start, final_q);
    g.DFS(start, des, final_paths);
    g.shortest_path(start, final_q);
    g.all_paths(start, des, final_paths);
    g.~Graph();

    return 0;
}