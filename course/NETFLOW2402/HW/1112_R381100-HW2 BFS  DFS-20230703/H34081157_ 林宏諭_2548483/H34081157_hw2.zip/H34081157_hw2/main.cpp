
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

struct arc {
    int from,to;
    float length;
};

struct node {
    int num;
    node *to;
};

vector<vector <int>> DFS;
//void Search(node *current,vector<node> *DFS, arc *&matrix, int *point,int sink,int source) {
//    node *t = new node;
//    t = current;
//    for (int i=point[current->num-1]+1;i<=point[current->num];i++){
//        if (current->num == sink) {
//            DFS->push_back(*t);
//            current->num = matrix[i].to;
//            Search(current, DFS, matrix, point, sink, source);
//        }
//        else {
//            current->num = matrix[i].to;
//            node *temp;
//            temp = DFS[DFS->size()].data();
//            while (temp->to != NULL) {
//                temp = temp->to;
//            }
//            temp->to = t;
//        }
//    }
//    if (current->num == source)
//        return;
//    if (point[current->num-1] == point[current->num])
//        DFS->pop_back();
//        return;
//};

void Search(node current,vector <int>stack, arc *&matrix, int *point,int sink,int source) {
    
    if (current.num == source) {
        DFS.push_back(stack);
        stack.pop_back();
        return;
    }
    int temp = current.num;
    for (int i=point[temp-1]+1;i<=point[temp];i++) {
        current.num = matrix[i].to;
        stack.push_back(current.num);
        Search(current,stack,matrix,point,sink,source);
        stack.pop_back();
        
    }
    return;
};

int main(int argc, const char * argv[]) {
    
    string filename;
    ifstream file;
    cout << "Enter filename: ";
    cin >> filename;
    file.open(filename,ios::in);
    string line,problem;
    int n,m;
    arc * matrix;

    int sink,source;
    int temp_i,temp_j;
    int * point;
    int * count;
    int a = 1;
    while (getline(file,line)) {
        char head;
        file >> head;
        if (head == 'p') {
            file >> problem >> n >> m;
            matrix = new arc [m+1];
            point = new int [n+1];
            count = new int [n+1];
            for (int i=0; i<=n+1; i++)
                count[i] = 0;
        }
        else if (head == 'a') {
            file >> temp_i >> temp_j;
            count[temp_i]++;
            matrix[a].from = temp_i;
            matrix[a].to = temp_j;
            file >> matrix[a].length;
            a++;
        }
    }
    
    for (int i=1; i<n+1; i++) {
        int total = 0;
        for (int j=0;j<=i;j++)
            total += count[j];
        point[i] = total;
    }
    cout << "Please input a source node: ";
    cin >> sink >> source;
    int *BFS = new int [n+1];
    for (int i=0; i<n+1; i++)
        BFS[i] = 0;
    for(int i=sink;i<n+1;++i) {
        for (int j=point[i-1];j<point[i];j++) {
            if (BFS[matrix[j].to] == 0) {
                BFS[matrix[j].to] = BFS[matrix[j].from] + 1;
            }
        }
    }
    cout << "BFS: ";
    for (int i=sink; i<source+1; i++)
        cout << i << "["<< BFS[i] << "] ";
    cout << endl;
    vector<int> stack;
    node first;
    first.num = sink;
    stack.push_back(sink);
    Search(first,stack,matrix,point,sink,source);
    int min = 1000000;
//    int  * total_length = new int[DFS.size()];
//    for (int i=0;i<DFS.size();++i)
//        total_length[i] = 0;
    
//    for (int i = 0; i < DFS.size(); i++) {
//        for (int j = 0; j < DFS[i].size()-1; j++) {
//            for(int k = point[DFS[i][j]-1]+1;k <= point[DFS[i][j]];++k) {
//                if (DFS[i][j+1] == matrix[k].to)
//                    total_length[i] += matrix[k].length;
//            }
//        }
//    }
    for (int i = 0; i < DFS.size(); i++) {
        if (DFS[i].size()<min)
            min = DFS[i].size();
    }
    cout << sink << "->" << source << ": " << DFS.size() << " paths" << endl;
    for (int i = 0; i < DFS.size(); i++) {
        if (DFS[i].size() == min) {
            cout << "*";
        }
        cout << "[" << DFS[i].size()-1 << "]: ";
        for (int j = 0; j < DFS[i].size(); j++) {
            if (j == DFS[i].size()-1)
                cout << DFS[i][j];
            else
                cout << DFS[i][j] << "-";
        }
        cout << endl;
    }
    return 0;
}
