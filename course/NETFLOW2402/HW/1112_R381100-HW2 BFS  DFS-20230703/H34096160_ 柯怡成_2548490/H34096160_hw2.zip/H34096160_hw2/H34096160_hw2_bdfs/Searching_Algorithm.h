#include <iostream>
#include <queue>
#include <stack>
using namespace std;

#ifndef SEARCHING_ALGORITHM_H_INCLUDED
#define SEARCHING_ALGORITHM_H_INCLUDED

/*
A path node representing a path, and a node representing a path
Content variables include:
- path: all points the path passes through
- pathNodeNum: how many points on the path
- distance: the distance of this path
- next: linked list structure set up due to unknown number of paths
*/
struct Path{
    int *path, pathNodeNum;
    double distance = 0;
    Path *next = NULL;
};

/*
the Class representing all paths
Content functions include:
- addPath: Add a path to the linked list represented by pathPtr, compare shortestPath and shortestDistance, and add pathNum
- printPath: Output all paths and corresponding lengths stored in the Class, and mark the shortest path and the least path
- getPathNum: Get how many paths there are
Content variables include:
- pathPtr : linked list structure storing all paths
- shortestPath : the shortest number of path arcs
- pathNum: the number of paths stored in it
- shortestDistance: the total distance of the shortest path
*/
class Pathes{
public:
    Pathes(){}
    /*

    */
    void addPath(stack<int> dfsS, int *&pointForward, int *&arcnow, double **&network, int &n, int &m){
        Path *tempPtr = pathPtr;
        if (pathPtr == NULL){ // If there is no path yet, add the first node of linked list
            pathPtr = new Path;
            tempPtr = pathPtr;
        }
        else { // If any path exists,
            while (tempPtr->next){ tempPtr = tempPtr->next; } // move to last node of linklist
            tempPtr->next = new Path; // create next node
            tempPtr = tempPtr->next;
        }

        for (int i = 1; i <= n; i++){ // sum the stored distances across all valid paths
            if (arcnow[i] != pointForward[i] && arcnow[i] <= m+1){
                tempPtr->distance += network[arcnow[i]-1][2];
            }
        }
        if (tempPtr->distance < shortestDistance){ shortestDistance = tempPtr->distance; } // Check the shortest path
        if (dfsS.size() < shortestPath){ shortestPath = dfsS.size(); } // Check the minimum number of paths

        int tempCtr = 0; // initialize the path in the node
        tempPtr->path = new int[dfsS.size() + 1];
        tempPtr->pathNodeNum = dfsS.size();
        while (!dfsS.empty()){ // store the value of the DFS stack into the path pointer
            tempPtr->path[dfsS.size()] = dfsS.top();
            dfsS.pop();
        }
        pathNum++; // record path number
    }
    void printPath(int sinkNode){
        Path *tempPtr = pathPtr;
        while (tempPtr){ // for all paths
            if (tempPtr->pathNodeNum == shortestPath) { cout << "*"; } // check for minimum number of paths
            if (tempPtr->distance == shortestDistance) { cout << "$"; } // check for the shortest path
            // output path
            cout << "[" << tempPtr->pathNodeNum << "][" <<tempPtr->distance << "] ";// << tempPtr->path[1];
            for (int i = 1; i <= tempPtr->pathNodeNum; i++){
                cout << tempPtr->path[i] << " - ";
            }
            cout << sinkNode << endl;
            tempPtr = tempPtr->next;
        }
    }
    int getPathNum(){ return pathNum; } // return
private:
    Path *pathPtr = NULL;
    int shortestPath = 1e9, pathNum = 0;
    double shortestDistance = 1e9;
};

void Breadth_First_Search(int *&pointForward, double **&network, int &n, int &m, int &sourceNode){
    int *distance = new int[n+1], temp; // sore the distance mark of each point/temporarily store the current point
    // initialize the distance matrix
    for (int i = 0; i <= n; i++){
        distance[i] = -1;
    }

    queue<int> bfsQ; // create queue
    // Output and put into array for source node
    bfsQ.push(sourceNode);
    distance[sourceNode] = 0;
    cout << sourceNode << "[" << 0 << "]\t";

    while (!bfsQ.empty()){ // as long as there are values in the queue
        temp = pointForward[bfsQ.front()]; // save front to temp
        while (temp < pointForward[bfsQ.front()+1]){ // as long as the arc corresponding to temp still belongs to the same point
            if (distance[int(network[temp][1])] == -1){ // If the peer node has not been marked
                // Output and put into array for peer node
                distance[int(network[temp][1])] = distance[bfsQ.front()] + 1;
                cout << network[temp][1] << "[" << distance[int(network[temp][1])] << "]\t";
                bfsQ.push(int(network[temp][1]));
            }
            temp++;
        }
        bfsQ.pop(); // remove used points
    }
    cout << endl;
}

void Depth_First_Search(int *&pointForward, double **&network, int &n, int &m, int &sourceNode, int &sinkNode){
    /*
    arcnow: mark the next arc that should be used
    temp: arc currently in use
    P: the set of pathes, an instance of class Pathes
    dfsS: stack for DFS
    */
    int *arcnow = new int[n+1], temp;
    Pathes *P = new Pathes;
    stack<int> dfsS;

    dfsS.push(sourceNode);
    // initialize arcnow as pointForward
    for (int i = 1; i <= n; i++){ arcnow[i] = pointForward[i]; }

    while (!dfsS.empty()){ // as long as there are values in the stack
        temp = arcnow[dfsS.top()];

        if (temp == pointForward[dfsS.top() + 1]){ // if the available arc is not the same starting point
            // reset arcnow
            arcnow[dfsS.top()] =  pointForward[dfsS.top()];
            dfsS.pop();
        }
        else if (network[temp][1] == sinkNode){ // if available arc completes the path
            // record the arc used and save the path
            arcnow[dfsS.top()]++;
            P->addPath(dfsS, pointForward, arcnow, network, n, m);
        }
        // If vertex hasn't been used, push it in dfsS
        else if (arcnow[int(network[temp][1])] == pointForward[int(network[temp][1])]){
            // Record that arc has been used and put the peer node into the stack
            arcnow[dfsS.top()]++;
            arcnow[int(network[temp][1])] = pointForward[int(network[temp][1])];
            dfsS.push(network[temp][1]);
        }
        // if it has been used, break and claim it is not a acyclic graph
        else {
            cout << "Not a acyclic graph�I\n";
            break;
        }
    }
    cout << sourceNode << " -> " << sinkNode << ": " << P->getPathNum() << endl;
    P->printPath(sinkNode);
}

#endif // SEARCHING_ALGORITHM_H_INCLUDED
