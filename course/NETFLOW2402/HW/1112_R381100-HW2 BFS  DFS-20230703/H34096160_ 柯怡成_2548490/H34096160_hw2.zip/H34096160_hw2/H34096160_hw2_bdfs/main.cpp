/*
This program can be executed without problems.
Purpose: All points that can be reached with BFS and the minimum number of arcs required, and find all paths and shortest distances with DFS
Method: Perform the exe file or compile main.cpp and execute the compiled execution file
Enter: SP file name(such as test1.sp, test2.sp), starting node, termination node
Output: The minimum number of arc, the number of paths, and all paths that can be reached from the starting node will marked at least the number of arc (*) and the shortest path ($).
Compile: directly compile the main.cpp, such as: g ++ -o hw2.exe main.cpp
Pseudo code: as shown below
Mason Ke completed this program at 2323/03/01 19:55

*/
#include <iostream>
#include "Read_SP_Forward_Reverse_Star.h"
#include "Searching_Algorithm.h"

using namespace std;
/* pseudo code
function Initialization(pointForward, pointReverse, network, fileName, problemName, problemType, n, m)
    input fileName
	myFile <- openFile(fileName)
    if (myFile is not open)
        output "Failed to open file ", fileName, "!!"
        return false
    end if

    while (line <- getNextLineFromFile(myFile)) do
        c <- getFirstField(line)
        switch c
            case 't':
                problemName <- getSecondField(line)
            case 'p':
                problemType <- getSecondField(line)
                n <- getThirdField(line)
                m <- getFourthField(line)
                pointForward <- allocateMemoryForIntArray(n+2)
                pointReverse <- allocateMemoryForIntArray(n+2)
                pointForward[n+1] <- m+1
                pointReverse[n+1] <- m+1
                network <- allocateMemoryForDoubleArray(m+1)
                for i from 1 to n
                    pointForward[i] <- 1
                    pointReverse[i] <- 1
                end for
                for i from 1 to m
                    network[i] <- allocateMemoryForDoubleArray(4)
                end for
            case 'a':
                from <- getSecondField(line)
                to <- getThirdField(line)
                distance <- getFourthField(line)
                for i from (from + 1) to n
                    pointForward[i] <- pointForward[i] + 1
                end for
                for i from (to + 1) to n
                    pointReverse[i] <- pointReverse[i] + 1
                end for
            default:
                // do nothing
        end switch
    end while
    closeFile(myFile)
    return true
end function

// The other two data structure I didn't use

function Store_Forward_Reverse_Star(pointForward, pointReverse, ptrReverse, network, fileName, n, m)
    myFile <- openFile(fileName)
    tempForward <- copyArray(pointForward)
    tempReverse <- copyArray(pointReverse)

    while (line <- getNextLineFromFile(myFile)) do
        c <- getFirstField(line)
        if c equal to 'a' then
            from <- getSecondField(line)
            to <- getThirdField(line)
            distance <- getFourthField(line)
            network[temp[from]][0] <- from
            network[temp[from]][1] <- to
            network[temp[from]][2] <- distance
            ptrReverse[tempReverse[to]] <- network[tempForward[from]]
            tempForward[from] <- tempForward[from] + 1
            tempReverse[from] <- tempReverse[from] + 1
        end if
    end while
    closeFile(myFile)
end function

structure Path
    path: pointer to int
    pathNodeNum: integer
    distance: double = 0
    next: pointer to Path = NULL
end structure

class Pathes
    pathPtr: pointer to Path = NULL
    shortestPath: integer = 1e9
    pathNum: integer = 0
    shortestDistance: double = 1e9

    method addPath(dfsS, pointForward, arcnow, network, n, m)
        tempPtr <- pathPtr
        if pathPtr equal to NULL then
            pathPtr = new Path
            tempPtr = pathPtr
        else
            While tempPtr.next is not NULL
                tempPtr = tempPtr.next
            End While
            tempPtr.next = new Path
            tempPtr = tempPtr.next
        end if

        for i from 1 to n
            if arcnow[i] is not equal to pointForward[i] and arcnow[i] <= m+1 then
                tempPtr.distance += network[arcnow[i]-1][2]
            end if
        end for
        if tempPtr.distance < shortestDistance then
            shortestDistance = tempPtr.distance
        end if
        if dfsS.size() < shortestPath then
            shortestPath = dfsS.size()
        end if

        tempCtr <- 0
        tempPtr.path <- new int[dfsS.size() + 1]
        tempPtr.pathNodeNum <- dfsS.size()
        while dfsS is not empty do
            tempPtr.path[dfsS.size()] <- dfsS.top()
            dfsS.pop()
        end while
        pathNum <- pathNum +1
    end method

    method printPath(sinkNode)
        tempPtr: pointer to Path = pathPtr
        While tempPtr is not NULL
            If tempPtr.pathNodeNum == shortestPath Then print("*")
            If tempPtr.distance == shortestDistance Then print("$")
            print("[", tempPtr.pathNodeNum, "][", tempPtr.distance, "] ", tempPtr.path[1])
            For i = 1 to tempPtr.pathNodeNum
                print(tempPtr.path[i], " - ")
            End For
            print(sinkNode, "\n")
            tempPtr = tempPtr.next
        cnd while
    end method

    method getPathNum()
        return pathNum
    end method
end class


initialize variables

while (the Initialization function returns false) do
    call Initialization function with pointForward, pointReverse, network, fileName, problemName, problemType, n, m as arguments
end while

call Store_Forward_Reverse_Star function with pointForward, pointReverse, ptrReverse, network, fileName, n, m as arguments

input sourceNode
input sinkNode

call Breadth_First_Search function with pointForward, network, n, m, sourceNode as arguments
call Depth_First_Search function with pointForward, network, n, m, sourceNode, sinkNode as arguments
*/
int main()
{
    /*
    n/m: number of node/arc
    pointForward/pointReverse: the start index of forward/reverse star
    sourceNode/sinkNode: the source and sink what user input
    network: the 2D structure to store arcs(from to distance)
    ptrReverse: the pointer to indicate where the place is
    fileName: a string to store the file name
    problemName/problemType: a string to store the problem name/type
    */
    int n, m, *pointForward, *pointReverse, sourceNode, sinkNode;
    double **network, **ptrReverse;
    string fileName, problemName, problemType;
    // try to open file and initialize the variable above
    while(!Initialization (pointForward, pointReverse, network, fileName, problemName, problemType, n, m)){ }

    Store_Forward_Reverse_Star (pointForward, pointReverse, ptrReverse, network, fileName, n, m);

    // input data
    cout << "Please input a source node: ";
    cin >> sourceNode;
    cout << "Please input a sink node: ";
    cin >> sinkNode;
    // call function BFS
    cout << endl;
    Breadth_First_Search(pointForward, network, n, m, sourceNode);
    // call function DFS
    cout << endl;
    Depth_First_Search(pointForward, network, n, m, sourceNode, sinkNode);


    return 0;
}
