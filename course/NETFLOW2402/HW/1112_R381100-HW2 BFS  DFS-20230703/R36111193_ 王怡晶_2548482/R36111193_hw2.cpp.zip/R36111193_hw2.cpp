/*
    This code can be compiled and run ok.

    input file: test1.sp

    purpose: 
        1.Read a network file with a format similar to test1.sp and test2.sp
        2.Ask the user to input a node index

    usage:
        input network filename, e.g. test1.sp
    
    compile:
        visual studio code

    pseudo-code:
       input filename
        cin >> source
        cin >> sink
        infile.get(test)
        if test == 'p'
        node_quantity >> arc_quantity
        if test == 'a'
        node1 >> node2 >> arc

        node1 = _array[i][0]
        node2 = _array[i][1]
        FirstArc[node1][CurrentArc[node1]] = node2


        if (!visited[next])
        visited[next] = true;
        distance[next] = distance[curr] + 1;
        queue.push_back(next);


        DFS(n,FirstArc, start, temp,end, AA);

        if visit == end
            AA.push_back(path);
            path.pop_back();
            return;
            
        
             if (map[visit][i] > 0) 
                path.push_back(map[visit][i]);
                DFS(n, map, map[visit][i], path,end,AA);

                

    coded by Yi-Jing Wang, ID: r36111193, email: sandy19980920@gmail.com
    date: 2023.03.18
*/

#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<list>
#include <queue>
#include <stack>

using namespace std;
void DFS(int n,int **map,int visit,vector<int>&path,int end,vector<vector<int> > &AA);
int main() {
    string filename;
    cout << "enter the filename: ";
    cin >> filename;
    ifstream infile(filename, std::ios::in); // 開啟檔案
    if (!infile) {
         cout << "檔案名稱錯誤" << endl;
        return 1;
    }

    int source;
    cout << "source node : "; //輸入source node
    cin >> source;

    int sink;
    cout << "sink node : "; //輸入source node
    cin >> sink;

    int node_quantity; //node數
    int arc_quantity; //arc數
    string gar; //不需要用到的字串

    char test; //檔案搜尋

    int node1=0;
    int node2=0;
    int arc=0;

    string line;

    int** _array=nullptr; //動態矩陣
    int qq = 0;

    while (infile.get(test)) {     // 逐行讀取

        if (test == 'p') {    //判斷是否是p開頭,看arc跟node數量
            infile >> gar >> node_quantity >> arc_quantity;

            _array = new int* [arc_quantity];

        }
        else if (test == 'a') {   // 判斷是否是a開頭
            infile >> node1 >> node2 >> arc;

              _array[qq] = new int[3];
              _array[qq][0] = node1;
              _array[qq][1] = node2;
              _array[qq][2] = arc;

            qq++;

        }
        else if (test == 'c' || test == 't' || test == 'n') { //若是c,t,n開頭則跳過
            getline(infile, line);
        }
    }

    int n = node_quantity;

    int** FirstArc = new int* [n + 1]; //連接的點
    int* CurrentArc = new int[n + 1]; // 連接的點數量
    // int *NextArc = new int[n+1]; // 第一次出現

    for (int i = 1; i <= n; i++) {
        FirstArc[i] = new int[n];
        CurrentArc[i] = 0;
        // NextArc[i]=0;
    }

    for (int i = 0; i < arc_quantity; i++) {
        node1 = _array[i][0];
        node2 = _array[i][1];
        FirstArc[node1][CurrentArc[node1]] = node2;
        CurrentArc[node1]++;

        // if (NextArc[node1] == 0) {
        //     NextArc[node1] = i ;
        // }

    }

    for (int i = 1; i <= n; i++) {   //print
        cout << "FirstArc[" << i << "]: ";
        for (int j = 0; j < CurrentArc[i]; j++) {
            cout << FirstArc[i][j] << " ";
        }
        cout << endl;
    }
    for (int i = 1; i <= n; i++) {
        cout << "CurrentArc[" << i << "]: " << CurrentArc[i] << endl;
    }
    list<int> queue;

    vector<bool> visited(n + 1, false);
    vector<int> distance(n + 1, -1);
    vector<int> paths(n + 1, -1); // 存儲每個節點的前一個節點


    visited[source] = true;
    distance[source] = 0;
    queue.push_back(source);
    while (!queue.empty()) {
        int curr = queue.front();
        queue.pop_front();

        visited[curr] = true;

        for (int i = 0; i < CurrentArc[curr]; i++) {
            int next = FirstArc[curr][i];

            if (!visited[next]) {
                visited[next] = true;
                distance[next] = distance[curr] + 1;
                queue.push_back(next);
            }
        }
    }

    cout << "BFS: ";
    for (int i = 1; i <= n; i++) {
        if (distance[i] >= 0) {
            cout << i << "[" << distance[i] << "] ";
        }
    }
    cout << endl;
    cout << source << "->" << sink ;
    vector<vector<int> > AA; //存放所有2-6的路徑
    vector<int> temp; //暫存路徑

    int start = source;
    int end = sink;
    temp.push_back(start);
    DFS(n,FirstArc, start, temp,end, AA);
    /*
    while (!s.empty()) {
        int curr = s.top();
        s.pop();
        temp.push_back(curr);
         cout <<"visit"<< curr<< endl;
        if (curr == end) { //達到終點，將暫存路徑加入AA矩陣
            cout << "reach end" << endl;
            AA.push_back(temp);
            temp.clear();
            s.push(start);
         }
       else {
            for (int i =0; i <= n; i++) { //搜尋相鄰節點
                if (FirstArc[curr][i] > 0 && !call[FirstArc[ curr][i]]) {
                    s.push(FirstArc[curr][i]);
                    break;
                }
            }
        }

    }*/
    //將所有路徑印出來
    int min = INT_MAX;
    for (int i = 0; i < AA.size(); i++) {
        if (min > AA[i].size())
            min = AA[i].size();
    }
    for (int i = 0; i < AA.size(); i++) {
        if (AA[i].size() == min)
            cout << "*";
        cout << "[" << AA[i].size() - 1 << "]:";
        for (int j = 0; j < AA[i].size(); j++) {
            cout << AA[i][j];
            if(j!=AA[i].size()-1)
                cout<< "-";
        }
        cout << endl;
    }
}
void DFS(int n,int** map, int visit, vector<int>&path,int end, vector<vector<int> >& AA) {
    if (visit == end) {
        AA.push_back(path);

        path.pop_back();
        return;
    }
    for (int i = 0; i <= n; i++) {
        if (map[visit][i] > 0) {
            path.push_back(map[visit][i]);
            DFS(n, map, map[visit][i], path,end,AA);
        }
    }
    path.pop_back();
}