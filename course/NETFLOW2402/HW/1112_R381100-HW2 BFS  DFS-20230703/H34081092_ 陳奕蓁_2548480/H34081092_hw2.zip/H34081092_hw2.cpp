/*
   This code can be compiled and run ok.

   This is to read a network.
   You enter a source node s and a sink node t
   The code will print out all the reachable nodes from s by the BFS labeling order
   and the distance label associated with each reachable node from s
   The code will also print out all the paths and their lengths from s to t,
   based on the idea of DFS; the shortest path will be marked with "*". 
   
   usage:
     1. input the name of a sp file
     2. input a source node
  
   input file:
     test1.sp
     test2.sp
	   
   output files:
     none
	   
   compile:
     gcc -o H34081092_hw2 H34081092_hw2.cpp
   
   pseudocode:

    struct list
        int x
        struct list *next
    end struct

    typedef struct list node
    typedef node * link

    struct graphlink
        link first
        link last
    end struct

    insert(struct graphlink* temp, int x)
        link newNode = new node;
        newNode->x = x;
        newNode->next = NULL;
        if temp->first == NULL then:
            temp->first = newNode;
            temp->last = newNode;
        else:
            temp->last->next = newNode;
            temp->last = newNode;
    end func

    enqueue(int value)
        if rear>=MAXSIZE then return -1;
        rear = rear + 1
        queue[rear] = value
    end func

    dequeue()
        if front == rear then return -1;
        front = front + 1
        return queue[front]
    end func

    BFS(int current)
        link tempNode
        enqueue(current);
        BFS_path_length[current] = 0;
        run[current] = 1; 

        while front != rear do: 
            current = dequeue()
            tempNode = adjacency_list[current].first;
            while tempNode!=NULL do: 
                if run[tempNode->x] == 0:
                    BFS_path_length[tempNode->x] = BFS_path_length[current] + 1;
                    enqueue(tempNode->x);
                    run[tempNode->x]=1;
                end if
                tempNode = tempNode->next;
            end while
        end while
    end func


    st is stack 

    DFS(int s, int t, int n, int path[], int index)
        link tempNode 
        st.push(s)
        path[index]=s
        tempNode = adjacency_list[s].first
        if !st.empty() then
            s = st.top()
            tempNode = adjacency_list[s].first; 
            while tempNode != NULL do
                if tempNode->x != t then
                    index++
                    DFS(tempNode->x, t , n, path, index)
                    tempNode = tempNode->next
                    index--
                else do 
                    path_count++
                    tempNode = tempNode->next
                    path[index+1] = t
                    for  i = 0 to index+1 do
                        output +=  path
                    end for
                    path[index+1] = 0
                end if
            end while
            st.pop()
            path[index] = 0
        end if
    end func

    main()
        for i = 1 to n do
            run[i] = 0;
            adjacency_list[i].first = NULL;
            adjacency_list[i].last = NULL;
            for j=1 to m do
                if arc[j][0]==i then
                    dataNum = arc[j][1]
                    insert(&adjacency_list[i], dataNum)
                end if
            end for
        end for

        BFS(s)

        for i = 1 to n do
            run[i] = 0;
            adjacency_list[i].first = NULL;
            adjacency_list[i].last = NULL;
            for j=1 to m do
                if arc[j][0]==i then
                    dataNum = arc[j][1]
                    insert(&adjacency_list[i], dataNum)
                end if
            end for
        end for
        
        DFS(s, t, n, path, 1)
    }

    coded by Yi-chen Chen, ID: H34081092, email: H34081092@gs.ncku.edu.tw
   date: 2023.03.18
*/

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <sstream>
#include <vector>
#include <cstdio>
#include <cstring>
#include <stack>
using namespace std;

const int MAXSIZE = 200;

int front=-1;
int rear=-1;

//read the data and split the lines 
vector<string> split( string line, char x, char tab){
    vector<string> result;
    string tmp = "";

    for(int i=0; i<line.length(); i++){
        if(line[i] == x | line[i]==tab){
            if(tmp!=""){
                result.push_back(tmp);
                tmp = "";
            }
            
        }else{
            tmp += line[i];
            // cout << tmp <<endl;
            if (i+1 == line.length()){
                result.push_back(tmp);
            }
            
        }
    }
    return result;
}

//a struct to save node data
struct list
{
    int x; 
    struct list *next;
};

typedef struct list node;
typedef node * link;

//graphlink is to use in adjacency list
struct graphlink
{
    link first;
    link last;
};

int* run; // a list to save whether the node is visited
int queue[MAXSIZE]; // queue to save nodes to visit in the future

struct graphlink* adjacency_list; // adjacency list

// insrt the nodes into the adjacency list
// temp = a element(node) in the adjacency list
// newNode = a node that temp can reach to 
void insert(struct graphlink* temp, int x){
    link newNode = new node;
    newNode->x = x;
    newNode->next = NULL; 
    if(temp->first == NULL){
        temp->first = newNode;
        temp->last = newNode;
    }else{
        temp->last->next = newNode;
        temp->last = newNode;
    }
}

void enqueue(int value){
    if(rear>=MAXSIZE) return;
    rear++; 
    queue[rear]=value; //save node in queue
}

int dequeue(){
    if(front == rear) return -1;
    front++; 
    return queue[front];
}

int* BFS_path_length; // to count the length of every node from s

void BFS(int current){
    link tempNode; // pointer of a node
    enqueue(current);
    BFS_path_length[current] = 0;
    run[current] = 1; 
    cout << current ; 
    cout << "[" << BFS_path_length[current] << "]  ";

    while(front!=rear){ // while there are node in queue
        current = dequeue(); //current = first node number of queue
        tempNode = adjacency_list[current].first; // the first node which "current node" can reach

        while(tempNode!=NULL){ //while there are nodes to visit
            if(run[tempNode->x] == 0){ // haven't visit yet
                BFS_path_length[tempNode->x] = BFS_path_length[current]+1; // length of visiting "tempNode" = length of visiting "current"+1
                enqueue(tempNode->x);// store tempNode into queue
                run[tempNode->x]=1; // mark "visited"
                cout << tempNode->x; 
                cout << "[" << BFS_path_length[tempNode->x] << "]  ";
            }
            tempNode = tempNode->next;
        }
    }
}

stack<int> st; //stack
vector<string> allpath = {}; //store the paths from s to t
vector<int> path_length = {}; //store the length of the paths from s to t
int path_count = 0; // store the total number of paths

void DFS(int s, int t, int n, int path[], int index){
    
    st.push(s); //push s into stack
    path[index] = s; //store s into "path"

    link tempNode;
    tempNode = adjacency_list[s].first; 
    //set tempNode as the first node that s can reach 

    if (!st.empty())
    {
        s = st.top();
        tempNode = adjacency_list[s].first;

        while( tempNode != NULL ){
            if(tempNode->x != t){
                index++; 
                DFS(tempNode->x, t , n, path, index);
                tempNode = tempNode->next;
                index--;
                
            }else{ // if reach t
                path_count++;
                tempNode = tempNode->next;
                path[index+1] = t;

                // store the path
                string output;
                output += "[";
                output += to_string(index+1);
                output += "]: ";
                path_length.insert(path_length.end(), index+1);
                for(int i=1; i<= n;i++){
                    if(path[i]!=0){
                        output += to_string(path[i]);
                        if (path[i] != t){
                            output += "-";
                        }
                    }
                }
                allpath.insert(allpath.end(), output);
                path[index+1] = 0; // clean t from path
                break;
            }
        }
        st.pop();
        path[index] = 0; // when s has no reachable node, clean node s from path 
    }
}

int main(){

    //read file
    string name, type;
    int n ,m;
    vector<string> tmp;
    ifstream myFile;
    string filename;
    cout<<"Please input network filename:";
    cin>>filename;
    myFile.open(filename);
    string line;
    int ** weight ;
    int ** arc;
    int c=1;
    int bigM=10000;

    while (getline(myFile, line)) {
        if (line[0]=='t'){
            tmp = split(line,' ','\t');
            name = tmp[1];
        }
        else if(line[0]=='p'){
            tmp = split(line,' ', '\t');
            type = tmp[1];
            n = stoi(tmp[2]);
            m = stoi(tmp[3]);

            weight = new int* [n+1];
            for(int i=0;i<=n;i++){
                weight[i] = new int [n+1];
                for(int j=0;j<=n;j++){
                    weight[i][j] = bigM;
                }
            }
            arc = new int* [m+1];
            for(int i=1; i<=m;i++){
                arc[i] = new int [2];
            }

        }else if(line[0]=='a'){
            tmp = split(line,' ', '\t');
            
            arc[c][0]=stoi(tmp[1]);
            arc[c][1]=stoi(tmp[2]);
            weight[arc[c][0]][arc[c][1]] = stoi(tmp[3]);
            c+=1;
        }
    }
    //end read file

    //BFS start
    run = new int [n+1]; // store the nodes are visited or not
    adjacency_list = new graphlink [n+1];
    BFS_path_length = new int [n+1]; // length from s to each node
    
    //store data into adjacency list
    int dataNum;
    for (int i=1 ; i<=n ; i++){
        run[i] = 0;
        adjacency_list[i].first = NULL;
        adjacency_list[i].last = NULL;
        for (int j=1; j<=m; j++){
            if(arc[j][0]==i){
                dataNum = arc[j][1];
                insert(&adjacency_list[i], dataNum);
            }
        }
    }
    
    int s;
    cout << "input s:";
    cin >> s;
    int t;
    cout << "input t:";
    cin >> t;

    cout << "BFS: " ;

    BFS(s);
    cout << endl;
    //BFS end

    //DFS start
    int * path = new int [n+1];
    for (int i=1;i<=n;i++){
        path[i] = 0;
    }

    //store data into adjacency list
    for (int i=1 ; i<=n ; i++){
        run[i] = 0;
        adjacency_list[i].first = NULL;
        adjacency_list[i].last = NULL;
        for (int j=1; j<=m; j++){
            if(arc[j][0]==i){
                dataNum = arc[j][1];
                insert(&adjacency_list[i], dataNum);
            }
        }
    }

    cout <<"DFS:" <<endl;

    DFS(s, t, n, path, 1);

    cout<< s <<"->"<<t<<": "<<path_count<<" paths"<<endl;
    
    int min = path_length[0];
    for(int i=1; i<path_length.size();i++){
        if(path_length[i]<=min){
            min = path_length[i];
        }
    }
    
    for (int i=0; i<allpath.size();i++) {
        string tmp;
        tmp = allpath[i][1];
        if(stoi(tmp) == min){
            cout << "*"; 
        }
        cout << allpath[i] << endl; 
    }
        
    return 0;
}