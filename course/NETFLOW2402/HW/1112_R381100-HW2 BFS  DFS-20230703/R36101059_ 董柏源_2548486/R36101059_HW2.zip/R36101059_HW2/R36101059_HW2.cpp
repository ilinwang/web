/*
   pseudocode:
   Read a file line by line
   Check every characters for every line
    if line[0] == 'c'
        then skip
    else if line[0] == 't'
        then recode title_of_problem_name
    else if line[0] == 'p'
        then recode problem_type, amount of nodes and amount of arcs
    else if line[0] == 'n'
        then skip
    else if line[0] == 'a'
        then recode from_node, to_node and length

   Input a source node (s) and a sink node (t)

   -BFS Initialize
    unmark all nodes
    mark node(s)
    order(s) = 0
    LIST = {s}

   -BFS
    -While LIST != null
        select node i in LIST
        if node i is incident to admissible arc(i,j) then
            mark node j
            order(j) = order(i)+1
            add node j to LIST
        else
            delete node i from LIST
    -end

   -DFS Initialize
    LIST = {s}
    shortest_path = M
    path = null
    currentArc(s) = firstArc(s)

   -DFS
    -While LIST != null
        select node i in LIST
        -While arc(i,j) is not the deepest arc
            if node j is the target node then
                record path, num_arcs_in_path
                check shortest_path
                break inner while
            else
                add node j to LIST
                renew currentArc(i)
        -end
        reset currentArc(i)
        delete node i from LIST
    -end

   Output the indices of the reachable nodes from s in BFS ordering with its associated distance label
   Output amounts of the path of from s to t in DFS
   Output each path from s to t in DFS and mark the shortest path

   ---------------------------------------------------------------------------
*/
#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <cstdlib>
#include <typeinfo>
#include <iomanip>
#include <cctype>
#include <cstring>
#include <vector>

using namespace std;

int main() {
    // Settings
    string user_filename;
    int user_source_node =0;
    int user_sink_node =0;
    string line;
    string title_of_problem_name;
    string problem_type;
    int num_nodes =0;
    int num_arcs =0;
    int **graph;
    int arc_index_count = 0;
    char row_label;
    int *point;
    int point_index_count = 0;
    int M = 999999;
    // Open file
    ifstream myFile;
    bool check_file_open = false;
    while(check_file_open == false){
        cout << "Please input network filename (or -1 to exit) : " ;
        cin >> user_filename ;
        myFile.open(user_filename);
        if(myFile.is_open() || user_filename =="-1")
            check_file_open = true;
        else
            cout <<"failed. wrong filename."<<endl;
        if(myFile.is_open()){
            cout << "opened"<<endl;
        }
        else if( user_filename =="-1"){
            cout <<"exit"<< endl;
            return 0;
        }
    }
    // Print file content
    while (myFile.get(row_label)) {
        if(row_label == 'c'){
            getline(myFile, line);
        }
        else if(row_label == 'p'){
            myFile>>problem_type >> num_nodes >> num_arcs;
            //initialize point & graph size
            point = new int[num_nodes];
            graph = new int*[num_arcs];
        }
        else if(row_label == 'n'){
            getline(myFile, line);
        }
        else if(row_label == 'a'){
            //set array_point & array_graph
            graph[arc_index_count] = new int[3];
            myFile >> graph[arc_index_count][0] >> graph[arc_index_count][1] >> graph[arc_index_count][2];
            if(arc_index_count == 0){
                point[0] = 0;
                point[num_nodes-1] = num_arcs;
                point_index_count++;
            }
            else if(graph[arc_index_count][0] != graph[arc_index_count-1][0]){
                point[point_index_count] = arc_index_count;
                point_index_count++;
            }
            arc_index_count++;
        }
    }
    //Close file
    myFile.close();

    while(user_source_node != -1){
        cout << "Please input a source node (or -1 to exit) : " ;
        cin >> user_source_node ;
        if(user_source_node ==-1){
            cout <<"exit"<< endl;
            return 0;
        }
        else if (user_source_node > num_nodes || user_source_node < 1){
            cout <<"!!Warning!!: source node "<< user_source_node <<" does not exist"<< endl;
        }
        else{
            user_sink_node = 0;
            while(user_sink_node > num_nodes || user_sink_node < 1){
                cout << "Please input a sink node (or -1 to exit) : " ;
                cin >> user_sink_node ;
                if(user_sink_node == -1){
                    cout <<"exit"<< endl;
                    return 0;
                }
                else if (user_sink_node > num_nodes || user_sink_node < 1){
                    cout <<"!!Warning!!: sink node "<< user_sink_node <<" does not exist"<< endl;
                }
            }
        }

        //BFS & DFS
        if(user_source_node <= num_nodes && user_source_node >= 1 && user_sink_node <= num_nodes && user_sink_node >= 1){
            //BFS
            //initialize
            vector <int> BFS_LIST;
            int s = user_source_node;
            int *mark;
            mark = new int[num_nodes];
            int *order;
            order= new int[num_nodes];
            for(int i = 0; i<num_nodes; i++){
                mark[i] = 0;
                order[i] = 0;
            }
            BFS_LIST.push_back(s);
            order[s-1] = 0;

            //Search
            cout<<"BFS: "<<s<<"[0]";
            while(!BFS_LIST.empty()){
                if(point[BFS_LIST[0]-1] != num_arcs){
                    for(int i = point[BFS_LIST[0]-1]; i<point[BFS_LIST[0]] ; i++){
                        if(mark[graph[i][1]-1] == 0){
                            mark[graph[i][1]-1] = 1;
                            order[graph[i][1]-1] = order[graph[i][0]-1]+1;
                            //print out BFS results
                            cout<< " "<< graph[i][1] << "[" << order[graph[i][1]-1] << "]";
                            BFS_LIST.push_back(graph[i][1]);
                        }
                    }
                }
                BFS_LIST.erase(BFS_LIST.begin());
            }
            cout<<""<<endl;

            //DFS
            //Initialize
            vector <int> DFS_LIST;
            vector <int> num_arcs_in_path_LIST;
            vector <string> path_LIST;
            int t = user_sink_node;
            int shortest_path = M;//length of shortest_path
            string path ;
            int *currentArc;
            currentArc= new int[num_nodes];
            for(int i = 0; i<num_nodes; i++){
                currentArc[i] = point[i]; // point[i] = firstArc[i]
            }
            DFS_LIST.push_back(s);

            //Search
            while(!DFS_LIST.empty()){
                while(currentArc[DFS_LIST[DFS_LIST.size()-1]-1] < point[DFS_LIST[DFS_LIST.size()-1]]){ //to the deepest
                    if(graph[currentArc[DFS_LIST[DFS_LIST.size()-1]-1]][1] == t){ //touch the sink node
                        //record path
                        path = to_string(s);
                        for(int i = 1;i<DFS_LIST.size();i++){
                            path = path + "-" + to_string(DFS_LIST[i]);
                        }
                        path = path +"-"+to_string(t);
                        path_LIST.push_back(path);
                        //record num_arcs_in_path
                        num_arcs_in_path_LIST.push_back(DFS_LIST.size());
                        //record shortest_path
                        if(num_arcs_in_path_LIST[num_arcs_in_path_LIST.size()-1] < shortest_path){
                            shortest_path = num_arcs_in_path_LIST[num_arcs_in_path_LIST.size()-1];
                        }
                        currentArc[DFS_LIST[DFS_LIST.size()-1]-1] = point[DFS_LIST[DFS_LIST.size()-1]];//break inner while loop
                    }
                    else{
                        DFS_LIST.push_back(graph[currentArc[DFS_LIST[DFS_LIST.size()-1]-1]][1]);
                        currentArc[DFS_LIST[DFS_LIST.size()-2]-1] += 1;
                        if(currentArc[DFS_LIST[DFS_LIST.size()-1]-1] == num_arcs){
                            //pre-processing for deleting the node which currentArc already over upper-bound
                            currentArc[DFS_LIST[DFS_LIST.size()-1]-1] = point[DFS_LIST[DFS_LIST.size()-1]-1];
                            DFS_LIST.erase(DFS_LIST.end()-1);
                        }
                    }

                }
                currentArc[DFS_LIST[DFS_LIST.size()-1]-1] = point[DFS_LIST[DFS_LIST.size()-1]-1];
                DFS_LIST.erase(DFS_LIST.end()-1);

            }

            //print out DFS results

            cout<<s<<"->"<<t<<": "<<path_LIST.size()<<"paths"<<endl;
            for(int i=0; i<path_LIST.size(); i++){
                if(num_arcs_in_path_LIST[i] == shortest_path){
                    cout<<"*" ;
                }
                cout<<"["<<num_arcs_in_path_LIST[i]<<"]: "<<path_LIST[i]<<endl;
            }

        }

    }
    return 0;
}

