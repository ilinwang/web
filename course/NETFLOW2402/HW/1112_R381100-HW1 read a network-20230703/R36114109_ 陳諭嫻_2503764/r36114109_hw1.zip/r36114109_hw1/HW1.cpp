/*
    This code can be compiled and run okay.

    This code is to read a network file and let the users search the node they want
    to get all the arcs and their lengths connecting with it.

    usage:
        HW1.cpp xxx
        where xxx is the input network filename, e.g. test1.sp

    input file:
        test1.sp
        test2.sp

    compile:
        g++ HW1.cpp -o hw1

    pseudocode:
        ifstream ifs
        ifs.open(filename)
        ------
        ifs >> search;
        if search == c
            continue;
        if search == t
            pn = problem name;
        if search == p
            pt = problem type;
            n = # nodes;
            m = # arcs;
        if search == n
            n = # nodes;
            L[i][j] = M = 10000;
            A[i][j] = 0;
        if search == a
            ifs >> node1 >> node2 >> length;
            L[node1 - 1][node2 - 1] = arcs' length from node 1 to node 2;
            A[node1 - 1][node2 - 1] = arcs' index;
        ------
        user input source node s
        if s > 0 && s < n
            if L[i][s - 1] != M
                print "arc[A[i][s - 1]]: i + 1 - s : L[i][s - 1]""
            if L[s - 1][i] != M
                print "arc[A[s - 1][i]]: s - i + 1 : L[s - 1][i]""
        if s < 0 || s > n
            print "!!Warning!!: node s does not exist"
        if s == 0
            break;

        free memory
        delete L[i][j];
        delete A[i][j];

    coded by Yu-Shian Chen, ID: r36114109, email: yushian99@gmail.com
    date: 2023.02.19
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <cmath>
#include <math.h>
#include <iomanip>
using namespace std;

int main(){
    cout << "Please input network filename: "; // ask users to input files
    char filename[100];
    cin >> filename;

    ifstream ifs;
    ifs.open(filename);

    while (ifs.fail()){
        cout << "Input file failed\n";
        cout << "Please input network filename: ";
        cin >> filename;
        ifs.open(filename);
    }

    vector<string> T; // t: title of the problem_name
    vector<string> P; // p: problem type(sp), n (# nodes), m (# arcs)

    string sall;
    string search; // the first letter for searching
    string pn;     // problem name

    string pt; // problem type
    int n = 0; // # nodes
    int m = 0; // # arcs

    int node1, node2;
    double length;
    int arcIndex = 0;
    int M = 10000; // initialize every arc to be a large number first

    double **L; // dynamically allocate memory to L for arcs' length
    int **A; // dynamically allocate memory to A for arcs' index

    while (getline(ifs, sall)){
        ifs >> search;
        // if the first letter is c, ignore
        if (search != "c"){ 
            if (search == "t"){ // if the first letter is t, save the problem name as pn
                ifs >> pn; // save the problem name as pn
                T.push_back(pn);
                // cout << pn << "\n";
            }

            // if the first letter is p,
            if (search == "p"){  
                ifs >> pt >> n >> m; // save the problem type as pt, get the # nodes as n and # arcs as m
                P.push_back(pt);
                // cout << pt << n << m << "\n";
            }

            // if the first letter is n, 
            if (search == "n"){ 
                ifs >> n; // save the # nodes as n
                // N.push_back(n);
                // cout << n << "\n";

                L = new double *[n]; // new memory
                A = new int *[n]; // new memory

                for (int i = 0; i < n; i++){
                    L[i] = new double[n];
                    A[i] = new int[n];
                    for (int j = 0; j < n; j++){
                        L[i][j] = M; // let the length of arcs to be a large num M = 10000 first
                        A[i][j] = 0; // let the index to be 0 first
                    }
                }
            }

            // if the first letter is a, 
            if (search == "a"){
                ifs >> node1 >> node2 >> length; // save nodes and length
                // N.push_back(n);
                L[node1 - 1][node2 - 1] = length; // store the length of node 1 to node 2
                A[node1 - 1][node2 - 1] = ++arcIndex; // add the index for arcs one by one
                // cout << node1 << "," << node2 << "," << length << "," << arcIndex << "\n";
                // cout << L[1][2];
            }
        }
    }
    ifs.close();

    int s;
    cout << "Please input a source node: "; // ask the users to input the node they wanna search
 
    while (cin >> s){
        // if the node exsits, find all the nodes connected to it and the length between them
        if (s > 0 && s < n){
            for (int i = 0; i < n; i++){
                if (L[i][s - 1] != M){
                    cout << "arc[" << A[i][s - 1] << "]: " << i + 1 << "-" << s << " : " << L[i][s - 1] << endl;
                }
                if (L[s - 1][i] != M){
                    cout << "arc[" << A[s - 1][i] << "]: " << s << "-" << i + 1 << " : " << L[s - 1][i] << endl;
                }
            }
            cout << "Please input a source node: ";
        }

        // cin >> s;
        // if the node doesnt exsit
        if (s < 0 || s > n){
            cout << "!!Warning!!: node " << s << " does not exist" << endl;
            cout << "Please input a source node: ";
            // cin >> s;
        }
        // to end the code
        if (s == 0)
            break;
    }

    // free momory
    for (int i = 0; i < n; i++){
        delete[] L[i];
        delete[] A[i];
    }
    delete[] L;
    delete[] A;

    return 0;
}