/*
   This code can be compiled and run ok.

   Purpose:
     This code can read a network file and source node,
     then print out all arcs (and their lengths) connecting with the node.

   Usage:
     Firstly, user request to input a filename. If filename is invalid, it will print error message and terminate.
     Secondly, user request to input a source node. If source node is invalid, it will print error message and terminate,
     else, it will print out all arcs (and their lengths) connecting with the node.

   Input file:
     test1.sp
     test2.sp

   Output files:
     None.

   Compile:
     g++ -o h34091160_hw1 h34091160_hw1.cpp

 Pseudocode:
   Begin
    Input filename
    Let n=0, m=0
    While reading each line in the file
      Read first word
      If first[0] = 't', then Problem name <- first
      Else if first[0] = 'p', then
      Begin
        Problem type, n, m <- first[1]
      End
      Else if first[0] = 'a', then do
        index+=1
        start_node, end_node, distance <- first
        Add node to the list
    End
    Input source node
    If source node <=0 or source node > n, then print warning message
    Else print list
    Delete list
  End

   coded by 李佳哲, ID: h34091160, email: h34091160@gs.ncku.edu.tw
   date: 2023.02.18
*/

#include <string>
#include <fstream>
#include <sstream>
#include <iostream>

using namespace std;

struct Node {  // Define the structure of node
    int number;
    double distance;
    int index;
    Node* next;
};

class Adj_list {  // Define a class that implement adjacency list
    Node* head;

public:
    Adj_list() {  // Initialize
        head = nullptr;
    }

    void addNode(int node_num, double arc_distance, int arc_index) {  // Add node to the adj. list
        Node* newNode = new Node;
        newNode->number = node_num;
        newNode->distance = arc_distance;
        newNode->index = arc_index;
        newNode->next = nullptr;

        if (head == nullptr) {
            head = newNode;
        } else {
            Node* curr = head;
            while (curr->next != nullptr) {
                curr = curr->next;
            }
            curr->next = newNode;
        }
    }

    void printList_outdegree(int i) {  // print out the adj. list of node i by out-degree
        Node* curr = head;
        while (curr != nullptr) {
            cout << "  arc[" << curr->index << "]: " << i + 1 << "-" << curr->number + 1 << " : " << curr->distance << endl;
            curr = curr->next;
        }
    }

    void printList_indegree(int i) {  // print out the adj. list of node i by in-degree
        Node* curr = head;
        while (curr != nullptr) {
            cout << "  arc[" << curr->index << "]: " << curr->number + 1 << "-" << i + 1<< " : " << curr->distance << endl;
            curr = curr->next;
        }
    }
};

int main()
{
    string filename;
    cout << "Please input network filename: ";    // User input filename

    getline(cin, filename);
    ifstream file(filename);

    if(!file.is_open()){
        cerr << "Failed to open " << filename << endl;
        return 1;
    }

    Adj_list* L_indegree;  // Save the in-degree adj. list
    Adj_list* L_outdegree;  // Save the out-degree adj. list
    string s, first, problem_type, problem_name;
    int n = 0;    // number of nodes
    int m = 0;    // number of arcs
    int start_node = 0;    // starting node of the arc
    int end_node = 0;    // ending node of the arc
    int distance = 0;    // distance of the arc
    int index = 0;    // index of the arc

    while (getline(file, s)) {
        istringstream stringfile(s);
        stringfile >> first;    // Read the first word of the line

        if(first[0]=='t'){    // Case 1: When read 't', record title of the problem name
            stringfile >> problem_name;
        }
        else if(first[0]=='p'){    // Case 2: When read 'p', record problem type, # of node and arc
            stringfile >> problem_type >> n >> m;
            L_outdegree = new Adj_list[n];    // L records the distance
            L_indegree = new Adj_list[n];    // L records the distance
        }
        else if(first[0]=='a'){    // Case 3: When read 'a', record start node, end node and the distance between them
            stringfile >> start_node >> end_node >> distance;
            index++;
            L_outdegree[start_node-1].addNode(end_node-1, distance, index);
            L_indegree[end_node-1].addNode(start_node-1, distance, index);
        }
    }

    /*
    // print out the adj. list
    for(int i=0;i<n;i++){
        L_outdegree[i].printList_outdegree(i);
        L_indegree[i].printList_indegree(i);
    }
    */

    int source_node = 0;
    cout << "Please input a source node: ";    // User input source node
    cin >> source_node;

    if(source_node <= 0 || source_node > n){    // Print warning message
        cout << "\n!!Warning!!: Node " << source_node << " does not exist." << endl;
    }
    else {    // Print out all arcs (and their distance) connecting with the node
        L_indegree[source_node-1].printList_indegree(source_node-1);
        L_outdegree[source_node-1].printList_outdegree(source_node-1);
    }

    delete[] L_outdegree;   // Clear the memory
    delete[] L_indegree;

    file.close();    // Close file

    return 0;
}
