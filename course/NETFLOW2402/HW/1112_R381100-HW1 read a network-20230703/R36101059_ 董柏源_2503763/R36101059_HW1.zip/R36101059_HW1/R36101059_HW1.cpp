#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <cstdlib>
#include <typeinfo>
#include <iomanip>
#include <cctype>
#include <cstring>

using namespace std;


int main() {
    // Settings
    string user_filename;
    int user_source_node;
    string line;
    string title_of_problem_name;
    string problem_type;
    int num_nodes;
    int num_arcs;
    float length;
    int from_node;
    int to_node;
    float **graph;
    int **arc_index;
    int arc_index_count = 1;
    int M = 100000;


    // Open file
    ifstream myFile;
    bool check_file_open = false;
    while(check_file_open == false){
        user_source_node = 0; //initialize

        cout << "Please input network filename (or -1 to exit) : " ;
        cin >> user_filename ;
        myFile.open(user_filename);
        if(myFile.is_open() || user_filename =="-1")
            check_file_open = true;
        else
            cout <<"failed. wrong filename."<<endl;


        if(myFile.is_open()){
            cout << "opened"<<endl;

            // Print file content
            while (getline(myFile, line)) {
                int i = 0;
                string temp_str = "";
                if (line[0] == 't'){
                    i = 2;
                    while(i<line.size()){
                        title_of_problem_name += line[i];
                        i++;
                    }
                    cout << "title_of_problem_name : "<<title_of_problem_name << endl;
                }
                else if (line[0] == 'p'){
                    i = 2;
                    while(i<line.size() && (line[i]!='	')){
                        problem_type += line[i];
                        i++;
                    }
                    cout << "problem_type : " << problem_type << endl;

                    i = line.size()-1;
                    while((line[i]!='	')){
                        i--;
                    }
                    temp_str = line.erase(0,i+1);
                    num_arcs = atoi(temp_str.c_str());
                    cout << "Number_arcs : " << num_arcs << endl;
                }
                else if (line[0] == 'n'){
                    i = 2;
                    while(i<line.size()){
                        temp_str += line[i];
                        i++;
                        if(line[i] == '	'){
                            i=line.size();
                        }
                    }
                    num_nodes = atoi(temp_str.c_str());
                    cout << "Number_nodes : " << num_nodes << endl;

                    graph = new float*[num_nodes+1];
                    for(i = 0; i < num_nodes+1; i++){
                        graph[i] = new float[num_nodes+1];
                        for (int j=0; j < num_nodes+1; j++){
                            graph[i][j] = M;
                        }
                    }
                    arc_index = new int*[num_nodes+1];
                    for(i = 0; i < num_nodes+1; i++){
                        arc_index[i] = new int[num_nodes+1];
                    }
                }
                else if (line[0] == 'a'){
                    from_node = 0;
                    to_node = 0;
                    length = 0;
                    i = 2;
                    int temp_i = 0;

                    while(i<line.size()){
                        if(!isspace(line[i])){
                            temp_str += line[i];
                            if(isspace(line[i+1])){
                                temp_i = i+2;
                                i= line.size();
                            }
                        }
                        i++;
                    }
                    i = temp_i;
                    from_node = atoi(temp_str.c_str());
                    temp_str = "";

                    while(i<line.size()){
                        if(!isspace(line[i])){
                            temp_str += line[i];

                            if(isspace(line[i+1])){
                                temp_i = i+2;
                                i= line.size();
                            }
                        }
                        i++;
                    }
                    i = temp_i;
                    to_node = atoi(temp_str.c_str());
                    temp_str = "";

                    while(i<line.size()){
                        if(!isspace(line[i])){
                            temp_str += line[i];
                            if(isspace(line[i+1])){
                                i= line.size();
                            }
                        }
                        i++;
                    }
                    length = atof(temp_str.c_str());
                    graph[from_node][to_node] = length;
                    arc_index[from_node][to_node] = arc_index_count;
                    arc_index_count++;
                    //cout <<  from_node<<" "<< to_node<< " "<<fixed << setprecision(2)<< graph[from_node][to_node] << endl;
                }
            }

            while(user_source_node != -1 && user_source_node != -2){
                cout << "Please input a source node (or -1 to exit , -2 to change input file) : " ;
                cin >> user_source_node ;
                if(user_source_node <= num_nodes && user_source_node >= 1){
                    for(int i = 1; i < num_nodes+1; i++){
                        if(graph[i][user_source_node] != M){
                            //node_exist = true;
                            cout <<"arc["<<arc_index[i][user_source_node]<<"]:"<< i <<"-"<< user_source_node<< ":"<<fixed << setprecision(2)<< graph[i][user_source_node] << endl;
                        }
                    }

                    for(int i = 1; i < num_nodes+1;i++){
                        if(graph[user_source_node][i] != M){
                            //node_exist = true;
                            cout <<"arc["<<arc_index[user_source_node][i]<<"]:"<< user_source_node <<"-"<<i<< ":"<<fixed << setprecision(2)<< graph[user_source_node][i] << endl;
                        }
                    }
                }
                else if (user_source_node == -1){
                    cout <<"exit"<< endl;
                }
                else if (user_source_node == -2){
                    cout <<"change input file"<< endl;
                    check_file_open = false;
                }
                else{
                    cout <<"!!Warning!!: node "<< user_source_node <<" does not exist"<< endl;
                }
            }

            //Close file
            myFile.close();
        }
        else if(user_filename == "-1")
            cout <<"exit"<< endl;

    }


    return 0;
}
