/*
   This code can be compiled and run ok.

   This is to read a network
   
   usage:
     1. input the name of a sp file
     2. input a source node
  
   input file:
     test1.sp
     test2.sp
	   
   output files:
     none
	   
   compile:
     gcc -o H34081092_hw1 H34081092_hw1.cpp
   
   pseudocode:
    ----------
    split( string line, char x, char tab)
    ------
        for i=0 to line.length()
            if line[i] = x or line[i]=tab then
                if tmp!="" then
                    result.push_back(tmp);
                    tmp = "";
            else
                tmp = tmp + line[i];
                if i+1 = line.length() then
                    result.push_back(tmp);
        return result;
    ----------

    main
    -----
    while getline(myFile, line)
        if line[0]='t' then
            tmp = split(line,' ','\t');
            name = tmp[1];
        else if line[0]='p' then
            tmp = split(line,' ', '\t');
            type = tmp[1];
            n = stoi(tmp[2]);
            m = stoi(tmp[3]);

            weight = new int* [n+1];
            for i=0 to n
                weight[i] = new int [n+1];
                for j=0 to n
                    weight[i][j] = bigM;
            arc = new int* [m+1];
            for i=1 to m
                arc[i] = new int [2];

        else if line[0]='a' then
            tmp = split(line,' ', '\t');
            arc[c][0]=stoi(tmp[1]);
            arc[c][1]=stoi(tmp[2]);
            weight[arc[c][0]][arc[c][1]] = stoi(tmp[3]);
            c=c+1;
    

    for int i=1 to m
        if arc[i][0]=s or arc[i][1]=s then
            index =1;
            cout << "arc[" << i <<"] ";
            cout << arc[i][0];
            cout << "->";
            cout << arc[i][1];
            cout << ":" << weight[arc[i][0]][arc[i][1]];
            cout << endl;

    while index = 0
        cout << "!!Warning!!: node " << s <<" does not exist" << endl;
        cout << "Please input a source node: ";
        cin >> s;
        for i=1 to m
            if arc[i][0]=s or arc[i][1]=s then
                index =1;
                cout << "arc[" << i <<"] ";
                cout << arc[i][0];
                cout << "->";
                cout << arc[i][1];
                cout << ":" << weight[arc[i][0]][arc[i][1]];
                cout << endl;

    return 0;
 
   coded by Yi-chen Chen, ID: H34081092, email: H34081092@gs.ncku.edu.tw
   date: 2023.03.05
*/

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <sstream>
#include <vector>
using namespace std;

vector<string> split( string line, char x, char tab){
    vector<string> result;
    string tmp = "";

    for(int i=0; i<line.length(); i++){
        if(line[i] == x | line[i]==tab){
            if(tmp!=""){
                result.push_back(tmp);
                tmp = "";
            }
            
        }else{
            tmp += line[i];
            // cout << tmp <<endl;
            if (i+1 == line.length()){
                result.push_back(tmp);
            }
            
        }
    }
    return result;
}

int main(){

    string name, type;
    int n ,m;
    vector<string> tmp;
    ifstream myFile;
    string filename;
    cout<<"Please input network filename:";
    cin>>filename;
    myFile.open(filename);
    string line;
    int ** weight ;
    int ** arc;
    int c=1;
    int bigM=10000;

    while (getline(myFile, line)) {
        if (line[0]=='t'){
            tmp = split(line,' ','\t');
            name = tmp[1];
        }
        else if(line[0]=='p'){
            tmp = split(line,' ', '\t');
            type = tmp[1];
            n = stoi(tmp[2]);
            m = stoi(tmp[3]);

            weight = new int* [n+1];
            for(int i=0;i<=n;i++){
                weight[i] = new int [n+1];
                for(int j=0;j<=n;j++){
                    weight[i][j] = bigM;
                }
            }
            arc = new int* [m+1];
            for(int i=1; i<=m;i++){
                arc[i] = new int [2];
            }

        }else if(line[0]=='a'){
            tmp = split(line,' ', '\t');
            
            arc[c][0]=stoi(tmp[1]);
            arc[c][1]=stoi(tmp[2]);
            weight[arc[c][0]][arc[c][1]] = stoi(tmp[3]);
            c+=1;
        }
    }

    cout <<"name: "<< name << endl;
    cout <<"type: "<< type << endl;
    cout <<"n: "<< n << endl;
    cout <<"m: "<< m << endl;
    
    //print adjacency matrix
    // for(int i=0;i<=n;i++){
    //     for(int j=0;j<=n;j++){
    //         cout << weight[i][j];
    //         cout << " , ";
    //     }
    //     cout << endl;
    // }

    //print arc
    //cout <<"arc:" << endl;
    // for (int i=1; i<=m;i++){
    //     cout << "arc[" << i <<"] ";
    //     cout << arc[i][0];
    //     cout << "->";
    //     cout << arc[i][1];
    //     cout << endl;
    // }

    // Close file
    myFile.close();

    //input source node s
    int s;
    cout << "Please input a source node: ";
    cin >> s;
    // s=1;
    
    int index=0;
    for(int i=1;i<=m;i++){
        if(arc[i][0]==s | arc[i][1]==s){
            index =1;
            cout << "arc[" << i <<"] ";
            cout << arc[i][0];
            cout << "->";
            cout << arc[i][1];
            cout << ":" << weight[arc[i][0]][arc[i][1]];
            cout << endl;
        }
    }
    while(index == 0){
        cout << "!!Warning!!: node " << s <<" does not exist" << endl;
        cout << "Please input a source node: ";
        cin >> s;
        for(int i=1;i<=m;i++){
            if(arc[i][0]==s | arc[i][1]==s){
                index =1;
                cout << "arc[" << i <<"] ";
                cout << arc[i][0];
                cout << "->";
                cout << arc[i][1];
                cout << ":" << weight[arc[i][0]][arc[i][1]];
                cout << endl;
            }
        }
    }

    return 0;
}