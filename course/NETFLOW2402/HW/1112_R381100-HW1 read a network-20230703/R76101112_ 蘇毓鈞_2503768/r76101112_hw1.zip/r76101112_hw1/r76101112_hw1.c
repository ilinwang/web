/*
	This program is to read a network
	compile:
		gcc -o r76101112_hw1 r76101112_hw1.c
        run: ./r76101112_hw1 
	This code can be compiled and run ok on Ubuntu.
	coded by SU YU CHUN, ID: R76101112, email: R76101112@gs.ncku.edu.tw
	date: 2023/2/26 
*/
#include <stdlib.h>
#include <stdio.h>
int main(){
	FILE *fp;
	char s[1024],fileName[1024],problemName[1024];
	double **ptr=NULL,t;
	int i,j,node,count,sourceNode;
	printf("Please input network filename:");
	scanf("%s",fileName);
	if((fp=fopen(fileName,"r"))==NULL) {
		printf("Open file error!!\n");
		system("pause");
		exit(0);
	}
	while(!feof(fp)) {
		fgets(s,1024,fp);
		
		if(s[0]=='n') {
			node=s[2]-48;
			ptr=(double **)malloc(sizeof(double *)*node);
			for(i=0;i<node;i++) {
				ptr[i] = (double *)malloc(sizeof(double)*node);
			}
			for(i=0;i<node;i++){
				for(j=0;j<node;j++){
					ptr[i][j]=0.0;
				}
			}  
		}
		if(s[0]=='a') {
			ptr[(s[2]-48)-1][(s[4]-48)-1]=(s[6]-48)+(s[8]-48)*0.1;
		}
		if(s[0]=='t'){
			j=0;
			for(i=2;s[i]!='\n';i++){
				problemName[j]=s[i];
				j++;
			}
			
		}
	}
	printf("Please input a source node:");
	scanf("%d",&sourceNode);
	while(sourceNode>node || sourceNode<0) {
		printf("!!Warning!!:node %d does not exist\n",sourceNode);
		printf("Please input a source node:");
		scanf("%d",&sourceNode);
	}
	count=0;
	for(i=0;i<node-1;i++) {
		for(j=0;j<node-1;j++){
			if(ptr[i][j]!=0.0){
				count++;
				if(i==sourceNode-1 || j==sourceNode-1){
					printf("arc[%d]:%d-%d:%.2f\n",count,i+1,j+1,ptr[i][j]);
				}
			}
		}
	}
	fclose(fp);
	
	return 0;
}
