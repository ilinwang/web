/*
    This code can be compiled and run ok.

    input file: test1.sp

    purpose: 
        1.Read a network file with a format similar to test1.sp and test2.sp
        2.Ask the user to input a node index

    usage:
        According to the dimension of the network (e.g. n=1000, m=10000), your code should dynamically allocate memory to store information for n nodes and m arcs, as well as their satellite data (e.g. length of an arc).
    
    compile:
        visual studio code

    pseudo-code:
        input the file
        use Data Structures and Algorithms
         

    coded by Yi-Jing Wang, ID: r36111193, email: sandy19980920@gmail.com
    date: 2023.02.21
*/


#include<iostream>
#include<fstream>
#include<string>
#include<vector>

using namespace std;

int main() {
    string filename;
    cout << "enter the filename: ";
    cin >> filename;
    ifstream infile(filename, std::ios::in); // 開啟檔案
    if (!infile) {
        cout << "檔案名稱錯誤" << endl;
        return 1;
}

    int source;
    cout << "source node : " ; //輸入source node
    cin >> source;

    int node_quantity; //node數
    int arc_quantity; //arc數
    string gar; //不需要用到的字串

    char test; //檔案搜尋

    int node1;
    int node2;
    double arc;

    string line;

    double ** array ; //動態矩陣
    int qq=0;

    while (infile.get(test)) {     // 逐行讀取

        if (test == 'p') {    //判斷是否是p開頭,看arc跟node數量
            infile >> gar >> node_quantity >> arc_quantity;

            array = new double * [arc_quantity];

    }
        else if (test == 'a') {   // 判斷是否是a開頭
            infile >> node1 >> node2 >> arc;

            array[qq] = new double[3];
            array[qq][0]= node1;
            array[qq][1]= node2;
            array[qq][2]= arc;

            qq++;        

    }
        else if (test == 'c' || test == 't' || test == 'n') { //若是c,t,n開頭則跳過
            getline(infile, line);
    }
}

    if (source > node_quantity) { // 超過node數量
        cout << "!!!Warning!!: node 7 does not exist" << endl;
}
    else {
        for (int i = 0; i < arc_quantity; i++) {
            if (array[i][0]==source||array[i][1]==source) {
            cout << "arc[" << i+1 << "]: " << array[i][0] << "-" << array[i][1] << ":" << array[i][2] << endl;
        }
           
    }
}

}