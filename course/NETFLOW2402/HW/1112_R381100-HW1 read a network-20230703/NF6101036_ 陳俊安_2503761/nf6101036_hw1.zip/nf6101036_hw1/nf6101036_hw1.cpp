/*
   This code can be compiled and run ok.

   This code will read a network and output the associate arc base on input node.
   
   usage:
     you may input a file which contains a network data and enter a source node, 
     the code will output the associated arcs and their length.
  
   input file:
     test1.sp
     test2.sp
	   
   output files:
     No output file
	   
   compile:
     g++ -o ./nf6101036_hw1.cpp
   
   pseudocode:
   1.read each line from the file.
    according to the first letter of each line, the code will have different functions.

    while(get each line)
    {

        if first_letter = 'p'
        {
            tokenize(s,delim,result);
            num_of_node=stoi(result[2]);
            num_of_arc=stoi(result[3]);
        }

        built a dynamic array base on num_of_node
        built a dynamic array base on num_of_arc

        if first_letter = 'a'
        {
            tokenize(s,delim,result);
            from_node=stoi(result[1]);
            node_b=stoi(result[2]);
            arc_len=stof(result[3]);
        }
    }
   ------

   coded by Chun-An Chen, ID: nf6101036, email: nf6101036@gs.ncku.edu.tw
   date: 2023.03.05
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <cstring>
#include <typeinfo>
#include <array>
#include <cstdio>
using namespace std;

//tokenize function is to split strings base on deliminator to a vector
void tokenize(string const &str, const char* delim,
            vector<string> &out)
{
    char *token = strtok(const_cast<char*>(str.c_str()), delim);
    while (token != nullptr)
    {
        out.push_back(string(token));
        token = strtok(nullptr, delim);
    }
}

struct arc_info{
    int from_node;
    int to_node;
    float length;
};

struct adj_list{
    vector<int> in_arc_idx;
    vector<int> out_arc_idx;
};

int main() {
    
    string filename;
    cout<<"Enter a filename"<<endl;
    cin >> filename;
    // filename = "test1.sp";
    ifstream ifile(filename);
    if(!ifile.is_open())
    {
        cout<<"Error, file does not exist!!"<<endl;
        exit(0);
    }

    vector<string> rr;
    vector<adj_list> adj_list_vec; //adjacency list vector
    vector<arc_info> arc_info_vec; //arc information vector
    string s;
    char symbol;
    int num_of_node, num_of_arc, from_node, to_node;
    float arc_len;
    int arc_idx = 0;
    

    //read each line
     while (getline(ifile, s))
    {
        //cout << s << "\n";
        //rr.push_back(s);

        //extract the number of node and arc
        if(s[0] == 'p')
        {
            vector<string> result;
            const char* delim = "	, ,	";
            tokenize(s,delim,result);
                
            num_of_node = stoi(result[2]);
            num_of_arc = stoi(result[3]);
            cout << "num of node : " << num_of_node << endl;
            cout << "num of arc : " << num_of_arc << endl;
        }

        //define the size of adj_list_vec and arc_info_vec
        adj_list_vec.resize(num_of_node+1);
        arc_info_vec.resize(num_of_arc+1);


        if(s[0] == 'a')
        {
            arc_idx++;
            vector<string> result;
            const char* delim = "	";
            tokenize(s,delim,result);
            from_node = stoi(result[1]);
            to_node = stoi(result[2]);
            arc_len = stof(result[3]);
            struct arc_info arc;
            arc.from_node = from_node;
            arc.to_node = to_node;
            arc.length = arc_len;
            arc_info_vec[arc_idx] = arc; //store arc information to arc_info_vec
            adj_list_vec[from_node].out_arc_idx.push_back(arc_idx);
            adj_list_vec[to_node].in_arc_idx.push_back(arc_idx);
            result.clear();
            
        }

    }

    ifile.close();

    while(true)
    {
        cout<<"Please input a source node"<<endl;
        int input_node;
        cin >> input_node;
        if(input_node > num_of_node || input_node <= 0)
        {
            cout<<"!!Warning!!: node " + to_string(input_node) + " does not exist"<<endl;
        }
        else
        {

            //print outgoining arc of input node
            for (int i = 0; i < adj_list_vec[input_node].out_arc_idx.size(); i++)
            {
                int from_nd, to_nd, idx;
                float len;
                idx = adj_list_vec[input_node].out_arc_idx[i];
                from_nd = arc_info_vec[idx].from_node;
                to_nd = arc_info_vec[idx].to_node;
                len = arc_info_vec[idx].length;
                printf("arc[%d]: %d-%d : %.2f\n",idx,from_nd,to_nd,len);
            }

            //print incomming arc of input node
            for (int i = 0; i < adj_list_vec[input_node].in_arc_idx.size(); i++)
            {
                int from_nd, to_nd, idx;
                float len;
                idx = adj_list_vec[input_node].in_arc_idx[i];
                from_nd = arc_info_vec[idx].from_node;
                to_nd = arc_info_vec[idx].to_node;
                len = arc_info_vec[idx].length;
                printf("arc[%d]: %d-%d : %.2f\n",idx,from_nd,to_nd,len);
            }
        }
    }

    return 0;
}