/*
    This code can be compiled and run ok.

    purpose:
        Read testx.sp files, store data into adjacency list,
		and print out all arcs connecting with the input node.

    usage:
        h34086034_hw1  no output file  text1.sp

    input file:
        text1.sp
        text2.sp
        text3.sp
        text4.sp
        text5.sp

    output file:
        no

    compile:
        g++ -o h34086034_hw1 h34086034_hw1.cpp

    pseudocode:
    input file name and read file
    ------
    Read problem name:
    while read line by line
        if str[0] = 't'
		    then problem_name = str.substr(2);
                 break;
    ------
    Read problem type, m and n:
    while read line by line
        if str[0] = 'p'
		    then for i = 0 to str.size()-1
                    if str[i] is a number
                        then x = i;
                             break;
                 problem_type = str.substr(0,x).substr(2);
                 temp = str.substr(x);

                 for i = 0 to temp.size()-1
                    if temp[i] is not a number
                        then x = i;
                             break;
                 m = stoi(temp.substr(x+1));

        if str[0] == 'n'
		    then n = stoi(str.substr(2));
                 break;
    ------
    define adjacency linked lists
    ------
    Store from, to, length into vector:
    while read line by line
		if str[0] = 'a'
            then for i = 0 to str.size()-1
                 if str[i] is a number
                    then x = i;
                         break;
            temp = str.substr(x);
            for i = 0 to temp.size()-1
                if temp[i] is not a number
                    then x = i;
                         break;
            n1 = stoi(temp.substr(0,x));

            temp = temp.substr(x);
            for i = 0 to temp.size()-1
                if temp[i] is a number
                    then x = i;
                         break;
            temp = temp.substr(x);
            for i = 0 to temp.size()-1
                if temp[i] is not a number
                    then x = i;
                         break;
            n2 = stoi(temp.substr(0,x));

            temp = temp.substr(x);
            for i = 0 to temp.size()-1
                if temp[i] is a number
                    then x = i;
                         break;
            len = temp.substr(x);
            arc[n1].push_back(n2);
            arc_length[n1].push_back(len);
    ------
    Store number of arc:
    for i = 1 to n
        for j = 0 to arc[i].size()-1
            arc_num[i].push_back(z);
            z++;
    -----
    input a node
    -----
	for i = 1 to n
        for j = 0 to arc[i].size()-1
            if i = num or arc[i][j] = num
                then print << "arc[" << arc_num[i][j] << "]: " << i << "-" << arc[i][j] << " : " << arc_length[i][j];
    -----
	file.close();
	return 0;

    coded by Zi-Yun Lin, ID: H34086034, email: celine20001024@gmail.com
    date: 2023.03.01
*/

#include <iostream>
#include <fstream>
#include <string>
#include<vector>
using namespace std;

int main(){

	string fname; //file name

	cout << "Please input network filename: ";
	cin  >> fname;
	cout << endl;

	ifstream file; //read file
	file.open(fname.c_str());

	string str, temp; //str: each line in file, temp: temporary
	string problem_name, problem_type;
	int n1, n2; //n1: from, n2: to
	string len; //arc length
    int n = 0, m = 0, x = 0; //x is used for substr()

    while(getline(file,str)){
        //read problem_name
        if(str[0] == 't'){
		    problem_name = str.substr(2);
		    break;
    }}

	while(getline(file,str)){
        //read problem_type, m
        if(str[0] == 'p'){
		    for (int i = 0; i < str.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            problem_type = str.substr(0,x).substr(2);
            temp = str.substr(x);
            for (int i = 0; i < temp.size(); i++){
                if (isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            m = stoi(temp.substr(x+1));
        }
        //read n
        if(str[0] == 'n'){
		    n = stoi(str.substr(2));
		    break;
        }
    }

    vector<int> arc[n+1]; //store from to
    vector<int> arc_num[n+1]; //store number of arc
    vector<string> arc_length[n+1]; //store arc length

    while(getline(file,str)){
		if(str[0] == 'a'){
            //split str for node1
            for(int i = 0; i < str.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n1 = stoi(temp.substr(0,x));
            //split str for node2
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n2 = stoi(temp.substr(0,x));
            //split str for arc length
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            len = temp.substr(x);
            arc[n1].push_back(n2);
            arc_length[n1].push_back(len);
        }
    }

    //num of arc
    int z = 1;
    for(int i = 1; i <= n; i++){
        for(int j = 0; j < arc[i].size() ; j++){
            arc_num[i].push_back(z);
            z++;
        }
    }

    for(int i = 1; i <= n; i++){
        cout << i ;
        for(int j = 0; j < arc[i].size() ; j++){
            cout << "->" << arc[i][j];
        }
        cout << endl;
    }

    int num = 1;
    cout << "Please input a source node: ";
	cin  >> num;
	cout << endl;

	if(num > n){
        cout << "!!Warning!!: node " << num << " does not exist" << endl;
        cout << "Please input a source node: ";
        cin  >> num;
        cout << endl;
	}

	for(int i = 1; i <= n; i++){
        for(int j = 0; j < arc[i].size() ; j++){
            if(i == num || arc[i][j] == num){
                cout << "arc[" << arc_num[i][j] << "]: " << i << "-" << arc[i][j] << " : " << arc_length[i][j] << endl;
            }
        }
    }

	file.close();
	return 0;
}
