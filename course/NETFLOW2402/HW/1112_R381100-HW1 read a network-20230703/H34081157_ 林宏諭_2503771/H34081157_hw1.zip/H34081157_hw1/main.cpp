
#include <iostream>
#include <fstream>

using namespace std;

int main(int argc, const char * argv[]) {
    
    string filename;
    ifstream file;
    cout << "Enter filename: ";
    cin >> filename;
    file.open(filename,ios::in);
    string line,problem;
    int n,m;
    int ** matrix;
    int temp_i,temp_j;
    while (getline(file,line)) {
        char head;
        file >> head;
        if (head == 'p') {
            file >> problem >> n >> m;
            matrix = new int * [n+1];
            for (int i=1; i<=n; i++)
                matrix[i] = new int [n+1];
            for (int i=1; i<=n; i++)
                for (int j=1; j<=n; j++)
                    matrix[i][j] = 0;
        }
        else if (head == 'a') {
            file >> temp_i >> temp_j;
            file >> matrix[temp_i][temp_j];
        }
    }
    int source;
    int curr_arc = 0,count =0;
    cout << "Please input a source node: ";
    cin >> source;
    for (int i=1; i<=n; i++) {
        for (int j=1; j<=n; j++) {
            if (matrix[i][j] != 0) {
                curr_arc += 1;
                if (i == source or j == source) {
                    cout << "arc[" << curr_arc << "]: " << i << "-" << j << " : " << matrix[i][j] << endl;
                    count++;
                }
            }
        }
    }
    if (count == 0) {
        cout << "!!Warning!!: node " << source << " does not exist" << endl;
    }
    return 0;
}
