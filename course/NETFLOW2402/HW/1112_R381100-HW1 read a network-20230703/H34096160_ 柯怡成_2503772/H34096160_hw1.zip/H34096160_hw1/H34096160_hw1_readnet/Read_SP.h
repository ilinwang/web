# include <fstream>
# include <sstream>
using namespace std;


#ifndef READ_SP_H_INCLUDED
#define READ_SP_H_INCLUDED
/*
the Class representing a node of linked list
Content functions include:
- Link_List_Node: constructor
- get_next: Get pointer of next node
- set_next: Set pointer of next node
- print_Forward: print forward arc of this node
- print_Backward: print backward arc of this node
Content variables include:
- connect_point : the peer node of the arc stored in this node
- arc_number : the index of the arc stored in this node
- distance: the distance of the arc stored in this node
- next/prev: the pointer to next/prev nodes
*/
class Link_List_Node{
public:
    Link_List_Node(Link_List_Node *prev_node, int connected_node, int arc_number, double distance)
        :prev(prev_node), connect_point(connected_node), arc_number(arc_number), distance(distance) { }
    Link_List_Node *get_next(){ return next; }
    void set_next(Link_List_Node* lln){ next = lln; }
    void print_Forward(int test_node){cout << "\t arc[" << arc_number << "]: " << test_node << "->" << connect_point << ": " << distance << endl;}
    void print_Backward(int test_node){cout << "\t arc[" << arc_number << "]: " << connect_point << "->" << test_node << ": " << distance << endl;}

private:
    int connect_point, arc_number;
    double distance;
    Link_List_Node *next = NULL, *prev = NULL;
};

/*
Ū���ɮר��x�s�� Matrix �榡
input filename(str)
store all paramater by file read
return file is read successfully or not(bool)
*/
bool read_Matrix(int **&adjMatrix, double **&distanceMatrix, string &fileName, string &problemName, string &problemType, int &n, int &m){
    // open file
    ifstream myFile;
    cout << "Please input network filename: ";
    cin >> fileName;
    myFile.open(fileName);
    // Check if the file was opened successfully
    if (!myFile.is_open()){
        cout << "Failed to open file " << fileName << "!!" << endl;
        return 0;
    }

    /* read file
    from, to: temporarily record the start and end points of the path
    ctr: used to calculate the arc number
    distance: temporarily record the distance of the path
    line: a line read from a file
    c: the first field in line, expected to be a character
    */
    int from, to, ctr = 0;
    double distance;
    string line, c;
    while (getline(myFile, line)){ // read a line from a myFile
        istringstream lineSplitIss(line);
        lineSplitIss >> c; // get the first field in line
        switch (c[0]) {
        // if the first letter is t, store the problem name
        case 't':
            lineSplitIss >> problemName;
            break;
        // if the first letter is p, store the problem type, n, m, and initialize two-dimensional matrix with pointer
        // adjMatrix <- 0; distanceMatrix <- 1e9
        case 'p':
            lineSplitIss >> problemType >> n >> m;
            adjMatrix = new int*[n+1];
            distanceMatrix = new double*[n+1];
            for (int i = 1; i <= n; i++){ // initialize each pointer on the matrix as an array
                adjMatrix[i] = new int[n+1];
                distanceMatrix[i] = new double[n+1];
                for (int j = 0; j <= n; j++){ // initialize each pointer on the array as an constant
                    adjMatrix[i][j] = 0;
                    distanceMatrix[i][j] = 1e9;
                }
            }
            break;
        // if the first letter is a, calculate where the arc starting at each point should be
        case 'a':
            lineSplitIss >> from >> to >> distance;
            adjMatrix[from][to] = ++ctr;
            distanceMatrix[from][to] = distance;
            break;
        default:
            break;
        }
    }
    myFile.close();
    return 1;
}

/*
�\��G���� Matrix �ɮ�
input node(int)
output arcs connected to node and it's distance in form "arc[arc#]: from -> to: distance"
return �۳s arc �ƶq(int)
*/
int test_Matrix(int **&adjMatrix, double **&distanceMatrix, int test_node, int n){
    int ctr = 0, total = 0;
    cout << "------------------------------------------------------------------------------------" << endl;
    cout << "incoming arcs: " << endl;
    for (int i = 1; i <= n; i++){ // output non-1e9 values in all nodes corresponding to column in the matrix
        if (distanceMatrix[i][test_node] != 1e9){
            cout << "\t arc[" << adjMatrix[i][test_node] << "]: " << i << "->" << test_node << ": " << distanceMatrix[i][test_node] << endl;
            ctr ++;
        }
    }
    cout << "in-degree(" << test_node << ") = " << ctr << endl;
    total += ctr;
    cout << "------------------------------------------------------------------------------------" << endl;
    ctr = 0;
    cout << "outgoing arcs: " << endl;
    for (int i = 1; i <= n; i++){ // output non-1e9 values in all nodes corresponding to row in the matrix
        if (distanceMatrix[test_node][i] != 1e9){
            cout << "\t arc[" << adjMatrix[test_node][i] << "]: " << test_node << "->" << i << ": " << distanceMatrix[test_node][i] << endl;
            ctr ++;
        }
    }
    cout << "out-degree(" << test_node << ") = " << ctr << endl;
    total += ctr;
    cout << "------------------------------------------------------------------------------------" << endl;

    return total;
}

/*
Ū���ɮר��x�s�� Link List �榡
input filename(str)
store all paramater by file read
return file is read successfully or not(bool)
*/
bool read_Link_List(Link_List_Node **&link_List_Forward, Link_List_Node **&link_List_Backward, string &fileName, string &problemName, string &problemType, int &n, int &m){
    // open file
    ifstream myFile;
    cout << "Please input network filename: ";
    cin >> fileName;
    myFile.open(fileName);
    // Check if the file was opened successfully
    if (!myFile.is_open()){
        cout << "Failed to open file " << fileName << "!!" << endl;
        return 0;
    }

    /* read file
    from, to: temporarily record the start and end points of the path
    ctr: used to calculate the arc number
    distance: temporarily record the distance of the path
    line: a line read from a file
    c: the first field in line, expected to be a character
    temp: temporarily record the node pointer
    */
    int from, to, ctr = 0;
    double distance;
    string line, c;
    Link_List_Node *temp;
    while (getline(myFile, line)){ // read a line from a myFile
        istringstream lineSplitIss(line);
        lineSplitIss >> c; // get the first field in line
        switch (c[0]) {
        // if the first letter is t, store the problem name
        case 't':
            lineSplitIss >> problemName;
            break;
        // Initialize Link List with pointer to NULL
        case 'p':
            lineSplitIss >> problemType >> n >> m;
            link_List_Forward = new Link_List_Node*[n+1];
            link_List_Backward = new Link_List_Node*[n+1];
            for (int i = 0; i <= n; i++){ // initialize each pointer on the linked list to NULL
                link_List_Forward[i] = NULL;
                link_List_Backward[i] = NULL;
            }
            break;
        // Read arcs and save into Link List
        case 'a':
            lineSplitIss >> from >> to >> distance;

            // outgoing arcs of node n
            temp = link_List_Forward[from];
            if (temp){
                while(temp->get_next()){ temp = temp->get_next(); } // to the end of linked list
                temp->set_next(new Link_List_Node(temp, to, ++ctr, distance)); // create new node
            }
            else { link_List_Forward[from] = new Link_List_Node(NULL, to, ++ctr, distance); } // if it is NULL, add a new node as the first node

            // incoming arcs of node n
            temp = link_List_Backward[to];
            if (temp){
                while(temp->get_next()){ temp = temp->get_next(); } // to the end of linked list
                temp->set_next(new Link_List_Node(temp, from, ctr, distance)); // create new node
            }
            else { link_List_Backward[to] = new Link_List_Node(NULL, from, ctr, distance); } // if it is NULL, add a new node as the first node
            break;
        default:
            break;
        }
    }
    temp = NULL;
    delete temp;
    myFile.close();
    return 1;
}

/*
�\��G���� Matrix �ɮ�
input node(int)
output arcs connected to node and it's distance in form "arc[arc#]: from -> to: distance"
return �۳s arc �ƶq(int)
*/
int test_Link_List(Link_List_Node **&link_List_Forward, Link_List_Node **&link_List_Backward, int test_node, int n){
    int ctr = 0, total = 0;
    bool search_outgoing_arcs = 0;

    cout << "------------------------------------------------------------------------------------" << endl;
    // print incoming arcs and counting indegree
    cout << "incoming arcs: " << endl;
    Link_List_Node *temp = link_List_Backward[test_node];
    while (temp){ // output all nodes corresponding to points in link_List_Backward
        temp->print_Backward(test_node);
        temp = temp->get_next();
        ctr++;
    }
    cout << "in-degree(" << test_node << ") = " << ctr << endl;
    total += ctr;
    cout << "------------------------------------------------------------------------------------" << endl;

    // print outgoing arcs and counting outdegree
    ctr = 0;
    cout << "outgoing arcs: " << endl;
    temp = link_List_Forward[test_node];
    while (temp){ // output all nodes corresponding to points in link_List_Forward
        temp->print_Forward(test_node);
        temp = temp->get_next();
        ctr++;
    }
    cout << "out-degree(" << test_node << ") = " << ctr << endl;
    cout << "------------------------------------------------------------------------------------" << endl;
    total += ctr;

    delete temp;
    return total;
}

#endif // READ_SP_H_INCLUDED
