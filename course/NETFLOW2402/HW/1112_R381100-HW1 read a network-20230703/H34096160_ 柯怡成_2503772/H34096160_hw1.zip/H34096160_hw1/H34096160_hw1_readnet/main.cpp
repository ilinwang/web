/*
Purpose: Store the network in the SP file with adj matrix or adj list, and output all the connected arcs to the expected point
Method: Perform the exe file directly or compile the main.cpp and execute the compiled execution file. When switching adj matrix / adj list, you need to manually adjust the annotation part in the main code code code
Enter: SP file name, test node (if you want to end, enter -1)
Output: All arcs adjacent to the test node are divided into two block output: in and out.
Compile: directly compile the main.cpp, such as: g ++ -o hw1.exe main.cpp
Pseudo code: as shown below
Mason Ke completed this program at 2323/03/01 19:55
*/
#include <iostream>
#include "Read_SP.h"

using namespace std;
/* psuedo code of adj matrix version
function read_Matrix(adjMatrix, distanceMatrix, fileName, problemName, problemType, n, m)
    myFile <- openFile(fileName)
    if (myFile is not open)
        output "Failed to open file ", fileName, "!!"
        return false
    end if
    while (line <- getNextLineFromFile(myFile)) do
        c <- getFirstField(line)
        switch c
            case 't':
                problemName <- getSecondField(line)
            case 'p':
                problemType <- getSecondField(line)
                n <- getThirdField(line)
                m <- getFourthField(line)
                adjMatrix  <- allocateMemoryForPointerToIntArray(n+1)
                distanceMatrix  <- allocateMemoryForPointerToDoubleArray(n+1)
                for i from 1 to n
                    adjMatrix[i] <- allocateMemoryForIntArray(n+1)
                    distanceMatrix[i] <- allocateMemoryForDoubleArray(n+1)
                    for j from 0 to n
                        adjMatrix[i][j] <- 0
                        distanceMatrix[i][j] <- 1e9
                    end for
                end for
            case 'a':
                from <- getSecondField(line)
                to <- getThirdField(line)
                distance <- getFourthField(line)
                adjMatrix[from][to]<- ctr
                ctr <- ctr + 1
                distanceMatrix[from][to] <- distance
            default:
                // do nothing
        end switch
    end while
    closeFile(myFile)
    return true
end function

function test_Matrix(adjMatrix, distanceMatrix, test_node, n)
    print ---
    print imcome arcs
    for i from 1 to n
        if distanceMatrix[i][test_node] is not equal to 1e9
            print arc[, adjMatrix[i][test_node], ], i, ->, test_node, :, distanceMatrix[i][test_node]
            ctr <- ctr + 1
        end if
    end for
    print in-degree(, test_node, ) =, ctr
    total <- total + ctr
    print ---
    ctr <- 0
    print outgoing arcs
    for i from 1 to n
        if distanceMatrix[test_node][i] is not equal to 1e9
            print arc[, adjMatrix[test_node][i], ], test_node, ->, i, :, distanceMatrix[test_node][i]
            ctr <- ctr + 1
        end if
    end for
    print out-degree(, test_node, ) =, ctr
    total <- total + ctr
    print ---
    return total
end function


initialize variables

while (the read_Matrix function returns false) do
    call read_Matrix function with adjMatrix, distanceMatrix, fileName, problemName, problemType, n, m as arguments
end while

input test_node

while test_node is not equal to -1
    if test_node > n or test_node < 1
        print Warning
    else
        arcs <- call test_Matrix function with adjMatrix, distanceMatrix, test_node, n as arguments
        print total number of arcs conneted to node , test_node,  is , arcs, arcs
        print ---
    end if
    input test_node
end while
    delete adjMatrix
    delete distanceMatrix
*/
/**/
/* psuedo code of adj list version
class Pathes
    connect_point: integer
    arc_number: integer
    distance: double
    next: pointer to Link_List_Node = NULL
    prev: pointer to Link_List_Node = NULL

    constructor Link_List_Node(prev_node, connected_node, arc_number, distance)

    method addPath(dfsS, pointForward, arcnow, network, n, m)
        prev <- prev_node
        connect_point <- connect_point
        arc_number <- arc_number
        distance <- distance
    end method

    method print_Forward(test_node)
        print \t arc[, arc_number, ]: , test_node, ->, connect_point, : , distance
    end method
    // here I ignore get/set function
end class

function read_Link_List(link_List_Forward, link_List_Backward, fileName, problemName, problemType, n, m)
    myFile <- openFile(fileName)
    if (myFile is not open)
        output "Failed to open file ", fileName, "!!"
        return false
    end if
    while (line <- getNextLineFromFile(myFile)) do
        c <- getFirstField(line)
        switch c
            case 't':
                problemName <- getSecondField(line)
            case 'p':
                problemType <- getSecondField(line)
                n <- getThirdField(line)
                m <- getFourthField(line)
                link_List_Forward <- allocateMemoryForPointerToLink_List_NodeArray(n+1)
                link_List_Backward  <- allocateMemoryForPointerToLink_List_NodeArray(n+1)
                for i from 1 to n
                    link_List_Forward[i] <- NULL;
                    link_List_Backward[i] <- NULL;
                end for
            case 'a':
                from <- getSecondField(line)
                to <- getThirdField(line)
                distance <- getFourthField(line)
                temp <- link_List_Forward[from]
                if temp is not NULL
                    while temp->get_next() is not NULL do
                        temp <- temp->get_next()
                    end while
                    ctr <- ctr + 1
                    temp->set_next(new Link_List_Node(temp, to, ctr, distance))
                else
                    ctr <- ctr + 1
                    link_List_Forward[from] <- new Link_List_Node(temp, to, ctr, distance)
                end if
                temp <- link_List_Backward[to]
                if temp is not NULL
                    while temp->get_next() is not NULL do
                        temp <- temp->get_next()
                    end while
                    ctr <- ctr + 1
                    temp->set_next(new Link_List_Node(temp, to, ctr, distance))
                else
                    ctr <- ctr + 1
                    link_List_Forward[from] <- new Link_List_Node(temp, to, ctr, distance)
                end if
            default:
                // do nothing
        end switch
    end while
    temp <- NULL
    delete temp
    closeFile(myFile)
    return true
end function

function test_Link_List(link_List_Forward, link_List_Backward, test_node, n)
    print ---
    print imcome arcs
    temp <- link_List_Backward[test_node]
    while temp is not NULL do
        temp->print_Backward(test_node)
        temp <- temp->get_next()
        ctr <- ctr + 1
    end while
    print in-degree(, test_node, ) =, ctr
    total <- total + ctr
    print ---
    ctr <- 0
    print outgoing arcs
    temp <- link_List_Forward[test_node]
    while temp is not NULL do
        temp->print_Forward(test_node)
        temp <- temp->get_next()
        ctr <- ctr + 1
    end while
    print out-degree(, test_node, ) =, ctr
    total <- total + ctr
    print ---
    return total
end function


initialize variables

while (the read_Matrix function returns false) do
    call read_Matrix function with adjMatrix, distanceMatrix, fileName, problemName, problemType, n, m as arguments
end while

input test_node

while test_node is not equal to -1
    if test_node > n or test_node < 1
        print Warning
    else
        arcs <- call test_Link_List function with link_List_Forward, link_List_Backward, test_node, n as arguments
        print total number of arcs conneted to node , test_node,  is , arcs, arcs
        print ---
    end if
    input test_node
end while
*/

int main()
{
    /*
    // Matrix version start
    // Ū���ɮ�
    int **adjMatrix;
    double **distanceMatrix;
    string fileName, problemName, problemType;
    int n, m, test_node = 0, arcs;
    while(!read_Matrix(adjMatrix, distanceMatrix, fileName, problemName, problemType, n, m)){ }

    // �T�{�۳s���|�P�`�I
    cout << endl << "Please input a source node: ";
    cin >> test_node;
    while (test_node != -1){
        if (test_node > n || test_node < 1){ cout << "!!Warning!!: node " << test_node << " does not exist!" << endl; }
        else {
            arcs = test_Matrix(adjMatrix, distanceMatrix, test_node, n);
            cout << "total number of arcs conneted to node " << test_node << " is " << arcs << " arcs" << endl;
            cout << "------------------------------------------------------------------------------------" << endl;
        }
        cout << endl << "Please input a source node: ";
        cin >> test_node;
    }
    for (int i = 1; i <= n; i++){
        delete adjMatrix[i];
        delete distanceMatrix[i];
    }
    delete adjMatrix;
    delete distanceMatrix;
    // Matrix version end
    */
    /**/
    // Link List version start
    Link_List_Node **link_List_Forward, **link_List_Backward;
    string fileName, problemName, problemType;
    int n, m, test_node = 0, arcs;
    while(!read_Link_List(link_List_Forward, link_List_Backward, fileName, problemName, problemType, n, m)){ }

    cout << endl << "Please input a source node: ";
    cin >> test_node;
    while (test_node != -1){ // continue the program as long as the test node is not -1
        if (test_node > n || test_node < 1){ cout << "!!Warning!!: node " << test_node << " does not exist!" << endl; } // Check if test_node exists
        else { // if test_node exists, call function to check the arc connected to this point
            arcs = test_Link_List(link_List_Forward, link_List_Backward, test_node, n);
            cout << "total number of arcs conneted to node " << test_node << " is " << arcs << " arcs" << endl;
            cout << "------------------------------------------------------------------------------------" << endl;
        }
        cout << endl << "Please input a source node: ";
        cin >> test_node;
    }
    /**/
    return 0;
}
