/*
This is to convert the algorithm output into excel txt format
   
    usage:
        read the network info, choose a node and list the related arcs

        execute h34081018_hw1
        and input the file name then the node number
    
    input file:
        test1.sp or test2.sp
        
    output files:
        none
        
    compile:
        g++ -o h34081018_hw1 h34081018_hw1.cpp

    pseudocode:
    input filename to read file
    ------
    origin = new int[arcs]
    destination = new int[arcs]
    length = new float[arcs]
    ------
    input node number to see the list
    ------
    for every arc of the network
    if(destination[arc] == node number || origin[arc] == node number)
        print arc info
    ------

    coded by Tsung-Lin Li, ID: h34081018, email: h34081018@gs.ncku.edu.tw
    date: 2023.02.27
*/
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;

int main(){
    string filename;
    printf("Please input network filename: \n");
    cin >> filename;

    ifstream readfile(filename);
    string Text;
    int n, arcs, *a, *b, temp = 0;
    float *length;

    // read file line by line
    while (getline (readfile, Text)) {
        // initialize dynamic allocated array
        if(Text[0] == 'p'){
            Text = Text.substr(6);
            istringstream is(Text);
            is >> n >> arcs;
            a = new int[arcs];
            b = new int[arcs];
            length = new float[arcs];
        }
        // store arc info
        else if(Text[0] == 'a'){
            Text = Text.substr(2);
            istringstream is(Text);
            is >> a[temp] >> b[temp] >> length[temp];
            temp++;
        }
    }
    readfile.close();
    
    printf("Please input a source node: \n");
    int node;
    cin >> node;
    
    // print arc info if it's related to the specific node
    if(node > n || node < 1){
        printf("!!Warning!!: node %i does not exist\n", node);
    }
    else{
        for(int i = 0; i < arcs; i++){
            if(a[i] == node || b[i] == node){
                printf("arc[%i]: %i-%i : %.2f\n", i + 1, a[i], b[i], length[i]);
            }
        }
    }

    delete[] a, b, length;
    return 0;
}