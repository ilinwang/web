extern "C"{
#include "timer.c"
}
#include <iostream>
#include <vector>
#include <queue>
#include <climits>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <cstring>



using namespace std;

struct Edge {
    int source;
    int destination;
    int weight;
};

class Graph {
    int V; 
    int E; 
    vector<Edge> edges; 

public:
    Graph(int V, int E) {
        this->V = V;
        this->E = E;
    }

    void addEdge(int u, int v, int w) {
        edges.push_back({u, v, w});
    }


    void bellmanFord(int start) {
        vector<int> dist(V, INT_MAX);
        dist[start] = 0;

        queue<int> q;
        q.push(start);

        for (int i = 1; i <= V - 1; i++) {
            int qSize = q.size();
            for (int j = 1; j <= qSize; j++) {
                int u = q.front();
                q.pop();

                for (auto edge : edges) {
                    int v = edge.destination;
                    int w = edge.weight;
                    if (edge.source == u && dist[u] != INT_MAX && dist[v] > dist[u] + w) {
                        dist[v] = dist[u] + w;
                        q.push(v);
                    }
                }
            }
        }

        for (auto edge : edges) {
            int u = edge.source;
            int v = edge.destination;
            int w = edge.weight;
            if (dist[u] != INT_MAX && dist[u] + w < dist[v]) {
                cout << "Graph contains negative weight cycle" << endl;
                return;
            }
        }

        // cout << "Vertex\tDistance from source" << endl;
        int sum = 0;
        for (int i = 1; i < V; i++) {
            // cout << i << "\t" ;
            if(dist[i]==INT_MAX){
                // cout<<"can't reach"<< endl;
            }else{
                // cout<< dist[i] << endl;
                sum+=dist[i];
            }
            
        }
        cout<<"total: "<<sum<<endl;
    }
};

vector<string> split( string line, char x, char tab){
    vector<string> result;
    string tmp = "";

    for(int i=0; i<line.length(); i++){
        if(line[i] == x | line[i]==tab){
            if(tmp!=""){
                result.push_back(tmp);
                tmp = "";
            }
            
        }else{
            tmp += line[i];
            if (i+1 == line.length()){
                result.push_back(tmp);
            }
            
        }
    }
    return result;
}

int main() {

    int n ,m;
    vector<string> tmp;
    ifstream myFile;
    string filename;
    cout<<"Please input network filename:";
    cin>>filename;

    int s = 0;
    // s= 2;
    cout<<"input source node:";
    cin>>s;

    // filename = "inputs/test1.sp";
    myFile.open(filename);
    string line;
    while (getline(myFile, line)) {
        if(line[0]=='p'){
            tmp = split(line,' ', '\t');
            n = stoi(tmp[2]);
            m = stoi(tmp[3]);
            break;
        }
    }
    myFile.close();
    Graph g(n+1, m+1);

    myFile.open(filename);
    
    while (getline(myFile, line)) {
        if(line[0]=='a'){
            tmp = split(line,' ', '\t');
            g.addEdge(stoi(tmp[1]), stoi(tmp[2]), stoi(tmp[3]));
        }
    }
    myFile.close();
    
    double t=0;

    t = timer();
    g.bellmanFord(s);

    t = timer() - t;

    cout<<"time: "<<t;
    return 0;
}
