extern "C"{
#include "timer.c"
}

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <sstream>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cmath>
using namespace std;

int ** arc;

//a struct to save node data
struct list
{
    int x; 
    int arcNum;
    struct list *next;
};

typedef struct list node;
typedef node * link;

//graphlink is to use in adjacency list
struct graphlink
{
    link first;
    link last;
};

struct graphlink* adjacency_list; // adjacency list

void insert(struct graphlink* temp, int x, int arcNum){
    link newNode = new node;
    newNode->x = x;
    newNode->next = NULL; 
    newNode->arcNum = arcNum;
    if(temp->first == NULL){
        temp->first = newNode;
        temp->last = newNode;
    }else{
        temp->last->next = newNode;
        temp->last = newNode;
    }
}

//read the data and split the lines 
vector<string> split( string line, char x, char tab){
    vector<string> result;
    string tmp = "";

    for(int i=0; i<line.length(); i++){
        if(line[i] == x | line[i]==tab){
            if(tmp!=""){
                result.push_back(tmp);
                tmp = "";
            }
            
        }else{
            tmp += line[i];
            if (i+1 == line.length()){
                result.push_back(tmp);
            }
            
        }
    }
    return result;
}

int ** heapArr;

int find_min(int** heapArr){
    return heapArr[1][0];
}

void adjustHeap(int** heapArr, int x, int i, int num){
    int j = num/2; //j 是 i 的 parent
    int nodeNum = i;
    
    while(j != 0){
        if(x < heapArr[j][1]){
            heapArr[num][0] = heapArr[j][0];
            heapArr[num][1] = heapArr[j][1];
            heapArr[j][0] = nodeNum;
            heapArr[j][1] = x;
            num = j;
            j = j/2;
        }else{
            heapArr[num][0] = nodeNum;
            heapArr[num][1] = x;
            break;
        }
    }
}

void adjustHeap2(int** heapArr, int i, int num){
    //i從1(root)開始
    int j = 2*i; //j是i的R-child 
    int x = heapArr[i][1]; //i的weight
    int nodeNum = heapArr[i][0];

    while(j <= num){
        if(j<num){ //代表i有L-child
            if (heapArr[j][1] > heapArr[j+1][1]) j++;
        }

        if(x <= heapArr[j][1]) {
            break;
        }else{
            heapArr[j/2][1] = heapArr[j][1];
            heapArr[j/2][0] = heapArr[j][0];
            heapArr[j][0] = nodeNum;
            heapArr[j][1] = x;
            j = j * 2;
        }
    }
}

void delete_min(int** heapArr, int num){
    if(num==1){
        heapArr[1][0] = 0;
        heapArr[1][1] = 123456;
    }else{
        heapArr[1][0] = heapArr[num][0];
        heapArr[1][1] = heapArr[num][1];
        heapArr[num][0] = 0;
        heapArr[num][1] = 123456;
    }

    num = num-1;

    if(num>0) adjustHeap2(heapArr, 1, num);
}

void insertHeap(int** heapArr, int x, int i, int num){
    
    int parentNum = num/2;

    if (parentNum == 0){
        // root
        heapArr[1][0] = i; // 編號
        heapArr[1][1] = x; // weight
    }else{
        adjustHeap(heapArr, x, i, num);
    }
}

void decrease_key(int** heapArr, int new_weight, int j, int n){
    for (int i=1; i<=n;i++){
        if (heapArr[i][0] == j){
            heapArr[i][1] = new_weight;
            break;
        }
    }
}

int checkInHeap (int** heapArr, int nodeNum, int num){
    for (int i=1; i<=num;i++){
        if (heapArr[i][0] == nodeNum){
            return 1;
        }
    }
    return 0;
}

void heap(int n, int m, int s) {
    int* d = new int [n+1];
    int* pred = new int [n+1];
    int elementNum = 0;

    for(int i=1; i<=n; i++){
        d[i] = 123456;
        pred[i] = 0;
    }

    d[s]=0;
    pred[s]=0;

     // 建立 heap 的 array ，分別存入:1.arc 的編號  2.arc 的 weight
    heapArr = new int * [n+1];
    for(int i=1; i<=n; i++){
        heapArr[i] = new int [2];
        heapArr[i][0] = 0;
        heapArr[i][1] = 123456;
    }

    elementNum++;
    insertHeap(heapArr, d[s], s, elementNum);

    
    

    while(elementNum != 0){
        int i = find_min(heapArr);

        delete_min(heapArr, elementNum);
        elementNum--;

        link j = adjacency_list[i].first;

        while(j!=NULL){
            int temp = d[i] + arc[j->arcNum][2];
            if (d[j->x] > temp){
                if (checkInHeap(heapArr, j->x, elementNum)==0){
                    d[j->x] = temp;
                    pred[j->x] = i;
                    elementNum++;
                    insertHeap(heapArr, d[j->x], j->x, elementNum);
                }else{
                    d[j->x] = temp;
                    pred[j->x] = i;
                    decrease_key(heapArr, d[j->x], j->x, elementNum);
                }
            }
            j = j->next;
        }
    }

    // cout<<"RESULT:"<<endl;

    int sum = 0;
    for (int i=1; i<=n; i++){
        if(d[i]==123456){
            // cout << s <<"->" << i << " : " << "[Can not reach]" << endl;
        }else{
            sum += d[i];
            
        }
    }
    cout<<"total="<<sum;
}


int main(){
    string name, type;
    int n ,m;
    vector<string> tmp;
    ifstream myFile;
    string filename;
    cout<<"Please input network filename:";
    cin>>filename;

    myFile.open(filename);
    string line;

    int c=1;
    int bigM=10000;

    while (getline(myFile, line)) {
        if (line[0]=='t'){
            tmp = split(line,' ','\t');
            name = tmp[1];
        }
        else if(line[0]=='p'){
            tmp = split(line,' ', '\t');
            type = tmp[1];
            n = stoi(tmp[2]);
            m = stoi(tmp[3]);

            arc = new int* [m+1];
            for(int i=1; i<=m;i++){
                arc[i] = new int [3];
            }

        }else if(line[0]=='a'){
            tmp = split(line,' ', '\t');
            
            arc[c][0]=stoi(tmp[1]);
            arc[c][1]=stoi(tmp[2]);
            arc[c][2] = stoi(tmp[3]);

            c+=1;
        }
    }

    myFile.close();

    adjacency_list = new graphlink [n+1];
    
    //store data into adjacency list
    int dataNum;
    for (int i=1 ; i<=n ; i++){
        adjacency_list[i].first = NULL;
        adjacency_list[i].last = NULL;
        for (int j=1; j<=m; j++){
            if(arc[j][0]==i){
                dataNum = arc[j][1];
                insert(&adjacency_list[i], dataNum, j);
            }
        }
    }

    int s ;
    cout << "Please input a source node: ";
    cin >> s;

    float time = timer();

    heap(n, m, s);

    time = timer() - time;

    cout<<"\ntime: "<<time;

    return 0;
}