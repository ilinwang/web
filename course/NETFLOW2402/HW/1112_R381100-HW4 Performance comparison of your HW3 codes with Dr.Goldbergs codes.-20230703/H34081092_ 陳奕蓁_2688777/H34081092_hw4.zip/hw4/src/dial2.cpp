extern "C"{
#include "timer.c"
}
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <vector>
#include <cstring>
#include <set>
using namespace std;

int ** arc;

//a struct to save node data
struct list
{
    int x; 
    int arcNum;
    struct list *next;
};

typedef struct list node;
typedef node * link;

//graphlink is to use in adjacency list
struct graphlink
{
    link first;
    link last;
};

struct graphlink* adjacency_list; // adjacency list

void insert(struct graphlink* temp, int x, int arcNum){
    link newNode = new node;
    newNode->x = x;
    newNode->next = NULL; 
    newNode->arcNum = arcNum;
    if(temp->first == NULL){
        temp->first = newNode;
        temp->last = newNode;
    }else{
        temp->last->next = newNode;
        temp->last = newNode;
    }
}

//read the data and split the lines 
vector<string> split( string line, char x, char tab){
    vector<string> result;
    string tmp = "";

    for(int i=0; i<line.length(); i++){
        if(line[i] == x | line[i]==tab){
            if(tmp!=""){
                result.push_back(tmp);
                tmp = "";
            }
            
        }else{
            tmp += line[i];
            if (i+1 == line.length()){
                result.push_back(tmp);
            }
            
        }
    }
    return result;
}

void dial(int n, int m, int s){
    int* d = new int [n+1];
    int* pred = new int [n+1];

    for(int i=1; i<=n; i++){
        d[i] = 123456;
        pred[i] = 0;
    }

    d[s] = 0;
    pred[s] = 0;

    int max = 1;
    for (int i=2; i<=m; i++){
        if(arc[i][2] > arc[max][2]){
            max = i;
        }
    }

    int N = 1+(n-1)*arc[max][2];

    set<int>* bucket = new set<int> [N];

    // put node s into bucket 0
    bucket[0].insert(s);

    int index = 0;
    while(index <= N){
        if (!bucket[index].empty()) {
            // 從bucket 中取出最小值
            set<int>::iterator iter;
            iter = bucket[index].begin();
            int i = *iter;
            bucket[index].erase(iter);
            link j= adjacency_list[i].first;
            while(j!=NULL){
                int temp = d[i] + arc[j->arcNum][2];
                if(i==136){
                    cout<<"i = 136\n";
                    cout<<"j="<<j->x<<endl;
                    cout<<"d["<<i<<"]="<<d[i]<<", arc["<<j->arcNum<<"][2]="<<arc[j->arcNum][2]<<endl;
                }
                if (d[j->x] > temp){
                    
                    // if(d[j->x]<N){
                    //     set<int>::iterator iter2;
                    //     iter2 = bucket[d[j->x]].find(j->x);
                    //     if (iter2 != bucket[d[j->x]].end()) { //find j in bucket[i]
                    //         bucket[d[j->x]].erase(*iter2);
                    //     }
                    // }
                    if(j->x==137){
                        cout<<"d["<<i<<"]="<<d[i]<<", arc[j][2]="<<arc[j->arcNum][2]<<endl;
                        cout<<"old="<<d[j->x]<<endl;
                        cout<<"new="<<temp<<endl;
                        cout<<"===\n";
                    }
                    
                    bucket[temp].insert(j->x); //insert node j into new bucket
                    
                    pred[j->x] = i;
                    
                    d[j->x] = temp;
                }
                j = j->next;
            }
        }
        index++;
    }

    cout<<"RESULT:"<<endl;

    int sum = 0;
    for (int i=1; i<=n; i++){
        if(i != s){
            if(d[i]==123456){
                // cout << s <<"->" << i << " : " << "[Can not reach]" << endl;
            }else{
                sum += d[i];
                // cout<< d[i] <<endl ;
            }
        }
    }
    cout<<"total: "<<sum;
}



int main(){
    string name, type;
    int n ,m;
    vector<string> tmp;
    ifstream myFile;
    string filename;
    
    cout<<"Please input network filename:";
    cin>>filename;

    // filename = "inputs/s1.txt";

    myFile.open(filename);
    string line;
    
    int c=1;
    int bigM=10000;

    while (getline(myFile, line)) {
        if (line[0]=='t'){
            tmp = split(line,' ','\t');
            name = tmp[1];
        }
        else if(line[0]=='p'){
            tmp = split(line,' ', '\t');
            type = tmp[1];
            n = stoi(tmp[2]);
            m = stoi(tmp[3]);

            arc = new int* [m+1];
            for(int i=1; i<=m;i++){
                arc[i] = new int [3];
            }

        }else if(line[0]=='a'){
            tmp = split(line,' ', '\t');
            
            arc[c][0]=stoi(tmp[1]);
            arc[c][1]=stoi(tmp[2]);
            arc[c][2] = stoi(tmp[3]);
            c+=1;
        }
    }

    // Close file
    myFile.close();

    adjacency_list = new graphlink [n+1];
    
    //store data into adjacency list
    int dataNum;
    for (int i=1 ; i<=n ; i++){
        adjacency_list[i].first = NULL;
        adjacency_list[i].last = NULL;
        for (int j=1; j<=m; j++){
            if(arc[j][0]==i){
                dataNum = arc[j][1];
                insert(&adjacency_list[i], dataNum, j);
            }
        }
    }

    int s ;
    cout << "Please input a source node: ";
    cin >> s;

    double time = timer();

    dial( n, m, s);

    time = timer() - time;

    cout<<"\ntime: "<<time;

    return 0;
}