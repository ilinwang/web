#include <stdio.h>
#include <stdlib.h>

#define YES 1
#define NO  0
#define STATISTIC YES

/* statistical variables */
long n_scans;
long n_impr;

/* definitions of types: node & arc */

#include "types_bf.h"

/* parser for getting extended DIMACS format input and transforming the
   data to the internal representation */

#include "parser_dh.c"

/* function 'timer()' for mesuring processor time */
#include <time.h>

/* function for constructing shortest path tree */

#include "bf.c"

int main (int argc, char *argv[]){

    double t;
    arc *arp, *ta;
    node *ndp, *source, *k;
    long n, m, nmin, i;
    char name[21];
    double sum_d = 0;
    
    
    if (argc < 3) {
        printf("Usage: %s <file_name> <number>\n", argv[0]);
        return 1;
    }
    char* fileName = argv[1];
    int number = atoi(argv[2]);

    parse( &n, &m, &ndp, &arp, &source, &nmin, name , fileName, number);

    clock_t start = clock();
    bf ( n, ndp, source );
    clock_t stop = clock();

    double elapsed_time = (double)(stop - start) / CLOCKS_PER_SEC;

    for ( k= ndp; k< ndp + n; k++ )
        if ( k -> parent != (node*) NULL )
            sum_d += (double) (k -> dist);

    printf("---------------------------\n");
    printf ("Sum of distances: %.0f\n", sum_d);
    printf ("Running time of dikh SP computation: %.6f",elapsed_time);
    printf("\n---------------------------");
}
