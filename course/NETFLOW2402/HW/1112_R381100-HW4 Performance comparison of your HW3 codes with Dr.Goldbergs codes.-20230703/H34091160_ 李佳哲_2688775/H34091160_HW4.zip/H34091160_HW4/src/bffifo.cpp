/*
   This code can be compiled and run ok.

   Purpose:
     This code can first read a network file and source node(s),
     then output a shortest path with its length from s to all the other nodes by Bellman-Ford FIFO algorithm.

   Usage:
     Firstly, user request to input a filename. If filename is invalid, it will print error message and terminate.
     Secondly, user request to input a source node. If source node is invalid, it will print error message and terminate,
     else, it will print out the result of 1-ALL shortest path.

   Input file:
     test1.sp
     test2.sp

   Output files:
     None.

   Compile:
     g++ -o h34091160_hw4_bf_fifo h34091160_hw4_bf_fifo.cpp

 Pseudocode:
   Begin
     d(j) := 999999 for j in N-{s}
     d(s) := 0 and pred(s) := -1
     List := {s};
     while LIST isn't empty do
     begin
       i = LIST.front();
       delete the front element i from LIST;
       for each (i,j) in A(i) do
       Begin
         value := d(i) + c_ij;
         if d(j) > value then
            d(j) := d(i) + c_ij;
            pred(j) := i;
       End
     End
     Print out the results;
   End

   coded by 李佳哲, ID: h34091160, email: h34091160@gs.ncku.edu.tw
   date: 2023.04.29
*/

#include <queue>
#include <string>
#include <chrono>
#include <fstream>
#include <sstream>
#include <iostream>

using namespace std;

struct Nodes {  // Define the structure of node
    int node_index = 0;  // record the index of the node
    int pred = 0;  // record the predecessor of the node
    int arc_len = 0;
    int arc_index = 0;
    int d = 0;  // record the distance label of the node
    Nodes* next;
};

struct Arcs {  // Define the structure of node
    int arc_index = 0;  // record the index of the arc
    int s = 0;  // record the tail node of the arc
    int t = 0;  // record the head node of the arc
    int distance = 0;  // record the length of the arc
};

class AdjacencyList {  // Define a class that implement adjacency list
    Nodes* head;
public:
    AdjacencyList() {  // Initialize
        head = nullptr;
    }

    void addNode(int num, int arc_index, int arc_distance) {  // Add node to the adj. list
        Nodes* newNode = new Nodes;
        newNode->node_index = num;
        newNode->arc_len = arc_distance;
        newNode->arc_index = arc_index;
        newNode->next = nullptr;

        if (head == nullptr) {
            head = newNode;
        }
        else {
            Nodes* curr = head;
            while (curr->next != nullptr) {
                curr = curr->next;
            }
            curr->next = newNode;
        }
    }

    int* outdegree_nodes(int outdegree_num){
        int* out = new int[outdegree_num];
        Nodes* curr = head;

        for(int y=0;y<outdegree_num;y++){
            out[y] = curr->node_index;
            //cout << out[y] << " ";
            curr = curr->next;
        }

        return out;
    }

    int* outdegree_arcs(int outdegree_num){
        int* out = new int[outdegree_num];
        Nodes* curr = head;

        for(int y=0;y<outdegree_num;y++){
            out[y] = curr->arc_index;
            //cout << out[y] << " ";
            curr = curr->next;
        }

        return out;
    }
};

void bellman_ford(int source_node, int n,  Nodes* node, Arcs* arc, int* outdegree_num, AdjacencyList* adjList_out) {
    // 1. Initialized
    queue<int> list;  // Record Bellman-Ford FIFO LIST queue

    for(int i=0;i<n;i++){
        if(i == source_node-1){
            list.push(i);
            node[i].d = 0;  // d(s) = 0
            node[i].pred = -1;  // pred(s) = -1, 避免跟 node 1 衝突，改用 -1 表示
        }
        else{
            node[i].d = 999999;  // d(s) = 999999
        }
    }

    // Modified label correcting algorithm
    while(list.size() != 0){  // while LIST != {}
        int i = list.front();  // select a node i in list
        list.pop();

        // Update i
        int* outdeg_num = adjList_out[i+1].outdegree_nodes(outdegree_num[i]);
        int* outdeg_arc = adjList_out[i+1].outdegree_arcs(outdegree_num[i]);

        for(int j=0;j<outdegree_num[i];j++){
            if(node[outdeg_num[j]-1].d > node[i].d + arc[outdeg_arc[j]-1].distance){  // if d(j) > d(i) + c_ij then distance update
                node[outdeg_num[j]-1].d = node[i].d + arc[outdeg_arc[j]-1].distance;
                node[outdeg_num[j]-1].pred = i;
                list.push(node[outdeg_num[j]-1].node_index-1);  // add node j to the LIST
            }
        }
    }

    // Print out the results
    int sum = 0;

    for(int i=0;i<n;i++){
        if(i+1 == source_node){
            continue;
        }
        else if(node[i].d == 999999){
            continue;
        }
        else{
            sum += node[i].d;
        }
    }
    cout << "---------------------------------" << endl;
    cout << "Sum of distances: " << sum << endl;

}

int main () {
    string filename;
    cout << "Please input network filename: ";    // user input filename
    getline(cin, filename);
    ifstream file(filename);

    if(!file.is_open()){
        cerr << "Failed to open " << filename << endl;
        return 1;
    }

    string s, first, problem_type, problem_name;
    int n = 0;    // number of nodes
    int m = 0;    // number of arcs
    int start_node = 0;    // starting node of the arc
    int end_node = 0;    // ending node of the arc
    int distance = 0;    // distance of the arc
    int index = 0;    // index of the arc
    bool counter = true;

    Arcs* arc;  // record arcs
    Nodes* node;  // record nodes
    AdjacencyList* adjList_in;  // record adjacency list by indegree
    AdjacencyList* adjList_out;  // record adjacency list by outdegree
    int* outdegree_num;  // record outdegree number of each node

    while (getline(file, s)) {
        istringstream stringfile(s);
        stringfile >> first;    // Read the first word of the line

        if(first[0]=='t'){    // Case 1: When read 't', record title of the problem name
            stringfile >> problem_name;
        }
        else if(first[0]=='p'){    // Case 2: When read 'p', record problem type, # of node and arc
            stringfile >> problem_type >> n >> m;

            // dynamically allocating memory
            outdegree_num = new int[n];
            node = new Nodes[n];
            arc = new Arcs[m];
            adjList_in = new AdjacencyList[n];
            adjList_out = new AdjacencyList[n];

            // save the nodes
            for(int i=0;i<n;i++){
                node[i].node_index = i + 1;
            }
        }
        else if(first[0]=='a'){    // Case 3: When read 'a', record start node, end node and the distance between them
            stringfile >> start_node >> end_node >> distance;
            //cout << start_node << " " << end_node << " " << distance << endl;

            // save the arc information
            arc[index].arc_index = index + 1;
            arc[index].s = start_node;
            arc[index].t = end_node;
            arc[index].distance = distance;

            // check the outdegree number of each node
            if (counter){
                for(int i=0;i<n;i++){
                    outdegree_num[i] = 0;  // Initialized
                }
                counter = 0;
                outdegree_num[start_node-1]++;
            }
            else{   // Record outdegree number
                outdegree_num[start_node-1]++;
            }

            // Add into adjacency list
            adjList_in[end_node].addNode(arc[index].s, arc[index].arc_index, arc[index].distance);
            adjList_out[start_node].addNode(arc[index].t, arc[index].arc_index, arc[index].distance);

            index++;
        }
    }

    int source_node = 0;
    cout << "Please input a source node: ";    // user input source node
    cin >> source_node;

    if(source_node <= 0 || source_node > n){    // print warning message
        cout << "\n!!Warning!!: Node " << source_node << " does not exist." << endl;
    }
    else {
        auto start = chrono::high_resolution_clock::now();

        bellman_ford(source_node, n, node, arc, outdegree_num, adjList_out);

        auto stop = chrono::high_resolution_clock::now();
        auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);
        cout << "Running time of SP computation: " << duration.count() << " microseconds" << endl;
        cout << "---------------------------------" << endl;

    }

    delete[] node;   // Clear the memory
    delete[] arc;
    delete[] outdegree_num;
    delete[] adjList_in;
    delete[] adjList_out;

    file.close();    // Close file

    return 0;
}

