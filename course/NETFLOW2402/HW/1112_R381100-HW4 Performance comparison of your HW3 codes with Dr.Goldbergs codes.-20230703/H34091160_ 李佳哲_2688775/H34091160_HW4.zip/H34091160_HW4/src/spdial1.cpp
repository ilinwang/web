/*
   This code can be compiled and run ok.

   Purpose:
     This code can first read a network file and source node(s),
     then output a shortest path with its length from s to all the other nodes by Dial's algorithm.

   Usage:
     Firstly, user request to input a filename. If filename is invalid, it will print error message and terminate.
     Secondly, user request to input a source node. If source node is invalid, it will print error message and terminate,
     else, it will print out the result of 1-ALL shortest path.

   Input file:
     test1.sp
     test2.sp

   Output files:
     None.

   Compile:
     g++ -o h34091160_hw3_spdial1 h34091160_hw3_spdial1.cpp

 Pseudocode:
  Begin
     d(j) := 999999 for j in N
     d(s) := 0 and pred(s) := -1
     createBucket(C+1);
     addNode(s);
     while !scanEnd do
     begin
       wrapAround();
       iterationDistance := iterationDistance + currentBucket
       for each (i,j) in A(i) do
       Begin
         if d(j) > d(i) + c_ij then
            if d(j) != 999999 then deleteNodeIndex(j);
            d(j) := d(i) + c_ij
            pred(j) := i
            addNode(j);
       End
       deleteLastNode();
       for i=0 to C do
       Begin
         if bucketSize != 0 then
         Begin
           currentBucket := i
           scanEnd := false
           break
         End
         Else scanEnd := true
       End
     End
     Print out the results
   End

   coded by 李佳哲, ID: h34091160, email: h34091160@gs.ncku.edu.tw
   date: 2023.05.02
*/

#include <string>
#include <chrono>
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <iostream>


using namespace std;

// Define the structure of node
struct Nodes {
    int node_index;    // record the index of the node
    int pred;    // record the predecessor of the node
    int arc_len;    // record arc length (only used in adjacency list)
    int arc_index;    // record arc index (only used in adjacency list)
    int d;    // record the distance label of the node
    Nodes* next;   // pointer
};

// Define the structure of node
struct Arcs {
    int arc_index;    // record the index of the arc
    int s;    // record the tail node of the arc
    int t;    // record the head node of the arc
    int distance;    // record the length of the arc
};

// Define the structure of Dial's bucket
struct buckets{
    int index;    // record the node index
    buckets* next;    // pointer(used in linked list)
};

// Define a class that implement adjacency list
class AdjacencyList {
    Nodes* head;
public:
    AdjacencyList() {    // Initialize
        head = nullptr;
    }

    void addNode(int num, int arc_index, int arc_distance) {    // Add node to the adj. list
        Nodes* newNode = new Nodes;
        newNode->node_index = num;
        newNode->arc_len = arc_distance;
        newNode->arc_index = arc_index;
        newNode->next = nullptr;

        if (head == nullptr) {
            head = newNode;
        }
        else {
            Nodes* curr = head;
            while (curr->next != nullptr) {
                curr = curr->next;
            }
            curr->next = newNode;
        }
    }

    int* outdegree_nodes(int outdegree_num){    // Return the outdegree nodes of node i (by array)
        int* out = new int[outdegree_num];
        Nodes* curr = head;

        for(int y=0;y<outdegree_num;y++){
            out[y] = curr->node_index;
            curr = curr->next;
        }
        return out;
    }

    int* outdegree_arcs(int outdegree_num){    // Return the outdegree arcs of node i (by array)
        int* out = new int[outdegree_num];
        Nodes* curr = head;

        for(int y=0;y<outdegree_num;y++){
            out[y] = curr->arc_index;
            curr = curr->next;
        }

        return out;
    }
};

// Define a class that implement Dial's bucket by adjacency list
class BucketList {
    buckets* head;
public:
    BucketList() {    // Initialize
        head = nullptr;
    }

    void addNode(int num) {    // Add node to the bucket adjacency list
        buckets* newNode = new buckets;
        newNode->index = num;
        newNode->next = nullptr;

        if (head == nullptr) {
            head = newNode;
        }
        else {
            buckets* curr = head;
            while (curr->next != nullptr) {
                curr = curr->next;
            }
            curr->next = newNode;
        }
    }

    int bucketSize(){    // Return the bucket size
        buckets* curr = head;
        int counter = 0;
        while (curr != nullptr) {
            counter++;
            curr = curr->next;
        }
        return counter;
    }

    void deleteLastNode() {    // Delete the last node in the bucket adjacency list
        buckets* curr = head;
        if (curr->next == NULL) {
            head = nullptr;
        }
        else{
            while (curr->next->next != NULL){
                curr = curr->next;
            }
            buckets* last = curr->next;
            curr->next = NULL;
            delete last;
        }
    }

    void deleteNodeIndex(int x) {    // Delete specific node (index = x) in the bucket adj. list
        buckets *current = head;
        buckets *previous = 0;
        while(current != 0 && current->index != x){
            previous = current;
            current = current->next;
        }

        if(current == 0){    // Case 1: list is empty
            cout << "There is no " << x << " in bucket."<< endl;
        }
        else if(current == head){    // Case 2: list contains exactly one number
            head = current->next;
            delete current;
            current = 0;
        }
        else{    // Case 3: list number >= 2
            previous->next = current->next;
            delete current;
            current = 0;
        }
    }

    int getBucketNode(){    // Return the last node in bucket
        buckets* curr = head;
        while (curr->next != nullptr) {
            curr = curr->next;
        }
        return curr->index;
    }

    void wrapAround(BucketList* bucket, int C){    // Implement Dial's bucket with wraparound buckets
        // 1. Find the minimum bucket(i) that have value, denoting findMinBucket
        int findMinBucket = 0;

        for(int i=0;i<C;i++){
            if(bucket[i].bucketSize() != 0){
                findMinBucket = i;
                break;
            }
        }

        // 2. Displace the bucket to the beginning
        for(int i=findMinBucket;i<=C;i++){
            bucket[i-findMinBucket].head = bucket[i].head;
        }

        // 3. Clear the redundent bucket
        for(int i=0;i<findMinBucket;i++){
            bucket[C-i].head = nullptr;
        }
    }
};

// Shortest path based on Dial's algorithm
void spdial(int source_node, int n,  Nodes* node, Arcs* arc, int* outdegree_num, AdjacencyList* adjList_out, int C){
    // 1. Initialized distance label
    for(int i=0;i<n;i++){
        if(i == source_node-1){
            node[i].d = 0;
            node[i].pred = -1;    // I used node(s) = -1 instead of 0 to prevent conflicting, because node 1 is node[0]
        }
        else{
            node[i].d = 999999;
        }
    }

    // 2. Initialized buckets
    BucketList* bucket = new BucketList[C+1];    // Dial's bucket (using array)
    int currentBucket = 0;    // minimum index of bucket that isn't empty
    int iterationDistance = 0;    // record the total distance that have been deleted cause by wraparound bucket
    bool scanEnd = false;    // Identify whether the Dial's algorithm has scan to the end

    // 3. Add source node to the bucket
    bucket[0].addNode(source_node-1);    // add source node to bucket(0)

    // 4. while loop
    while(!scanEnd){

        bucket->wrapAround(bucket, C);    // wraparound the bucket at the beginning, making FindMin = bucket[0]
        iterationDistance += currentBucket;

        // array that contains outdegree nodes and arcs of node i
        int* outdeg_num = adjList_out[bucket[0].getBucketNode() + 1].outdegree_nodes(outdegree_num[bucket[0].getBucketNode()]);
        int* outdeg_arc = adjList_out[bucket[0].getBucketNode() + 1].outdegree_arcs(outdegree_num[bucket[0].getBucketNode()]);

        for(int j=0;j<outdegree_num[bucket[0].getBucketNode()];j++){    // for each (i,j) in A(i)
            if(node[outdeg_num[j]-1].d > node[bucket[0].getBucketNode()].d + arc[outdeg_arc[j]-1].distance){    // if d(j) > d(i) + c_ij
                if(node[outdeg_num[j]-1].d != 999999){    // if d(j) != infinite
                    bucket[node[outdeg_num[j]-1].d - iterationDistance].deleteNodeIndex(node[outdeg_num[j]-1].node_index - 1);
                }

                node[outdeg_num[j]-1].d = node[bucket[0].getBucketNode()].d + arc[outdeg_arc[j]-1].distance;    // d(j) = d(i) + c_ij
                node[outdeg_num[j]-1].pred = bucket[0].getBucketNode();    // pred(j) = i

                bucket[node[outdeg_num[j]-1].d - iterationDistance].addNode(node[outdeg_num[j]-1].node_index - 1);    // add node to the bucket
            }
        }

        bucket[0].deleteLastNode();  // After scanning all the A(i), delete node i from bucket

        for(int i=0;i<C+1;i++){    // Check whether the Dial's algorithm has scan to the end
            if(bucket[i].bucketSize() != 0){
                currentBucket = i;
                scanEnd = false;
                break;
            }
            else{
                scanEnd = true;
            }
        }
    }    // End while

    // Print out the results
    int sum = 0;
    cout << endl;
    for(int i=0;i<n;i++){
        if(i+1 == source_node){
            continue;
        }
        else if(node[i].d == 999999){
            continue;
        }
        else{
            sum += node[i].d;
        }
    }
    cout << "---------------------------------" << endl;
    cout << "Sum of distances: " << sum << endl;

    delete[] bucket;    // Clear memory
}

int main () {
    string filename;
    cout << "Please input network filename: ";    // User input filename
    getline(cin, filename);
    ifstream file(filename);

    if(!file.is_open()){
        cerr << "Failed to open " << filename << endl;
        return 1;
    }

    string s, first, problem_type, problem_name;
    int n = 0;    // Number of nodes
    int m = 0;    // Number of arcs
    int CC = 0;    // Maximum c_ij in A (Dial's sp)
    int start_node = 0;    // Starting node of the arc
    int end_node = 0;    // Ending node of the arc
    int distance = 0;    // Distance of the arc
    int index = 0;    // Index of the arc
    bool counter = true;

    Arcs* arc;    // Record arcs
    Nodes* node;    // Record nodes
    AdjacencyList* adjList_out;    // Record adjacency list by outdegree
    int* outdegree_num;    // Record outdegree number of each node

    while (getline(file, s)) {
        istringstream stringfile(s);
        stringfile >> first;    // Read the first word of the line

        if(first[0]=='t'){    // Case 1: When read 't', record title of the problem name
            stringfile >> problem_name;
        }
        else if(first[0]=='p'){    // Case 2: When read 'p', record problem type, # of node and arc
            stringfile >> problem_type >> n >> m;

            // Dynamically allocating memory
            outdegree_num = new int[n];
            node = new Nodes[n];
            arc = new Arcs[m];
            adjList_out = new AdjacencyList[n];

            // Save the nodes
            for(int i=0;i<n;i++){
                node[i].node_index = i + 1;
            }
        }
        else if(first[0]=='a'){    // Case 3: When read 'a', record start node, end node and the distance between them
            stringfile >> start_node >> end_node >> distance;

            // Save the arc information
            arc[index].arc_index = index + 1;
            arc[index].s = start_node;
            arc[index].t = end_node;
            arc[index].distance = distance;

            // Check the outdegree number of each node
            if (counter){
                for(int i=0;i<n;i++){
                    outdegree_num[i] = 0;  // Initialized
                }
                counter = 0;
                outdegree_num[start_node-1]++;
            }
            else{   // Record outdegree number
                outdegree_num[start_node-1]++;
            }

            // Check the maximum arc length
            if(distance > CC){
                CC = distance;
            }

            // Add into adjacency list
            adjList_out[start_node].addNode(arc[index].t, arc[index].arc_index, arc[index].distance);
            index++;
        }
    }

    int source_node = 0;
    cout << "Please input a source node: ";    // User input source node
    cin >> source_node;

    if(source_node <= 0 || source_node > n){    // Print warning message
        cout << "\n!!Warning!!: Node " << source_node << " does not exist." << endl;
    }
    else {
        auto start = chrono::high_resolution_clock::now();

        spdial(source_node, n, node, arc, outdegree_num, adjList_out, CC);  // Execute Dial's SP algorithm
        
        auto stop = chrono::high_resolution_clock::now();
        auto duration = chrono::duration_cast<chrono::microseconds>(stop - start);
        cout << "Running time of SP computation: " << duration.count() << " microseconds" << endl;
        cout << "---------------------------------" << endl;

    }

    delete[] node;   // Clear the memory
    delete[] arc;
    delete[] outdegree_num;
    delete[] adjList_out;

    file.close();    // Close file

    return 0;
}

