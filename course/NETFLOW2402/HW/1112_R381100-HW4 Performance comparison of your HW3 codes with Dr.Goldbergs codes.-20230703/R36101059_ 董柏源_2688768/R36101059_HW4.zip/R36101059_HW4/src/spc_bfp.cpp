/*
   pseudocode:
   Read a file line by line
   Check every characters for every line
    if line[0] == 'c'
        then skip
    else if line[0] == 't'
        then recode title_of_problem_name
    else if line[0] == 'p'
        then recode problem_type, amount of nodes and amount of arcs
    else if line[0] == 'n'
        then skip
    else if line[0] == 'a'
        then recode from_node, to_node and length

    Construct a forward star

    Input a source node (s)

    BF_PAPE():
    Initialize;
    while(LIST != null){
        for each arc(i,j) belong to A(i){
            if d(j) > d(i) + Cij{
                d(j) = d(i) +Cij
                pred(j) = i
                if j is first update
                    add j to LIST.back()
                else
                    add j to LIST.front()
            }
        }
    }
    print out 1 to all , distance and path
   ---------------------------------------------------------------------------
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <ctime>
#include <queue>

// Settings
using namespace std;
string user_filename ;
int user_source_node = 0;
int user_sink_node = 0;
string line; //readFile line by line
string title_of_problem_name;
string problem_type;
char row_label;
int num_nodes =0; //amount of nodes
int num_arcs =0; //amount of arcs
int **graph; //data_structure
int arc_index_count;
int point_index_count;
int *point; // node in graph
int M = 999999;
priority_queue<vector<int>, vector<vector<int>>, greater<vector<int>> > pq;
vector<int> temp_pq;


clock_t my_timer;

int *d; //distance label
int *pred; //predecessor

vector<int> H; //Heap

//dial
vector<vector<int>> dial_bucket;
int C = 0;
int unlimited_index;
int current_bucket;
int deleted_node;

list<int> LIST; //BF_FIFO

fstream myFile;
void readFile();
void minHeapify(int,int);
void decreaseKey(int,int);
void heap();
void dial();
void BF_FIFO();
void BF_PAPE();
void print_out_path();

int main() {

    while(user_filename != "-1"){
        cout << "Please input network filename (or -1 to exit) : " ;
        cin >> user_filename ;
        myFile.open(user_filename);
        while(!myFile.is_open() && user_filename != "-1"){
            cout <<"failed. wrong filename."<<endl;
            cout << "Please input network filename (or -1 to exit) : " ;
            cin >> user_filename ;
            myFile.open(user_filename);
        }
        if(myFile.is_open()){

            cout << "opened"<<endl;
            readFile();

            cout << "Please input a source node (or -1 to exit , -2 to change input file) : " ;
            cin >> user_source_node ;
            while(user_source_node != -1 && user_source_node != -2){
                if(user_source_node > 0 && user_source_node <= num_nodes){


                    int test_times = 10000;
                    my_timer = clock();
                    for (int i = 0; i < test_times; i++){
                        //heap(); //execute algorithm
                        //dial(); //execute algorithm
                        //BF_FIFO(); //execute algorithm
                        BF_PAPE(); //execute algorithm
                    }
                    float process_time = float(clock() - my_timer)/test_times;
                    //print_out_path();
                    int sum_d = 0;
                    for (int i = 0 ; i<num_nodes ; i++){
                        if(d[i] != M)
                            sum_d += d[i];
                    }
                    cout<<"Sum of distances: " << sum_d<<endl;
                    cout<<"Running time of SP computation: " << process_time << " (ms)" <<endl;

                    cout << "Please input a source node (or -1 to exit , -2 to change input file) : " ;
                    cin >> user_source_node ;
                }
                else{
                    cout <<"!!Warning!!: node "<< user_source_node <<" does not exist"<< endl;
                    cout << "Please input a source node (or -1 to exit , -2 to change input file) : " ;
                    cin >> user_source_node ;
                }
            }
            if(user_source_node == -1){
                user_filename = "-1";
            }
        }
    }
    cout <<"exit"<< endl;

    return 0;
}

void readFile(){

    // Open file

    // Record file content
    //point[node]
    //graph[node][j] j=0 tail  j=1 head  j=2 length
    while (myFile.get(row_label)) {
        if(row_label == 'c'){
            getline(myFile, line);
        }
        else if(row_label == 'p'){
            myFile>>problem_type >> num_nodes >> num_arcs;
            //initialize point & graph size
            point = new int[num_nodes+1];
            graph = new int*[num_arcs];
            arc_index_count = 0;
            point_index_count = 0;
            temp_pq.resize(3);
        }
        else if(row_label == 'n'){
            getline(myFile, line);
        }
        else if(row_label == 'a'){
            myFile >> temp_pq[0] >> temp_pq[1] >> temp_pq[2];
            pq.push(temp_pq);
        }
    }
    while (!pq.empty()){
        //set array_point & array_graph
        graph[arc_index_count] = new int[3];
        auto now = pq.top();
        pq.pop();
        //cout << now[0] << " " << now[1] << " "<< now[2] << endl;
        graph[arc_index_count][0] = now[0];
        graph[arc_index_count][1] = now[1];
        graph[arc_index_count][2] = now[2];
        for(int i = point_index_count; i<graph[arc_index_count][0]; i++){
            point[i] = arc_index_count;
        }
        point_index_count = graph[arc_index_count][0];
        if(graph[arc_index_count][2] > C){ //for dial
            C = graph[arc_index_count][2];
        }
        arc_index_count++;
    }


    //forward star
    for(int i = graph[num_arcs-1][0]; i <= num_nodes;i++){
        point[i] = num_arcs;
    }

    //Close file
    myFile.close();
    return;
}

void minHeapify(int node_index,int heap_length){

    int left = 2*node_index;
    int right = 2*node_index+1;
    int smallest;

    if ( left <= heap_length && d[H[left]-1] <= d[H[node_index]-1])
        smallest = left;
    else
        smallest = node_index;

    if (right <= heap_length && d[H[right]-1] <= d[H[smallest]-1])
        smallest = right;

    if (smallest != node_index) {
        swap(H[smallest], H[node_index]);
        minHeapify(smallest,heap_length);
    }
}

void decreaseKey(int node_index, int new_d){

    d[H[node_index]-1] = new_d;
    while (node_index > 1 && d[H[node_index/2]-1] > d[H[node_index]-1]) {
        swap(H[node_index], H[node_index/2]);
        node_index = node_index/2;
    }

}

void heap(){
    //Initialize
    H.resize(1);
    d = new int[num_nodes];
    pred = new int[num_nodes];
    for(int i= 0 ; i<num_nodes ;i++){
        d[i] = M;
        pred[i] = 0;
    }
    d[user_source_node-1] = 0;
    deleted_node = 0;
    H.push_back(user_source_node);

    while(H.size() != 1){

        deleted_node = H[1];
        H[1] = H[H.size()-1];
        H.pop_back();
        minHeapify(1,H.size());
        for(int i = point[deleted_node-1]; i < point[deleted_node]; i++){
            if(graph[i][2]+d[deleted_node-1] < d[graph[i][1]-1]){
                if(d[graph[i][1]-1] == M){
                    H.push_back(graph[i][1]);
                    decreaseKey(H.size()-1,graph[i][2]+d[deleted_node-1]);
                }
                else{
                    for(int j = 1; j<H.size(); j++){
                        if(graph[i][1] == H[j]){
                            decreaseKey(j,graph[i][2]+d[deleted_node-1]);
                            break;
                        }
                    }
                }
                pred[graph[i][1]-1] = deleted_node;
            }
        }
    }

    return;
}

void dial(){
    //Initialize
    d = new int[num_nodes];
    pred = new int[num_nodes];
    dial_bucket.resize((num_nodes-1)*C+2);
    unlimited_index = (num_nodes-1)*C+1;
    current_bucket = 0;
    deleted_node = 0;

    for(int i= 0 ; i<num_nodes ;i++){
        d[i] = M;
        pred[i] = 0;
        if( i+1 != user_source_node){
            dial_bucket[unlimited_index].push_back(i+1);
        }
        else{
            dial_bucket[0].push_back(i+1);
        }
    }
    d[user_source_node-1] = 0;


    while(!(current_bucket == unlimited_index-1 && dial_bucket[unlimited_index-1].size() == 0)){
        if(dial_bucket[current_bucket].size() != 0){
            deleted_node = dial_bucket[current_bucket][0];
            dial_bucket[current_bucket].erase(dial_bucket[current_bucket].begin());
            for(int i = point[deleted_node-1]; i < point[deleted_node]; i++){
                if(graph[i][2]+d[deleted_node-1] < d[graph[i][1]-1]){
                    if(d[graph[i][1]-1] == M){
                        d[graph[i][1]-1] = graph[i][2]+d[deleted_node-1]; // update distance label
                        for(int j = 0; j<dial_bucket[unlimited_index].size(); j++){
                            if(graph[i][1] == dial_bucket[unlimited_index][j]){
                                dial_bucket[d[graph[i][1]-1]].push_back(graph[i][1]);
                                dial_bucket[unlimited_index].erase(dial_bucket[unlimited_index].begin()+j);
                                break;
                            }
                        }
                    }
                    else{
                        d[graph[i][1]-1] = graph[i][2]+d[deleted_node-1]; // update distance label
                        for(int j = current_bucket; j<dial_bucket.size()-1; j++){
                            for(int k = 0; k<dial_bucket[j].size(); k++){
                                if(graph[i][1] == dial_bucket[j][k]){
                                    dial_bucket[d[graph[i][1]-1]].push_back(graph[i][1]);
                                    dial_bucket[j].erase(dial_bucket[j].begin()+k);
                                    break;
                                }
                            }
                        }
                    }
                    pred[graph[i][1]-1] = deleted_node;
                }
            }
        }
        else
            current_bucket++;
    }

    return;
}

void BF_FIFO(){
    //Initialize
    d = new int[num_nodes];
    pred = new int[num_nodes];
    LIST.clear();
    for(int i= 0 ; i<num_nodes ;i++){
        d[i] = M;       //d[node_index] = length
        pred[i] = 0;    //pred[node_index] = node_number
    }
    d[user_source_node-1] = 0;
    LIST.push_back(user_source_node);

    while(!LIST.empty()){
        for (int i = point[LIST.front()-1]; i<point[LIST.front()]; i++){
            if(d[graph[i][1]-1] > d[LIST.front()-1] + graph[i][2]){
                 d[graph[i][1]-1] = d[LIST.front()-1] + graph[i][2];
                 pred[graph[i][1]-1] = LIST.front();
                 LIST.push_back(graph[i][1]);
            }
        }
        LIST.pop_front();
    }

    return;
}

void BF_PAPE(){
    //Initialize
    d = new int[num_nodes];
    pred = new int[num_nodes];
    LIST.clear();
    for(int i= 0 ; i<num_nodes ;i++){
        d[i] = M;       //d[node_index] = length
        pred[i] = 0;    //pred[node_index] = node_number
    }
    d[user_source_node-1] = 0;
    LIST.push_back(user_source_node);
    int delete_node = 0;

    while(!LIST.empty()){
        delete_node = LIST.front();
        LIST.pop_front();
        for (int i = point[delete_node-1]; i<point[delete_node]; i++){
            if(d[graph[i][1]-1] > d[delete_node-1] + graph[i][2]){
                if(d[graph[i][1]-1] == M)
                    LIST.push_back(graph[i][1]);
                else
                    LIST.push_front(graph[i][1]);
                d[graph[i][1]-1] = d[delete_node-1] + graph[i][2];
                pred[graph[i][1]-1] = delete_node;
            }
        }
    }

    return;
}

void print_out_path(){
    for (int i = 1; i<=num_nodes; i++){
        if(i != user_source_node){
            cout<< user_source_node <<"->"<<i<<": ";

            if(pred[i-1] == 0){
                cout<< "[can not reach]"<<endl;
            }
            else{
                cout<<"["<<d[i-1]<<"] "<< i <<"<-";
                int pass_node = i ;
                while(pred[pass_node-1] != user_source_node){
                    cout<< pred[pass_node-1] << "<-";
                    pass_node = pred[pass_node-1];
                }
                cout<<user_source_node<<endl;
            }
        }
    }
}
