/* This code is to find a shortest path from certain source node to other nodes based on Dijkstra's Dial's implementation. */
# include <iostream>
# include <fstream>
# include <string>
# include <vector>
# include <sstream>
#include <ctime>
using namespace std;

struct Arc{
    long tail;
    long head;
    long length;
};

struct DNode{
    int index;
    DNode *next;
};

//# include "check_time.c"
//# include "readfile.cpp"

long spdial(int &, vector<Arc> *&, long &, int &, long *&, int *&, DNode **&);
void Insert(DNode *, DNode *);
void Clear(DNode *, int);

int main(){
    string pname; //problem name
    int run = 10000;
    int V, E;
    int s;
    long M = 0;
    vector<Arc> *L;
    float t, T;
    long sum_d;
    long d;
    clock_t my_timer;
    //RF(pname, V, E, M, L, s);

    /* dijkstra dial */
    long *distance;    // to record the distance
    int *pred;              // to record the pred
    DNode **bucket;
    distance = new long [V];
    pred = new int [V];
    bucket = new DNode *[(V-1)*M+1];

    T = 0;
    sum_d = 0;
    for( int k = 0; k < run; k++){
        for(int i = 0; i < V; ++i){
            distance[i] = M*V;
            pred[i] = -1;
        }
        for(int i = 0; i < (V-1)*M+1; ++i) bucket[i] = NULL;
        my_timer = clock();
        d = spdial(V, L, M, s, distance, pred, bucket);
        my_timer = clock() - t;
        T += my_timer;
        sum_d += d;
    }
    cout<<"mydikb "<<pname<<" "<<sum_d/run<<" "<<T/run<<endl;

    return 0;
}
void readFile(){

    // Open file

    // Record file content
    //point[node]
    //graph[node][j] j=0 tail  j=1 head  j=2 length
    while (myFile.get(row_label)) {
        if(row_label == 'c'){
            getline(myFile, line);
        }
        else if (row_label == 't'){
            myFile >> title_of_problem_name;

        }
        else if(row_label == 'p'){
            //myFile << "\t" << 10;
            myFile>>problem_type >> num_nodes >> num_arcs;
            //initialize point & graph size
            point = new int[num_nodes+1];
            graph = new int*[num_arcs];
            arc_index_count = 0;
            point_index_count = 0;
            temp_pq.resize(3);

        }
        else if(row_label == 'n'){
            //myFile << "\t" << 10;
            getline(myFile, line);
            //myFile << "\t" << 10;
        }
        else if(row_label == 'a'){
            myFile >> temp_pq[0] >> temp_pq[1] >> temp_pq[2];
            pq.push(temp_pq);
        }
    }
    while (!pq.empty()){
        //set array_point & array_graph
        graph[arc_index_count] = new int[3];
        auto now = pq.top();
        pq.pop();
        //cout << now[0] << " " << now[1] << " "<< now[2] << endl;
        graph[arc_index_count][0] = now[0];
        graph[arc_index_count][1] = now[1];
        graph[arc_index_count][2] = now[2];
        for(int i = point_index_count; i<graph[arc_index_count][0]; i++){
            point[i] = arc_index_count;
        }
        point_index_count = graph[arc_index_count][0];
        if(graph[arc_index_count][2] > C){ //for dial
            C = graph[arc_index_count][2];
        }
        arc_index_count++;
    }


    //forward star
    for(int i = graph[num_arcs-1][0]; i <= num_nodes;i++){
        point[i] = num_arcs;
    }

    //Close file
    myFile.close();
    return;
}
long spdial(int &V, vector<Arc> *&L, long &M, int &s, long *&distance, int *&pred, DNode **&bucket){
    long sum = 0;       // sum of all shortest path length from source node s
    int x;
    long d;                  // x: to take the nodes in bucket or is the predecessor, d: take the distance, easy to use
    int stop = 0;

    /* Initialize */



    DNode *t = (DNode *) malloc (sizeof(DNode));
    t->index = s; t->next = NULL;
    bucket[0] = t;
    pred[s-1] = 0;

    for(int i = 0; i < (V-1)*M+1; ++i){
        /* No element in this bucket */
        if(bucket[i] == NULL) continue;

        /* Elements in this bucket */
        while(bucket[i] != NULL){
            x = bucket[i]->index;
            if(distance[x-1] > i) distance[x-1] = i;
            stop += 1;

            for(int j = 0; j < L[x-1].size(); ++j){
                // if distance update
                if(distance[L[x-1][j].head-1] > i + L[x-1][j].length){
                    d = distance[L[x-1][j].head-1];

                    // if node L[x-1][j] in other bucket
                    if(d != M*V){
                        if(bucket[d]->index == L[x-1][j].head) bucket[d] = bucket[d]->next;
                        else Clear(bucket[d], L[x-1][j].head);
                    }

                    DNode *t = (DNode *) malloc (sizeof(DNode));
                    t->index = L[x-1][j].head;
                    t->next = NULL;

                    // update the predecessor and distance
                    pred[L[x-1][j].head-1] = x;
                    distance[L[x-1][j].head-1] = i + L[x-1][j].length;

                    // insert to the bucket
                    d = distance[L[x-1][j].head-1];
                    if(bucket[d] == NULL) bucket[d] = t;
                    else Insert(bucket[d], t);
                }
            }
            // if there is other node in the same bucket, point to the next node
            // otherwise, point to null
            bucket[i] = bucket[i]->next;
        }
        if(stop == V) break;
    }

    for(int i =0; i<V;++i){
       if(distance[i] != M*V) sum+= distance[i];
    }

    return sum;
}

void Insert(DNode *bucket, DNode *n){
    if(bucket->next) Insert(bucket->next, n);
    else bucket->next = n;
    return;
}

void Clear(DNode *bucket, int index){
    if(bucket->index!=index) Clear(bucket->next, index);
    else bucket = bucket->next;
    return ;
}
