#!/bin/bash

cd ..
for ((i=1; i<=6; i++)); do
    ./bin/bf < ./inputs/$i.txt >> ./results/bf.txt
    echo "$i finished."
done
