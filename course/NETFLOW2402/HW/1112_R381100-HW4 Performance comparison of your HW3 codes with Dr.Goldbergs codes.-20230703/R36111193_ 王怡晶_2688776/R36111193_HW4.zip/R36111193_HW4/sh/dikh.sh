#!/bin/bash

cd ..
for ((i=1; i<=6; i++)); do
    ./bin/dikh < ./inputs/$i.txt >> ./results/dikh.txt
    echo "$i finished."
done
