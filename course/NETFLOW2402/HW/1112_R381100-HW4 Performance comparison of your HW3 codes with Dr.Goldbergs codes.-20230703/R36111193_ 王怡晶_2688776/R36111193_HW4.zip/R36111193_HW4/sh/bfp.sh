#!/bin/bash

cd ..
for ((i=1; i<=6; i++)); do
    ./bin/bfp < ./inputs/$i.txt >> ./results/bfp.txt
    echo "$i finished."
done
