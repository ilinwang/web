#!/bin/bash

cd ..
for ((i=1; i<=6; i++)); do
    ./bin/dikb < ./inputs/$i.txt >> ./results/dikb.txt
    echo "$i finished."
done
