/*
    This code can be compiled and run ok.

    input file: input_s1_1.txt
                input_s1_2.txt
                input_s1_3.txt
                input_s2_1.txt
                input_s2_2.txt
                input_s2_3.txt

    purpose: 
        1.Read a network file with a format similar to input_s1_1.txt
            input_s1_2.txt
            input_s1_3.txt
            input_s2_1.txt
            input_s2_2.txt
            input_s2_3.txt
        2.Ask the user to input a node index

    usage:
        input network filename, e.g. input_s1_1.txt
        input_s1_2.txt
        input_s1_3.txt
        input_s2_1.txt
        input_s2_2.txt
        input_s2_3.txt
    
    compile:
        visual studio code

    pseudo-code:
       input filename
        cin >> source
        cin >> sink




        void dial()
            for(int i= 0 ; i<node_quantity ;i++){
            d[i] = M;
            pred[i] = 0;
            if( i+1 != source){
                pail[_infinite].push_back(i+1);
            }
            else{
                pail[0].push_back(i+1);
            }
        }
        while(!(current_pail == _infinite-1 && pail[_infinite-1].size() == 0)){
                if(pail[current_pail].size() != 0){
                    _delete = pail[current_pail][0];
                    pail[current_pail].erase(pail[current_pail].begin());
                    for(int i = point[_delete-1]; i < point[_delete]; i++){
                        if(_array[i][2]+d[_delete-1] < d[_array[i][1]-1]){
                            if(d[_array[i][1]-1] == M){
                                d[_array[i][1]-1] = _array[i][2]+d[_delete-1];
                                for(int j = 0; j<pail[_infinite].size(); j++){
                                    if(_array[i][1] == pail[_infinite][j]){
                                        pail[d[_array[i][1]-1]].push_back(_array[i][1]);
                                        pail[_infinite].erase(pail[_infinite].begin()+j);
                                        break;
                                    }
                                }
                            }
                            else{
                                d[_array[i][1]-1] = _array[i][2]+d[_delete-1];
                                for(int j = current_pail; j<pail.size()-1; j++){
                                    for(int k = 0; k<pail[j].size(); k++){
                                        if( _array[i][1] == pail[j][k]){
                                            pail[d[ _array[i][1]-1]].push_back( _array[i][1]);
                                            pail[j].erase(pail[j].begin()+k);
                                            break;
                                        }
                                    }
                                }
                            }
                            pred[_array[i][1]-1] = _delete;
                        }
                    }
                }
                else
                    current_pail++;
            }
                

    coded by Yi-Jing Wang, ID: r36111193, email: sandy19980920@gmail.com
    date: 2023.05.07
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <ctime>
#include <queue>
using namespace std;

int source=0;// input


// read file
void readFile();
string filename;
fstream infile;
char test;
string line;
string gar;
int node_quantity =0; //node數
int arc_quantity =0; //arc數
int ** _array; //動態矩陣
int aa;
int pp;
int *point;
priority_queue<vector<int>, vector<vector<int> >, greater<vector<int> > > pq;
vector<int> temp_pq;


//dial
int *d;
int *pred;
vector<int> H;
int M = 99999999;
int C=0;
int _delete;


vector<vector<int> > pail;
int _infinite;
int current_pail;
void dial();

void print_out_path();


clock_t time_clock;
int main() {

    while(filename != "-1"){
        cout << "enter the filename (or -1 to exit) : ";
        cin >> filename ;

        infile.open(filename);
        while(!infile.is_open() && filename != "-1"){
            cout <<"wrong filename."<<endl;
            cout << "enter the filename (or -1 to exit)  : ";
            cin >> filename ;
        }
        if(infile.is_open()){

            cout << "opened"<<endl;
            readFile();

            cout << "enter the source node(or -1 to exit) " ;
            cin >> source ;
            if(source > 0 && source <= node_quantity){


                int times = 10;
                time_clock = clock();
                for (int i = 0; i < times; i++){
                    
                    dial();
                }
                float process_time = float(clock() - time_clock)/times;
                int sum_d = 0;
                for (int i = 0 ; i<node_quantity ; i++){
                    if(d[i] != M)
                        sum_d += d[i];
                }
                cout<<"Sum of distances: " << sum_d<<endl;
                cout<<"Running time of SP computation: " << process_time << " (ms)" <<endl;

            }
 
        }
    }
    cout <<"exit"<< endl;

    return 0;
}



void readFile(){
    while (infile.get(test)) {

            if(test == 'c' || test == 't' || test == 'n'){
                getline(infile, line);
            }
            else if (test == 'p'){
                infile >> gar >> node_quantity >> arc_quantity;
                point = new int[node_quantity+1];
                _array = new int*[arc_quantity];
                aa = 0;
                pp = 0;
                temp_pq.resize(3);
            }
            else if (test == 'a'){
                infile >> temp_pq[0] >> temp_pq[1] >> temp_pq[2];
                pq.push(temp_pq);

            }
    }
    while (!pq.empty()){
        _array[aa] = new int[3];
        auto now = pq.top();
        pq.pop();

        _array[aa][0] = now[0];
        _array[aa][1] = now[1];
        _array[aa][2] = now[2];

        for (int i = pp; i < _array[aa][0]; i++){
            point[i] = aa;
        }
        pp = _array[aa][0];
        if (_array[aa][2]> C){
            C = _array[aa][2];
    
    }
    aa++;

}
    for (int i = _array[arc_quantity-1][0]; i< node_quantity;i++){
        point[i] = arc_quantity;
    }
    infile.close();
    return;
}

void dial(){
    d = new int[node_quantity];
    pred = new int[node_quantity];
    pail.resize((node_quantity-1)*C+2);
    _infinite = (node_quantity-1)*C+1;
    current_pail = 0;
    _delete = 0;

    for(int i= 0 ; i<node_quantity ;i++){
        d[i] = M;
        pred[i] = 0;
        if( i+1 != source){
            pail[_infinite].push_back(i+1);
        }
        else{
            pail[0].push_back(i+1);
        }
    }
    d[source-1] = 0;

    while(!(current_pail == _infinite-1 && pail[_infinite-1].size() == 0)){
        if(pail[current_pail].size() != 0){
            _delete = pail[current_pail][0];
            pail[current_pail].erase(pail[current_pail].begin());
            for(int i = point[_delete-1]; i < point[_delete]; i++){
                if(_array[i][2]+d[_delete-1] < d[_array[i][1]-1]){
                    if(d[_array[i][1]-1] == M){
                        d[_array[i][1]-1] = _array[i][2]+d[_delete-1]; 
                        for(int j = 0; j<pail[_infinite].size(); j++){
                            if(_array[i][1] == pail[_infinite][j]){
                                pail[d[_array[i][1]-1]].push_back(_array[i][1]);
                                pail[_infinite].erase(pail[_infinite].begin()+j);
                                break;
                            }
                        }
                    }
                    else{
                        d[_array[i][1]-1] = _array[i][2]+d[_delete-1]; 
                        for(int j = current_pail; j<pail.size()-1; j++){
                            for(int k = 0; k<pail[j].size(); k++){
                                if( _array[i][1] == pail[j][k]){
                                    pail[d[ _array[i][1]-1]].push_back( _array[i][1]);
                                    pail[j].erase(pail[j].begin()+k);
                                    break;
                                }
                            }
                        }
                    }
                    pred[_array[i][1]-1] = _delete;
                }
            }
        }
        else
            current_pail++;
    }
    // print_out_path();
    return;
}


// void print_out_path(){
//     for (int i = 1; i<=node_quantity; i++){
//         if(i != source){
//             cout<< source <<"->"<<i<<": ";

//             if(pred[i-1] == 0){
//                 cout<< "[can not reach]"<<endl;
//             }
//             else{
//                 cout<<"["<<d[i-1]<<"] "<< i <<"<-";
//                 int pass_node = i ;
//                 while(pred[pass_node-1] != source){
//                     cout<< pred[pass_node-1] << "<-";
//                     pass_node = pred[pass_node-1];
//                 }
//                 cout<<source<<endl;
//             }
//         }
//     }
// }

