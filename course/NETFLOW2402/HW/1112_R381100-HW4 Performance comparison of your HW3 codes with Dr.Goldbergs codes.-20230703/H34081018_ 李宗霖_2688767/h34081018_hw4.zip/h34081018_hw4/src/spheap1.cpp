/*
This is to read a network and to do Dijkstra's binary heap implementation.
   
    usage:
        read the network info, choose a source node then see results

        execute spheap1
        input the file name and one node numbers
    
    input file:
        test1.sp or test2.sp
        
    output files:
        none
        
    compile:
        g++ -o spheap1 spheap1.cpp

    pseudocode:
    input filename to read file
    ------
    use struct and class to define arcs and Graphs
    ------
    create_heap(int s){
        initialize heap, pred, and distance with n + 1 spaces
        all distance = inf
        distance(s) = 0
        pred(s) = 0
        insert s
    }
    index(int node){
        return the index of node in heap
    }
    siftup(int node){
        while node is not a root and distance(node) < distance(parent(node)) do swap(node, parent(node))
    }
    siftdown(int node){
        while node is not a leaf and distance(node) > distance(min_child(node)) do swap(node, min_child(node))
    }
    delete_min(){
        swap(old_root, last)
        last--
        siftdown(new_root)
        return old_root
    }
    dijkstra_heap(int s){
        create_heap(s);
        while(heap is not empty){
            cur = delete_min();
            if(cur == node_num){
                continue;
            }
            scan through the arcs start from cur and update distance and heap if needed
        }
        printd(s);
    }
    ------

    coded by Tsung-Lin Li, ID: h34081018, email: h34081018@gs.ncku.edu.tw
    date: 2023.04.10
*/
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <algorithm>
#include <ctime>

using namespace std;

struct edge{
    int head;
    int tail;
    int length;
};

class Graph{
    int node_num, arc_num;
    edge *arcs;
    int *point;
    int *heap, *pred, *d;
    int last = 0;

    public:
    Graph(string filename){
        ifstream readfile(filename);
        string Text;
        int temp = 1, latest_tail = 0;

        // read file line by line
        while (getline (readfile, Text)) {
            // initialize dynamic allocated array
            if(Text[0] == 'p'){
                Text = Text.substr(5);
                istringstream is(Text);
                is >> node_num >> arc_num;
                arcs = new edge[arc_num + 1];
                point = new int[node_num + 1];
            }
            // store arc info
            else if(Text[0] == 'a'){
                Text = Text.substr(2);
                istringstream is(Text);
                is >> arcs[temp].tail >> arcs[temp].head >> arcs[temp].length;
                if(latest_tail != arcs[temp].tail){
                    point[arcs[temp].tail] = temp;
                    latest_tail = arcs[temp].tail;
                }
                else if (temp == arc_num){
                    point[node_num] = arc_num + 1;
                }
                temp++;
            }
        }
        readfile.close();

        for(int i = 1; i < node_num + 1; i++){
            if(point[i] >= arc_num){
                point[i] = arc_num + 1;
            }
            else if(point[i] <= 0){
                point[i] = arc_num + 1;
            }
        }
    }

    void printGraph(){
        for(int i = 1; i < arc_num + 1; i++){
            printf("edge %i (%i -> %i): %i\n", i, arcs[i].tail, arcs[i].head, arcs[i].length);
        }
        for(int i = 1; i < node_num + 1; i++){
            printf("point %i: %i\n", i, point[i]);
        }
    }
    void create_heap(int s){
        heap = new int[node_num + 1];
        pred = new int[node_num + 1];
        d = new int[node_num + 1];
        for(int i = 1; i < node_num + 1; i++){
            d[i] = INT_MAX;
        }
        d[s] = 0;
        pred[s] = 0;
        insert(s);
    }

    void insert(int temp){
        heap[++last] = temp;
    }

    int index(int temp){
        for(int i = 1; i < node_num + 1; i++){
            if(heap[i] == temp) return i;
        }
    }

    void siftup(int temp){
        if(index(temp) > last){
            return;
        }
        while(index(temp) != 1 && d[index(temp)] < d[index(temp) / 2]){
            swap(heap[index(temp)], heap[index(temp) / 2]);
        }
    }

    void siftdown(int temp){
        while(last >= index(temp) * 2){
            int min_child;
            if(last == index(temp) * 2 || d[index(temp) * 2] <= d[index(temp) * 2 + 1]){
                min_child = index(temp) * 2;
            }
            else{
                min_child = index(temp) * 2 + 1;
            }
            if(d[index(temp)] > d[min_child]){
                swap(heap[temp], heap[min_child]);
                temp = min_child;
            }
            else{
                break;
            }
        }
    }

    int delete_min(){
        int temp = heap[1];
        swap(heap[1], heap[last]);
        last--;
        siftdown(heap[1]);
        return temp;
    }

    void dijkstra_heap(int s){
        create_heap(s);
        while(last != 0){
            int cur = delete_min();
            if(cur == node_num){
                continue;
            }
            for(int j = point[cur]; j < point[cur + 1]; j++){
                int temp = d[cur] + arcs[j].length;
                if(d[arcs[j].head] > temp){
                    if(d[arcs[j].head] == INT_MAX){
                        insert(arcs[j].head);
                    }
                    d[arcs[j].head] = temp;
                    pred[arcs[j].head] = cur;
                    siftup(last);
                }
            }
        }
    }

    void printd(int s){
        for(int i = 1; i < node_num + 1; i++){
            if(i == s){
                continue;
            }
            if(d[i] != INT_MAX){
                printf("%i->%i: [%i] ", s, i, d[i]);
                int temp = i;
                while(temp != s){
                    cout << temp << "<-";
                    temp = pred[temp];
                }
                cout << s << endl;
            }
            else{
                printf("%i->%i: [can not reach]\n", s, i);
            }
        }
    }

    void sumd(){
        int total = 0;
        for(int i = 1; i < node_num + 1; i++){
            if(d[i] != INT_MAX){
                total += d[i];
            }
        }
        cout << "sum of shortest paths: " << total;
    }

    ~Graph(){
        delete[] arcs, point, heap, pred, d;
    }
};

int main(){
    string filename;
    cout << "Please input filename: ";
    cin >> filename;
    clock_t a, b;
    Graph g1(filename);

    int source;
    cout << "Please input index of source node: ";
    cin >> source;

    a = clock();
    g1.dijkstra_heap(source);
    b = clock();
    g1.sumd();
    g1.~Graph();
    // cout <<  a << "\t" << b << endl;

    return 0;
}