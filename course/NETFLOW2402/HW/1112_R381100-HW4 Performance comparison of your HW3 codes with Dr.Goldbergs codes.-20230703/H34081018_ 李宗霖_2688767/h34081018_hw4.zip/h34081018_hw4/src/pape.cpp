/*
This is to read a network and to do PAPE implementation.
   
    usage:
        read the network info, choose a source node then see results

        execute spdial1
        input the file name and one node numbers
    
    input file:
        test1.sp or test2.sp
        
    output files:
        none
        
    compile:
        g++ -o pape pape.cpp

    pseudocode:
    input filename to read file
    ------
    use struct and class to define arcs and Graphs
    ------
    pape(int s){
        initialize pred and distance with n + 1 spaces
        all distance = inf
        distance(s) = 0
        pred(s) = 0
        insert s to list
        while(list is not empty)
            fifo node temp from list
            and update(temp)
    }
    
    insert(int node){
        if(!visited[node]){
            visited[node] = true;
            list.push_back(node);
        }
        else{
            list.insert(list.begin(), node);
        }
    }
    ------

    coded by Tsung-Lin Li, ID: h34081018, email: h34081018@gs.ncku.edu.tw
    date: 2023.05.07
*/
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <ctime>

using namespace std;

struct edge{
    int head;
    int tail;
    int length;
};

class Graph{
    int node_num, arc_num;
    edge *arcs;
    int *point;
    int *pred, *d;
    bool *visited;
    vector <int> list;

    public:
    Graph(string filename){
        ifstream readfile(filename);
        string Text;
        int temp = 1, latest_tail = 0;

        // read file line by line
        while (getline (readfile, Text)) {
            // initialize dynamic allocated array
            if(Text[0] == 'p'){
                Text = Text.substr(5);
                istringstream is(Text);
                is >> node_num >> arc_num;
                arcs = new edge[arc_num + 1];
                point = new int[node_num + 1];
                visited = new bool[node_num + 1];
            }
            // store arc info
            else if(Text[0] == 'a'){
                Text = Text.substr(2);
                istringstream is(Text);
                is >> arcs[temp].tail >> arcs[temp].head >> arcs[temp].length;
                if(latest_tail != arcs[temp].tail){
                    point[arcs[temp].tail] = temp;
                    latest_tail = arcs[temp].tail;
                }
                else if (temp == arc_num){
                    point[node_num] = arc_num + 1;
                }
                temp++;
            }
        }
        readfile.close();

        for(int i = 1; i < node_num + 1; i++){
            if(point[i] >= arc_num){
                point[i] = arc_num + 1;
            }
            else if(point[i] <= 0){
                point[i] = arc_num + 1;
            }
        }
    }

    void pape(int s){
        pred = new int[node_num + 1];
        d = new int[node_num + 1];
        for(int i = 1; i < node_num + 1; i++){
            d[i] = INT_MAX;
            visited[i] = false;
        }
        d[s] = 0;
        pred[s] = 0;
        visited[s] = true;
        list.push_back(s);

        while(!list.empty()){
            int cur = list.front();
            list.erase(list.begin());
            if(point[cur] > arc_num){
                break;
            }
            for(int j = point[cur]; j < point[cur + 1]; j++){
                int temp = d[cur] + arcs[j].length;
                if(temp < d[arcs[j].head]){
                    d[arcs[j].head] = temp;
                    pred[arcs[j].head] = cur;
                    insert(arcs[j].head);
                }
            }
        }
    }
    void insert(int node){
        if(!visited[node]){
            visited[node] = true;
            list.push_back(node);
        }
        else{
            list.insert(list.begin(), node);
        }
    }
    void printGraph(){
        for(int i = 1; i < arc_num + 1; i++){
            printf("edge %i (%i -> %i): %i\n", i, arcs[i].tail, arcs[i].head, arcs[i].length);
        }
        for(int i = 1; i < node_num + 1; i++){
            printf("point %i: %i\n", i, point[i]);
        }
    }

    void printd(int s){
        for(int i = 1; i < node_num + 1; i++){
            if(i == s){
                continue;
            }
            if(d[i] != INT_MAX){
                printf("%i->%i: [%i] ", s, i, d[i]);
                int temp = i;
                while(temp != s){
                    cout << temp << "<-";
                    temp = pred[temp];
                }
                cout << s << endl;
            }
            else{
                printf("%i->%i: [can not reach]\n", s, i);
            }
        }
    }

    void sumd(){
        int total = 0;
        for(int i = 1; i < node_num + 1; i++){
            if(d[i] != INT_MAX){
                total += d[i];
            }
        }
        cout << "sum of shortest paths: " << total;
    }


    ~Graph(){
        delete[] arcs, point, pred, d, visited;
    }
};

int main(){
    string filename;
    cout << "Please input filename: ";
    cin >> filename;
    clock_t a, b;
    Graph g1(filename);

    int source;
    cout << "Please input index of source node: ";
    cin >> source;

    a = clock();
    g1.pape(source);
    b = clock();
    g1.sumd();
    g1.~Graph();
    // cout <<  a << "\t" << b << endl;

    return 0;
}