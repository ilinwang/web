- compile the c++ file "bf/pape/spdial1/spheap1.cpp"
	- input the name of network (e.g. input1.txt)
	- then input the index of source node (e.g. 10)

- compile the c file "bf/bfp/dikb/dikh.c"
	- run the batch file "bf/bfp/dikb/dikh" to get the result

- failed to run spdial1/spheap1 on some network instances