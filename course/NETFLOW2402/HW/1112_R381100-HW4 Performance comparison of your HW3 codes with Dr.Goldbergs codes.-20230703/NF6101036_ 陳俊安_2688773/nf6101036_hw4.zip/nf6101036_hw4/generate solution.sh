echo "#!/bin/bash" > script.sh
echo "cd /Users/joseph/Desktop/Netflow/HW/HW4/nf6101036_hw4" >> script.sh
echo "" >> script.sh

SS_cat=(10 20 2 10)
S_cat=(100 500 100 10000)
L_cat=(2000 12000 10 100)
final_dst="result"
source_node=10


for alg in dikh dikb bf bfp
do
    for file in spgrid sprand spacyc
    # for file in sprand spacyc
    # for file in spgrid
    do
        for seed in 1 2 3
        do
            # echo "bin/$alg < inputs/${file}_n${SS_cat[0]}_m${SS_cat[1]}_seed${seed}_cmax${SS_cat[3]}_cmin${SS_cat[2]}_source${source_node}.txt > $final_dst/${alg}_${file}_n${SS_cat[0]}_m${SS_cat[1]}_seed${seed}_cmax${SS_cat[3]}_cmin${SS_cat[2]}_source${source_node}_solution.txt" >> script.sh
            echo "bin/$alg < inputs/${file}_n${S_cat[0]}_m${S_cat[1]}_seed${seed}_cmax${S_cat[3]}_cmin${S_cat[2]}_source${source_node}.txt > $final_dst/${alg}_${file}_n${S_cat[0]}_m${S_cat[1]}_seed${seed}_cmax${S_cat[3]}_cmin${S_cat[2]}_source${source_node}_solution.txt" >> script.sh
            echo "bin/$alg < inputs/${file}_n${L_cat[0]}_m${L_cat[1]}_seed${seed}_cmax${L_cat[3]}_cmin${L_cat[2]}_source${source_node}.txt > $final_dst/${alg}_${file}_n${L_cat[0]}_m${L_cat[1]}_seed${seed}_cmax${L_cat[3]}_cmin${L_cat[2]}_source${source_node}_solution.txt" >> script.sh
        done
    done
done


# for alg in My_BF_deque My_BF_queue My_spdial My_spheap
for alg in My_BF_deque_long My_BF_queue_long My_spdial_long My_spheap_long
# for alg in My_spdial_long
do
    for file in spgrid sprand spacyc
    # for file in sprand spacyc
    # for file in spgrid
    do
        for seed in 1 2 3
        do
            # echo "bin/$alg inputs/${file}_n${SS_cat[0]}_m${SS_cat[1]}_seed${seed}_cmax${SS_cat[3]}_cmin${SS_cat[2]}.txt $source_node > $final_dst/${alg}_${file}_n${SS_cat[0]}_m${SS_cat[1]}_seed${seed}_cmax${SS_cat[3]}_cmin${SS_cat[2]}_source${source_node}_solution.txt" >> script.sh
            echo "bin/$alg inputs/${file}_n${S_cat[0]}_m${S_cat[1]}_seed${seed}_cmax${S_cat[3]}_cmin${S_cat[2]}.txt $source_node > $final_dst/${alg}_${file}_n${S_cat[0]}_m${S_cat[1]}_seed${seed}_cmax${S_cat[3]}_cmin${S_cat[2]}_source${source_node}_solution.txt" >> script.sh
            echo "bin/$alg inputs/${file}_n${L_cat[0]}_m${L_cat[1]}_seed${seed}_cmax${L_cat[3]}_cmin${L_cat[2]}.txt $source_node > $final_dst/${alg}_${file}_n${L_cat[0]}_m${L_cat[1]}_seed${seed}_cmax${L_cat[3]}_cmin${L_cat[2]}_source${source_node}_solution.txt" >> script.sh
        done
    done
done
