echo "#!/bin/bash" > script.sh
echo "cd /Users/joseph/Documents/C++/HW4/netflow_splib" >> script.sh
echo "" >> script.sh

SS_cat=(10 20 2 10)
S_cat=(100 500 100 10000)
L_cat=(2000 12000 10 100)


for seed in 1 2 3
do
    for file in sprand spacyc
    do
        # echo "src/$file ${SS_cat[0]} ${SS_cat[1]} $seed -ll${SS_cat[3]} -lm${SS_cat[2]}  > inputs/${file}_n${SS_cat[0]}_m${SS_cat[1]}_seed${seed}_cmax${SS_cat[3]}_cmin${SS_cat[2]}.txt" >> script.sh
        echo "src/$file ${S_cat[0]} ${S_cat[1]} $seed -ll${S_cat[3]} -lm${S_cat[2]}  > inputs/${file}_n${S_cat[0]}_m${S_cat[1]}_seed${seed}_cmax${S_cat[3]}_cmin${S_cat[2]}.txt" >> script.sh
        echo "src/$file ${L_cat[0]} ${L_cat[1]} $seed -ll${L_cat[3]} -lm${L_cat[2]}  > inputs/${file}_n${L_cat[0]}_m${L_cat[1]}_seed${seed}_cmax${L_cat[3]}_cmin${L_cat[2]}.txt" >> script.sh
    done

done

for seed in 1 2 3
do
    for file in spgrid
    do
        # echo "src/$file ${SS_cat[0]} ${SS_cat[1]} $seed -il${SS_cat[3]} -im${SS_cat[2]}  > inputs/${file}_n${SS_cat[0]}_m${SS_cat[1]}_seed${seed}_cmax${SS_cat[3]}_cmin${SS_cat[2]}.txt" >> script.sh
        echo "src/$file ${S_cat[0]} ${S_cat[1]} $seed -il${S_cat[3]} -im${S_cat[2]}  > inputs/${file}_n${S_cat[0]}_m${S_cat[1]}_seed${seed}_cmax${S_cat[3]}_cmin${S_cat[2]}.txt" >> script.sh
        echo "src/$file ${L_cat[0]} ${L_cat[1]} $seed -il${L_cat[3]} -im${L_cat[2]}  > inputs/${file}_n${L_cat[0]}_m${L_cat[1]}_seed${seed}_cmax${L_cat[3]}_cmin${L_cat[2]}.txt" >> script.sh
    done

done
