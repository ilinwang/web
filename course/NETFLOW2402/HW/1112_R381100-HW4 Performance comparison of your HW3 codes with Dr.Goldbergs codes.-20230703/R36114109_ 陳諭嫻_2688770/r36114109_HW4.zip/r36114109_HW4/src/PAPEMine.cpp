/*
    This code can be compiled/ can not be run okay.

    This code is to read a network file and to let the users input the nodes they want to do 
    the bellmand-ford PAPE implementation.

    usage:
        PAPEMine.cpp xxx
        where xxx is the input network filename, e.g. test1.sp

    input file:
        test1.sp
        test2.sp

    compile:
        g++ PAPEMine.cpp -o PAPEMine

    pseudocode:
        struct Arc tail, head, length
        ----- Read file
        ifstream ifs
        ifs.open(filename)
    
        ifs >> search
        if search == c
            continue
        if search == t
            pn = problem name
        if search == p
            pt = problem type
            n = # nodes
            m = # arcs
        if search == n
            n = # nodes
        if search == a
            Arc arc
            ifs >> arc.tail >> arc.head >> arc.length
            arcs.push_back(arc)
        ----- Forward star
        for i = 0 ~ arcs.size()-1
            forward_star[arcs[i].tail].push_back(arcs[i])

        point.push_back(1)
        for int i = 1 ~ n-1
            point.push_back(point[i-1] + forward_star[i].size())
        ----- User input source node 
        ----- PAPE 
        begin
            d[1]=0 pred[1]=0;
            d[j]=MAX
            LIST=[1];
            while LIST != 0 do
                begin
                    delete i from LIST
                    if d[j] decreaases
                        if d[j]>d[i]+cij
                        d[j]=d[i]+cij
                        pred[j]=i 
                        add j to LIST
                end
        end

    coded by Yu-Shian Chen, ID: r36114109, email: yushian99@gmail.com
    date: 2023.05.02
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <string>
#include <tuple>
#include <list>
#include <ctime>

using namespace std;

struct Arc{
    int tail, head;
    double length;
};

priority_queue<vector<int>, vector<vector<int> >, greater<vector<int> > > pq;
vector<int> Tpq;

const int MAX = 10001; 

clock_t my_timer;

int arcIndex;
int pointIndex;
int **graph; 
int *point; 
int C = 0;

void readFile(string filename) {
    ifstream ifs;
    ifs.open(filename);

    while (ifs.fail()) {
        cout << "Input file failed\n";
        cout << "Please input network filename: ";
        cin >> filename;
        ifs.open(filename);
    }

    vector<Arc> arcs;
    // vector<int> arcIndex(0);

    string sall;
    string search; // the first letter for searching
    string pn;     // problem name
    string pt; // problem type
    int n; // # nodes
    int m; // # arcs
    int p=0; // arc index

    while (getline(ifs, sall)) {
        ifs >> search;
        // if the first letter is c, ignore
        if (search != "c") {
            if (search == "t") { // if the first letter is t, save the problem name as pn
                ifs >> pn;       // save the problem name as pn
                // cout << pn;
            }

            // if the first letter is p,
            if (search == "p") {
                ifs >> pt >> n >> m; // save the problem type as pt, get the # nodes as n and # arcs as m
                // cout << pt;
                point = new int[n+1];
                graph = new int*[m];
                arcIndex = 0;
                pointIndex = 0;
                Tpq.resize(3);
            }

            // if the first letter is n,
            if (search == "n") {
                ifs >> n; // save the # nodes as n
                // cout << n;
            }

            // if the first letter is a,
            if (search == "a") {
                Arc arc;
                // ifs >> arc.tail >> arc.head >> arc.length;
                ifs >> Tpq[0] >> Tpq[1] >> Tpq[2];
                pq.push(Tpq);
                // arcs.push_back(arc);
                // p += 1;
                // arcIndex.push_back(p);
            }
        }
    }

    while (!pq.empty()){
        graph[arcIndex] = new int[3];
        auto now = pq.top();
        pq.pop();
        graph[arcIndex][0] = now[0];
        graph[arcIndex][1] = now[1];
        graph[arcIndex][2] = now[2];

        for(int i = pointIndex; i<graph[arcIndex][0]; i++){
            point[i] = arcIndex;
        }
        pointIndex = graph[arcIndex][0];

        if(graph[arcIndex][2] > C){ 
            C = graph[arcIndex][2];
        }
        arcIndex++;
    }

    for(int i = graph[m-1][0]; i <= n;i++){
        point[i] = m;
    }

    ifs.close();
    return;
}

// build forward star

vector<vector<Arc> > buildFS(int n, vector<Arc> arcs){
    vector<vector<Arc> > forward_star(n + 1); // # nodes, +1 since it's more convenient to see what node
    for (int i = 0; i < arcs.size(); i++) { // store the arc info into forward_star
        forward_star[arcs[i].tail].push_back(arcs[i]);
    }
    return forward_star;
}



int *dist; //distance label
int *pred; //predecessor
int n;
int source_node;

struct Node {
    int node_id, distance;
};

bool operator<(const Node& a, const Node& b) {
    return a.distance > b.distance;
}

list<int> LIST; 
void PAPE(){
    dist = new int[n];
    pred = new int[n];
    LIST.clear();
    for(int i= 0 ; i<n ;i++){
        dist[i] = MAX;      
        pred[i] = 0;    
    }
    dist[source_node-1] = 0;
    LIST.push_back(source_node);
    int delete_node = 0;

    while(!LIST.empty()){
        delete_node = LIST.front();
        LIST.pop_front();
        for (int i = point[delete_node-1]; i<point[delete_node]; i++){
            if(dist[graph[i][1]-1] > dist[delete_node-1] + graph[i][2]){
                if(dist[graph[i][1]-1] == MAX)
                    LIST.push_back(graph[i][1]);
                else
                    LIST.push_front(graph[i][1]);
                dist[graph[i][1]-1] = dist[delete_node-1] + graph[i][2];
                pred[graph[i][1]-1] = delete_node;
            }
        }
    }

    return;
}

// void bf_FIFO(vector<vector<Arc> > & forward_star, int start_node) {
//     int num_nodes = forward_star.size() - 1; 
//     vector<int> distance(num_nodes + 2, INT_MAX); 
//     distance[start_node] = 0;

//     queue<Node> q;
//     vector<bool> in_queue(num_nodes + 1, false); 
//     q.push({start_node, 0});
//     in_queue[start_node] = true;

//     while (!q.empty()) {
//         Node cur_node = q.front();
//         q.pop();
//         in_queue[cur_node.node_id] = false;

//         for (int i = 0; i < forward_star[cur_node.node_id].size(); i++) {
//             int next_node = forward_star[cur_node.node_id][i].head;
//             int edge_weight = forward_star[cur_node.node_id][i].length;

//             if (distance[cur_node.node_id] + edge_weight < distance[next_node]) {
//                 distance[next_node] = distance[cur_node.node_id] + edge_weight;

//                 if (!in_queue[next_node]) {
//                     q.push({next_node, distance[next_node]});
//                     in_queue[next_node] = true;
//                 }
//             }
//         }
//     }

//     return;
// }



// the main function
int main() {
    vector<Arc> arcs;
    vector<int> arcIndex;
    string pn;     // problem name
    string pt; // problem type
    int n; // # nodes
    int m;

    cout << "Please input network filename: "; // ask users to input files
    char filename[100];
    cin >> filename;

    readFile(filename);

    cout << pn << " " << pt << " " << n << " " << m;

    cout << arcs[0].length;
    
    vector<vector<Arc> > forward_star = buildFS(n, arcs);

    // for (int i = 1; i <= n; i++) {
    //     for (int j = 0; j < forward_star[i].size(); j++) {
    //         cout << "Tail: " << forward_star[i][j].tail << ", Head: " << forward_star[i][j].head << ", Length: " << forward_star[i][j].length << endl;
    //     }
    // }

    // user input source and sink nodes
    int source_node, sink_node;
    cout << "Please input a source node: ";
    cin >> source_node;

    clock_t start_time = clock();

    PAPE();

    clock_t end_time = clock(); 

    double t = double(end_time - start_time) / CLOCKS_PER_SEC;

    int AllDist = 0;
    for (int i = 1; i<=n; i++){
        if(i != source_node){
            cout<< source_node <<"->"<<i<<": ";

            if(pred[i-1] == 0){
                cout<< "[can not reach]"<<endl;
            }
            else{
                cout<<"["<<dist[i-1]<<"] "<< i <<"<-";
                AllDist = AllDist + dist[i-1];
                int pass_node = i ;
                while(pred[pass_node-1] != source_node){
                    cout<< pred[pass_node-1] << "<-";
                    pass_node = pred[pass_node-1];
                }
                cout<<source_node<<endl;
            }
        }
    }

    cout << AllDist << " " << t;

    return 0;
}
