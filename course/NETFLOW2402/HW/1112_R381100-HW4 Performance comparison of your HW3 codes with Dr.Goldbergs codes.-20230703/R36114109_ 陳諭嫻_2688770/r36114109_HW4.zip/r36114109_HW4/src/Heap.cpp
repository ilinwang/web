/*
    This code can be compiled/ can not be run okay.

    This code is to read a network file and to let the users input the nodes they want to do 
    the Dijkstra's binary heap/ Dijkstra's Dial's implementation.

    usage:
        Heap.cpp xxx
        where xxx is the input network filename, e.g. test1.sp

    input file:
        test1.sp
        test2.sp

    compile:
        g++ Heap.cpp -o Heap

    pseudocode:
        struct Arc tail, head, length
        struct Node distance, label
        ----- Read file
        ifstream ifs
        ifs.open(filename)
    
        ifs >> search
        if search == c
            continue
        if search == t
            pn = problem name
        if search == p
            pt = problem type
            n = # nodes
            m = # arcs
        if search == n
            n = # nodes
        if search == a
            Arc arc
            ifs >> arc.tail >> arc.head >> arc.length
            arcs.push_back(arc)
        ----- Forward star
        for i = 0 ~ arcs.size()-1
            forward_star[arcs[i].tail].push_back(arcs[i])

        point.push_back(1)
        for int i = 1 ~ n-1
            point.push_back(point[i-1] + forward_star[i].size())
        ----- User input source node 
        ----- min heap 
        begin
            create-heap(H);   
            d(j) = inf for j Î N; d(s): = 0 and pred(s): = 0; 
            insert(s,H);
            while H != empty do
            begin
                find-min(i,H);
                delete-min(i,H);  
                for each(i,j) in A(i) do 
                begin
                    temp = d(i) + cij;
                    if d(j) > temp then
                        if d(j) = inf then insert(j,H);
                        else decrease - key(temp, i, H);
                        d(j) = d(i) + cij, pred(j) : = i, 
                end
            end
        end

    coded by Yu-Shian Chen, ID: r36114109, email: yushian99@gmail.com
    date: 2023.04.06
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <string>
#include <cstring>
#include <sstream>
#include <climits>
#include <limits>
#include <cmath>
#include <algorithm>
#include <map>

using namespace std;

struct Arc{
    int tail, head;
    double length;
    int dest;
    int index;
};

struct Node{
    vector<Arc> arcs;
    double distance;
    int label;
    int index;
};

const int MAX = 10001; 

vector<pair<int, int> > adj[MAX]; // adj[i] 儲存與節點 i 相鄰的節點及邊長
int dist[MAX]; // 儲存從起點到各節點的最短路徑長度
bool vis[MAX]; // if visited

vector<int> heap;

void minHeap(int m){
    int left = 2 * m;
    int right = 2 * m + 1;
    int min;

    if (left <= heap.size() && heap[left] < heap[m])
        min = left;
    else
        min = m;
    if (right < heap.size() && heap[right] < heap[min])
        min = right;
    if (min != m){
        swap(heap[m],heap[min]);
        // heap[min] = heap[m];
        minHeap(min);
    }
}

void buildMinHeap(){
    int height = floor(heap.size()/2)-1;
    for (int i = height; i > -1; i --)
        minHeap(i);
}

int findMin() {
    return heap[0];
}

int deleteMin() {
    int minH = heap[0]; // Remove the root
    int m = heap.size();
    m--;
    heap[0] = heap[m];

    minHeap(0); // restore the heap by heapifying the new root 

    heap.pop_back();

    return minH;
}

void dijkstra(int source){
    heap.push_back(source); // 將起點加入堆中
    dist[source] = 0; // 起點到自己的距離為 0
    buildMinHeap(); // 建堆

    while (!heap.empty()) {
        int u = deleteMin(); // 取出堆中距離最小的節點 u
        vis[u] = true; // 標記 u 為已走過

        for (int i = 0; i < adj[u].size(); i++) {
            int v = adj[u][i].first; // 取得與 u 相鄰的節點 v
            int weight = adj[u][i].second; // 取得 u 到 v 的邊長

            if (!vis[v] && dist[u] + weight < dist[v]) {
                // 若 v 未被走過且從起點到 u 再到 v 的路徑更短，更新 dist[v]
                dist[v] = dist[u] + weight;
                heap.push_back(v); // 將 v 加入堆中
            }
        }

        buildMinHeap(); // 重新建堆
    }
}

vector<Node> graph;
const int INF = numeric_limits<int>::max();


// the main function
int main() {
    cout << "Please input network filename: "; // ask users to input files
    char filename[100];
    cin >> filename;

    ifstream ifs;
    ifs.open(filename);

    while (ifs.fail()){
        cout << "Input file failed\n";
        cout << "Please input network filename: ";
        cin >> filename;
        ifs.open(filename);
    }

    vector<string> T; // t: title of the problem_name
    vector<string> P; // p: problem type(sp), n (# nodes), m (# arcs)

    vector<Arc> arcs;

    string sall;
    string search; // the first letter for searching
    string pn;     // problem name

    string pt; // problem type
    int n = 0; // # nodes
    int m = 0; // # arcs
    int p = 0; // arc index


    vector<int> arcIndex;
    for (int i = 0; i < m; i ++){
        arcIndex[i] = 0;
    }
    

    while (getline(ifs, sall)){
        ifs >> search;
        // if the first letter is c, ignore
        if (search != "c"){ 
            if (search == "t"){ // if the first letter is t, save the problem name as pn
                ifs >> pn; // save the problem name as pn
                T.push_back(pn);
            }

            // if the first letter is p,
            if (search == "p"){  
                ifs >> pt >> n >> m; // save the problem type as pt, get the # nodes as n and # arcs as m
                P.push_back(pt);
            }

            // if the first letter is n, 
            if (search == "n"){ 
                ifs >> n; // save the # nodes as n
            }

            // if the first letter is a, 
            if (search == "a"){
                Arc arc;
                ifs >> arc.tail >> arc.head >> arc.length;
                arcs.push_back(arc);
                p += 1;
                arcIndex.push_back(p);
            }
        }
    }
    ifs.close();

   

    for (int i = 0; i < m; i ++){
        cout << arcIndex[i];
    }


    // build forward star
    vector<vector<Arc> > forward_star(n + 1); // # nodes, +1 since it's more convenient to see what node

    for (int i = 0; i < arcs.size(); i++){ // store the arc info into forward_star
        forward_star[arcs[i].tail].push_back(arcs[i]);
        // cout << forward_star[i][1].head;
    }

    vector<int> point;
    point.push_back(1);
    for (int i = 1; i <n; i ++){
        point.push_back(point[i-1] + forward_star[i].size());
    }

    

    // user input source and sink nodes
    int source_node, sink_node;
    cout << "Please input a source node: ";
    cin >> source_node;
    // cout << "Please input a sink node: ";
    // cin >> sink_node;


    // BFS implement
    vector<int> distance(n + 1, -1);
    vector<int> label(n + 1, -1);
    queue<int> Bqueue; // queue to store nodes in the BFS order

    distance[source_node] = 0;
    label[source_node] = 0;
    Bqueue.push(source_node);

    while (!Bqueue.empty()){
        int f = Bqueue.front();
        for (int i = 0; i < forward_star[f].size(); i++){
            // Arc& arc = forward_star[f][i];
            int h = forward_star[f][i].head; // get the head of the ith arc in the forward_star of f, the front node in queue

            if (label[h] == -1){ // if it's not the source node, update label
                label[h] = label[f] + 1; 
            }

            if (distance[h] == -1){ // if it's not the source node, update distance
                distance[h] = distance[f] + forward_star[f][i].length; 
                Bqueue.push(h); // add head node to the queue
            }
        }
        Bqueue.pop(); // remove the front node from the queue
    }

    vector<int> heap = label;

    dijkstra(source_node);

    // dijkstraDials(source_node, n, heap, arcs, distance);

    for (int i = 0; i < heap.size(); i++) {
        cout << source_node << "->" << heap[i] << ": ";
        if (distance[i] == INT_MAX) {
            cout << "[can not reach]\n";
        } else {
            cout << "[" << distance[i] << "] ";
            int currentNode = heap[i];
            while (currentNode != source_node) {
                // find the parent of the current node
                int parentIndex = -1;
                for (int j = 0; j < heap.size(); j++) {
                    if (heap[j] == currentNode) {
                        parentIndex = (j - 1) / 2;
                        break;
                    }
                }
                if (parentIndex >= 0) {
                    int previousNode = heap[parentIndex];
                    cout << currentNode << "<-" << previousNode;
                    currentNode = previousNode;
                    if (currentNode != source_node) {
                        cout << "<-";
                    }
                } else {
                    // the current node is the source node
                    break;
                }
            }
            cout << "\n";
        }
    }

    return 0;
}