/*
    This code can be compiled and run okay.

    This code is to read a network file and to let the users input the nodes they want to do 
    the Bellman-Ford FIFO implementation.
    You can get the total length of the shortest paths + total run time of this algorithm.

    usage:
        NEWbf.cpp xxx
        where xxx is the input network filename, e.g. input1.txt

    input file:
        input1.txt
        input2.txt
        input3.txt
        inputL1.txt
        inputL2.txt
        inputL3.txt

    compile:
        g++ NEWbf.cpp -o NEWbf

    pseudocode:
        struct Arc tail, head, length
        ----- readFile(filename) 
        ifstream ifs(filename)
        if (type == "p") 
            iss >> problemType >> n >> m
            forward_star.resize(n)
        else if (type == "a") 
            iss >> arc.tail >> arc.head >> arc.length
            arcs.push_back(arc)
        
        ----- build forward star
        for (int i = 0; i < arcs.size(); i++) 
            forward_star[arc.tail].push_back(arc)

        ----- printPath(source, node, predecessor)
        if (node == source) 
            cout << node
            return
        cout << node << "<-"
        printPath(source, predecessor[node], predecessor)

        -----bf(source)
        dist[source] = 0
        Queue.push(source)

        while (!Queue.empty()) 
            u = Queue.front()
            Queue.pop()
            inQueue[u] = false

        for (i = 0 ~ forward_star[u].size()) 
            const Arc& arc = forward_star[u][i]
            int v = arc.head
            double weight = arc.length

            if (dist[u] != INT_MAX && dist[u] + weight < dist[v]) 
                dist[v] = dist[u] + weight
                if (!inQueue[v]) 
                    Queue.push(v)
                    inQueue[v] = true

    coded by Yu-Shian Chen, ID: r36114109, email: yushian99@gmail.com
    date: 2023.04.28
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <string>
#include <sstream>
#include <climits>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <map>
#include <chrono>

using namespace std;

struct Arc {
    int tail, head;
    double length;
};

const int MAX = 10000;

vector<vector<Arc> > forward_star(MAX);
vector<int> dist(MAX, INT_MAX); // for the shortest distances
queue<int> Queue; // for bf
vector<Arc> arcs;

void bf(int source) {
    vector<bool> inQueue(MAX, false);
    dist[source] = 0;
    Queue.push(source);
    inQueue[source] = true;
    
    while (!Queue.empty()) {
        int u = Queue.front();
        Queue.pop();
        inQueue[u] = false;

        for (int i = 0; i < forward_star[u].size(); i++) {
            const Arc& arc = forward_star[u][i];
            int v = arc.head;
            double weight = arc.length;

            if (dist[u] != INT_MAX && dist[u] + weight < dist[v]) {
                dist[v] = dist[u] + weight;
                if (!inQueue[v]) {
                    Queue.push(v);
                    inQueue[v] = true;
                }
            }
        }
    }
}

void readFile(const string& filename) {
    ifstream ifs(filename);
    while (ifs.fail()) {
        cout << "Input file failed\n";
        cout << "Please input network filename: ";
        string input;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');  // clear input buffer
        getline(cin, input);
        ifs.open(input);
    }

    string line;
    int n = 0, m = 0;

    while (getline(ifs, line)) {
        istringstream iss(line);
        string type;
        iss >> type;

        if (type == "p") {
            string problemType;
            iss >> problemType >> n >> m;
            forward_star.resize(n + 1); // resize forward star
        } else if (type == "a") {
            Arc arc;
            iss >> arc.tail >> arc.head >> arc.length; // sort them into the structure arc 
            arcs.push_back(arc);
        }
    }

    for (int i = 0; i < arcs.size(); i++) {
        const Arc& arc = arcs[i];
        forward_star[arc.tail].push_back(arc); // build forward star
    }
}

int main() {
    string filename;
    cout << "Please input network filename: ";
    cin >> filename;

    readFile(filename);

    int source_node;
    cout << "Please input a source node: ";
    cin >> source_node;

    auto start = chrono::high_resolution_clock::now(); // get the time before doing bf

    bf(source_node);

    auto end = chrono::high_resolution_clock::now(); // get the time after doing bf

    chrono::duration<double> runtime = end - start; // get the time bf spent 

    cout << "Total time: " << runtime.count() << " seconds\n";
    
    int total = 0;
    for (int i = 1; i <= forward_star.size(); i++) {
        // cout << source_node << " -> " << i << ": ";
        if (dist[i] == INT_MAX) {
            // cout << "[cannot reach]\n";
        } else {
            // cout << "[" << dist[i] << "]\n";
            total += dist[i];
        }
    }
    cout << "Total: " << total << "\n";

    return 0;
}
