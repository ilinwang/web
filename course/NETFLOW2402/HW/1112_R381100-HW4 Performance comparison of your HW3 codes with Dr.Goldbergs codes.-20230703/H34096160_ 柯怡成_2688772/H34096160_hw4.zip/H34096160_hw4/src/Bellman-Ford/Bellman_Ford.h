#ifndef BELLMAN_FORD_H_INCLUDED
#define BELLMAN_FORD_H_INCLUDED

void tripal_comparison(int tail, int *pointForward, double **network, int *distance, queue Q){

}

#endif // BELLMAN_FORD_H_INCLUDED
