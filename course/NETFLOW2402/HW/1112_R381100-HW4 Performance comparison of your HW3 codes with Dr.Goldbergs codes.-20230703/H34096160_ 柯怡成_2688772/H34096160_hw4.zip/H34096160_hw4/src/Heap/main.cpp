/*
Purpose: Find the shortest path from the original node s to all other points
Method: directly execute the exe file or compile main.cpp, and execute the compiled execution file.
Input: SP file name, test node
Output: total distances (sum of all points' paths) and execute time.
Compilation: Compile main.cpp directly, such as: g++ -o hw4.exe main.cpp
Pseudocode: as shown below
the code can run
Mason Ke Finished 2323/04/24 14:38
*/
/*psuedocode
Read file and save with Forward star
read the original node s
Do While the data structure is not empty
    Obtain the minimum node and distance of the data structure (see the corresponding function in the .h file)
    If the node is unmarked (distance equals -1)
        Add the node and distance to the data structure
        pred is set to the current searched point
    ElseIf the distance of the data structure is greater than the value currently calculated
        relabel the distance
        pred is set to the current searched point
    End If
Loop
For all nodes (except the original node)
    If its distance is not M
        Add the distance
    End If
Next
*/
#include <iostream>
#include <ctime>
#include "DijkstraHeap.h"
#include "Read_SP_Forward_Reverse_Star.h"

using namespace std;

int main()
{
    int n, m, *pointForward, *pointReverse, s;
    double **network, **ptrReverse;
    string fileName, problemName, problemType;
    // try to open file and initialize the variable above
    while(!Initialization (pointForward, pointReverse, network, fileName, problemName, problemType, n, m)){ }
    Store_Forward_Star (pointForward, network, fileName, n);

    // input data
    cout << "Please input a source node: ";
    cin >> s;

    int t_start = clock(), t_end;// get the time start
    // declare variable
    int* pred = new int[n+1];
    Heap* P = new Heap(n);
    // initialization
    for (int i = 0; i <= n; i++){ pred[i] = -1; }
    P->addNode(s, 0);
    pred[s] = 0;

    while (!P->is_NULL()){ // As long as the data structure is not empty (there is still a point in the component)
        // Get the node with the shortest distance
        int return_value[2];
        P->Get_root_node(return_value);
        int head_node;
        int ctr = pointForward[return_value[0]];
        while (ctr != pointForward[return_value[0] + 1]){ // If the node still has outgoing arc
            // set up head_node and distance
            head_node = network[ctr][1];
            int distance = network[ctr][2] + return_value[1];
            if (P->Get_distance(head_node) == -1) { // if it is unlabel, label it
                P->addNode(head_node, distance);
                pred[head_node] = return_value[0];
            }
            else if (distance < P->Get_distance(head_node)) { // if its label is larger than distance, relable it
                P->Relabel(head_node, distance);
                pred[head_node] = return_value[0];
            }
            ctr++;
        }
    }
    int Total_distance = 0;
    for (int i = 1; i <= n; i++){ // Sum the total distancce
        Total_distance += P->Get_correct_distance(i);
    }

    t_end = clock(); // get the time end

    cout << Total_distance << "\t" << (t_end - t_start)/1000.0;// output distance and time(second)
    return 0;
}
