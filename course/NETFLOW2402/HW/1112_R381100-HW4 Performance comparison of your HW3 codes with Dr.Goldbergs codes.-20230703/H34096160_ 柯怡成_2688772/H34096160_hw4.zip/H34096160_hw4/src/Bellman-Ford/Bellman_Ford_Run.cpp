/*
Purpose: Find the shortest path from the original node s to all other points
Method: directly execute the exe file or compile Bellman_Ford_Run.cpp, and execute the compiled execution file.
Input: SP file name, test node
Output: total distances (sum of all points' paths) and execute time.
Compilation: Compile Bellman_Ford_Run.cpp directly, such as: g++ -o hw4.exe Bellman_Ford_Run.cpp
Pseudocode: as shown below
the code can run
Mason Ke Finished 2323/04/24 15:09
*/
/*psuedocode
Read file and save with Forward star
read the original node s
Do While the queue is not empty
    Get the front node in queue
    Do while the tail of arc is still the front node
        If distance of head is larger than distance of tail + cost of arc(tail, head) i.e. triple compare
            set distance of head <- larger than distance of tail + cost of arc(tail, head)
            set predecessor of head <- tail
            push head into queue
        End If
    Loop
Loop
For all nodes (except the original node)
    If its distance is not BIG_M
        Add the distance
    End If
Next
*/
#include <iostream>
#include <queue>
#include <ctime>
#include "Read_SP_Forward_Reverse_Star.h"

using namespace std;

int main()
{
    int n, m, *pointForward, *pointReverse, s;
    double **network, **ptrReverse;
    string fileName, problemName, problemType;
    // try to open file and initialize the variable above
    while(!Initialization (pointForward, pointReverse, network, fileName, problemName, problemType, n, m)){ }
    Store_Forward_Star (pointForward, network, fileName, n);

    // input data
    cout << "Please input a source node: ";
    cin >> s;

    // set variable to make code more readable
    const int BIG_M = 10000000;
    const int No_Pred = -1;
    int t_start = clock(), t_end; // get the time start
    int *distance = new int[n+1], *pred = new int[n+1]; // declare two array to store all distance/predecessor
    for (int i = 1; i <= n; i++){ // initialize distance and pred
        distance[i] = BIG_M;
        pred[i] = No_Pred;
    }
    // let s be sorce
    distance[s] = 0;
    queue<int> Q;
    Q.push(s);

    while (Q.empty() == false){ // while there are still some node need to check
        int tail = Q.front(); // Get an point
        Q.pop(); // pop what we got from queue
        int temp = pointForward[tail]; // get the arcs we need

        while (temp != pointForward[tail+1]){ // while arc still from tail
            int head = network[temp][1];
            if (distance[head] > distance[tail] + network[temp][2]){ // triple compare
                distance[head] = distance[tail] + network[temp][2];
                pred[head] = tail;
                Q.push(head); // push the node we modified
            }
            temp++; // change to next arc
        }
    }

    int Total_distance = 0;
    for (int i = 1; i <= n; i++){ // Sum all distance
        if (distance[i] != BIG_M) // if it can be reached
            Total_distance += distance[i];
    }
    t_end = clock(); // get the time end

    cout << Total_distance << "\t" << (t_end - t_start)/1000.0; // output distance and time(second)

    return 0;
}
