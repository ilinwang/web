/*
Purpose: Find the shortest path from the original node s to all other points
Method: directly execute the exe file or compile main.cpp, and execute the compiled execution file.
Input: SP file name, test node
Output: total distances (sum of all points' paths) and execute time.
Compilation: Compile main.cpp directly, such as: g++ -o hw4.exe main.cpp
Pseudocode: as shown below
the code can run
Mason Ke Finished 2323/04/24 15:16
*/
/*psuedocode
Read file and save with Forward star
read the original node s
Do While the data structure is not empty
    Obtain the minimum node and distance of the data structure (see the corresponding function in the .h file)
    If the node is unmarked (distance equals -1)
        Add the node and distance to the data structure
        pred is set to the current searched point
    ElseIf the distance of the data structure is greater than the value currently calculated
        relabel the distance
        pred is set to the current searched point
    End If
Loop
For all nodes (except the original node)
    If its distance is not M
        Add the distance
    End If
Next
*/
#include <iostream>
#include <ctime>
#include "DijkstraDial.h"
#include "Read_SP_Forward_Reverse_Star.h"

using namespace std;

int main()
{
    int n, m, *pointForward, *pointReverse, s;
    double **network, **ptrReverse;
    string fileName, problemName, problemType,y;
    // try to open file and initialize the variable above
    while(!Initialization (pointForward, pointReverse, network, fileName, problemName, problemType, n, m)){ }

    Store_Forward_Star (pointForward, network, fileName, n);

    // input data
    cout << "Please input a source node: ";
    cin >> s;

    int t_start = clock(), t_end; // get the time start
    // declare variable
    int C = 0;
    int* Distance = new int[n+1];
    int* pred = new int[n+1];
    // initialization
    for (int i = 1; i <= m; i++) { C = (network[i][2] < C? C: network[i][2]); }
    Dial* P = new Dial(n, C, s);
    for (int i = 0; i <= n; i++){
        pred[i] = -1;
        Distance[i] = 10000000;
    }
    // source node
    pred[s] = 0;
    Distance[s] = 0;
    // Get the node with the shortest distance(source node)
    Linklist* temp = P->Find_Next();
    //cout << 1;
    while (temp->node != -1){ // As long as the data structure is not empty (there is still a point in the component)
        // declare variable
        int node_now = temp->node, head_node;
        int ctr = pointForward[node_now];
        while (ctr != pointForward[node_now + 1] && ctr <= m){ // If the node still has outgoing arc
            head_node = network[ctr][1];
            int diatance = network[ctr][2] + Distance[node_now];
            if (Distance[head_node] == 10000000) { // if it is unlabel, label it
                P->Relabel(head_node, -1, diatance);
                pred[head_node] = node_now;
                Distance[head_node] = diatance;
            }
            else if (diatance < Distance[head_node]) { // if its label is larger than distance, relable it


                P->Relabel(head_node, Distance[head_node], diatance);
                pred[head_node] = node_now;
                Distance[head_node] = diatance;
            }
            ctr++;
        }
        temp = P->Find_Next();
    }

    int total_distance = 0;
    for (int i = 1; i <= n; i++){ // for all nodes
        if (Distance[i] != 10000000)
            total_distance += Distance[i];
    }
    t_end = clock(); // get the time end

    cout << total_distance << "\t" << (t_end - t_start)/1000.0; // output distance and time(second)

    return 0;
}
