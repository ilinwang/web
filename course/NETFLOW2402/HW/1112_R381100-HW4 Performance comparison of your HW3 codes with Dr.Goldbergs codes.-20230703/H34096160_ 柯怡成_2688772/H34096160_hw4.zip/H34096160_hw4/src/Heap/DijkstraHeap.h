#ifndef DIJKSTRAHEAP_H_INCLUDED
#define DIJKSTRAHEAP_H_INCLUDED

using namespace std;

class Heap{
public:
    Heap(int n):n(n){ // initialization
        Store_Place = new int[n+2];
        nodes = new int[n+2];
        distance = new int[n+2];
        correct_distance = new int[n+1];
        for (int i = 0; i <= n; i++){
            Store_Place[i] = 0;
            nodes[i] = -1;
            distance[i] = 1000000;
            correct_distance[i] = -1;
        }
        // relabel of particular place
        distance[0] = -1;
        distance[n+1] = 0;
    }
    bool is_NULL(){ return (nodes[1] == -1? 1 : 0); } // check if the heap is NULL
    int Get_distance(int node){ return distance[Store_Place[node]]; } // get function
    int Get_correct_distance(int node){ return correct_distance[node]; } // get function
    void Get_root_node(int *return_value){ // get root node and distance, pop it, and resort it
        // get return value
        return_value[0] = nodes[1];
        return_value[1] = distance[1];
        // let heap root in distance after selected
        correct_distance[nodes[1]] = distance[1];
        // reset index of root and final value in heap
        Store_Place[nodes[1]] = n+1;
        Store_Place[nodes[nodes_in_heap]] = 1;
        // let final value in heap be root
        nodes[1] = nodes[nodes_in_heap];
        distance[1] = distance[nodes_in_heap];
        // reset origin final value in heap
        nodes[nodes_in_heap] = -1;
        distance[nodes_in_heap] = 1000000;
        // resort
        int ctr = 1;
        while (distance[ctr] > distance[2*ctr] || distance[ctr] > distance[2*ctr+1]){ // while parent smaller than any one of child
            if (distance[2*ctr] < distance[2*ctr+1]){ // if leftchild smaller, swap parent and leftchild
                Store_Place[nodes[ctr]] = Store_Place[nodes[ctr]] + Store_Place[nodes[2*ctr]];
                Store_Place[nodes[2*ctr]] = Store_Place[nodes[ctr]] - Store_Place[nodes[2*ctr]];
                Store_Place[nodes[ctr]] = Store_Place[nodes[ctr]] - Store_Place[nodes[2*ctr]];
                nodes[ctr] = nodes[ctr] + nodes[2*ctr];
                nodes[2*ctr] = nodes[ctr] - nodes[2*ctr];
                nodes[ctr] = nodes[ctr] - nodes[2*ctr];
                distance[ctr] = distance[ctr] + distance[2*ctr];
                distance[2*ctr] = distance[ctr] - distance[2*ctr];
                distance[ctr] = distance[ctr] - distance[2*ctr];
                ctr = ctr*2;
            }
            else{ // if rightchild smaller, swap parent and rightchild
                Store_Place[nodes[ctr]] = Store_Place[nodes[ctr]] + Store_Place[nodes[2*ctr+1]];
                Store_Place[nodes[2*ctr+1]] = Store_Place[nodes[ctr]] - Store_Place[nodes[2*ctr+1]];
                Store_Place[nodes[ctr]] = Store_Place[nodes[ctr]] - Store_Place[nodes[2*ctr+1]];
                nodes[ctr] = nodes[ctr] + nodes[2*ctr+1];
                nodes[2*ctr+1] = nodes[ctr] - nodes[2*ctr+1];
                nodes[ctr] = nodes[ctr] - nodes[2*ctr+1];
                distance[ctr] = distance[ctr] + distance[2*ctr+1];
                distance[2*ctr+1] = distance[ctr] - distance[2*ctr+1];
                distance[ctr] = distance[ctr] - distance[2*ctr+1];
                ctr = ctr*2+1;
            }
            // if is larger than final one, break
            if ((ctr * 2) > nodes_in_heap){ break; }
        }
        nodes_in_heap--;
    }
    void Relabel(int node, int new_label){
        distance[Store_Place[node]] = new_label; // set label as new label
        upperresort(Store_Place[node]); // choose the place it should be
    }
    void addNode(int node, int label){
        Store_Place[node] = ++nodes_in_heap; // give this node an index
        nodes[nodes_in_heap] = node; // Add node at the end of valid value of nodes
        distance[nodes_in_heap] = label; // Add label at the end of valid value of distance
        upperresort(nodes_in_heap); // choose the place it should be
    }
private:
    int n, nodes_in_heap = 0, selected = 0;
    int *Store_Place; // index of nodes' place in heap
    int *nodes; // nodes in heap
    int *distance; // distance in heap
    int *correct_distance; // distance after selected

    void upperresort(int ctr){
        //int ctr = nodes_in_heap;
        while (distance[ctr] < distance[ctr/2]){ // if the distance smaller than its parent
            // swap the record of index of nodes[ctr] and nodes[ctr]
            Store_Place[nodes[ctr]] = Store_Place[nodes[ctr]] + Store_Place[nodes[ctr/2]];
            Store_Place[nodes[ctr/2]] = Store_Place[nodes[ctr]] - Store_Place[nodes[ctr/2]];
            Store_Place[nodes[ctr]] = Store_Place[nodes[ctr]] - Store_Place[nodes[ctr/2]];
            // swap the record of nodes of ctr and ctr/2
            nodes[ctr] = nodes[ctr] + nodes[ctr/2];
            nodes[ctr/2] = nodes[ctr] - nodes[ctr/2];
            nodes[ctr] = nodes[ctr] - nodes[ctr/2];
            // swap the record of distance of ctr and ctr/2
            distance[ctr] = distance[ctr] + distance[ctr/2];
            distance[ctr/2] = distance[ctr] - distance[ctr/2];
            distance[ctr] = distance[ctr] - distance[ctr/2];
            ctr = ctr/2;
        }
    }
};

#endif // DIJKSTRAHEAP_H_INCLUDED
