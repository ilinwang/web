#ifndef DIJKSTRADIAL_H_INCLUDED
#define DIJKSTRADIAL_H_INCLUDED

using namespace std;

struct Linklist{ // declare node -> node and next
    Linklist(int node):node(node){}
    int node;
    Linklist* next = NULL;
};

class Dial{
public:
    Dial(int n, int C,int s)
        :n(n), C(C){ // initialization
        Buckets = new Linklist*[C+1];
        for (int i = 0; i < C + 1; i++){
            Buckets[i] = NULL;
        }
        // source node
        Buckets[0] = new Linklist(s);
    }
    Linklist* Find_Next(){ // get the node have smallest distance, and delete it
        int counter = 0;
        while(Buckets[finding_distance] == NULL){ // check bucket until there is/are value(s) in it
            finding_distance++;
            finding_distance = finding_distance % (C+1);
            if (counter++ > C + 1){ // if number of bucket larger than nC, return -1
                return new Linklist(-1);
            }
        }
        // when found, pop the first value in the bucket, and return the first value
        Linklist *temp =  Buckets[finding_distance];
        Buckets[finding_distance] = temp->next;
        return temp;
    }
    void Relabel(int node, int original_label, int new_label) {
        if (original_label != -1) {
            // relabel
            int oldplace = original_label % (C + 1);
            Linklist* before = Buckets[oldplace], * temp;
            if (before->node == node) { // if original label is the first value
                temp = before;
                Buckets[oldplace] = temp->next;
            }
            else { // else, find original label
                while (before->next != nullptr && before->next->node != node) {
                    before = before->next;
                }
                if (before->next == nullptr) {
                    return; // node not found
                }
                temp = before->next;
                before->next = temp->next;
            }
            //let the label in the bucket of new label
            temp->next = Buckets[new_label % (C + 1)];
            Buckets[new_label % (C + 1)] = temp;
        }
        else {
            // add node at the first in the bucket
            Linklist* new_node = new Linklist(node);
            if (Buckets[new_label % (C + 1)] == nullptr) {
                Buckets[new_label % (C + 1)] = new_node;
            }
            else {
                new_node->next = Buckets[new_label % (C + 1)];
                Buckets[new_label % (C + 1)] = new_node;
            }
        }
    }
private:
    int n;
    int C;
    int finding_distance = 0;
    Linklist** Buckets;
};

#endif // DIJKSTRADIAL_H_INCLUDED
