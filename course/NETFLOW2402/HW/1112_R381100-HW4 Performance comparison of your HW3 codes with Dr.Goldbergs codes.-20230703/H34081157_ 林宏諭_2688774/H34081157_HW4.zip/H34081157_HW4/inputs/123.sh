#echo "bf\t" >> ../results/results.txt
../bin/sprand 200 4000 1 -ll10000 -lm100 | ../bin/$1 >>../results/$1-1.txt
../bin/sprand 200 4000 2 -ll10000 -lm100 | ../bin/$1 >>../results/$1-2.txt
../bin/sprand 200 4000 3 -ll10000 -lm100 | ../bin/$1 >>../results/$1-3.txt
../bin/sprand 2000 12000 1 -ll100 -lm10 | ../bin/$1 >>../results/$1-4.txt
../bin/sprand 2000 12000 2 -ll100 -lm10 | ../bin/$1 >>../results/$1-5.txt
../bin/sprand 2000 12000 3 -ll100 -lm10 | ../bin/$1 >>../results/$1-6.txt
#
#echo "bfp\t" >> ../results/results.txt
../bin/sprand 200 4000 1 -ll10000 -lm100 | ../bin/$1 >>../results/$1-1.txt
../bin/sprand 200 4000 2 -ll10000 -lm100 | ../bin/$1 >>../results/$1-2.txt
../bin/sprand 200 4000 3 -ll10000 -lm100 | ../bin/$1 >>../results/$1-3.txt
../bin/sprand 2000 12000 1 -ll100 -lm10 | ../bin/$1 >>../results/$1-4.txt
../bin/sprand 2000 12000 2 -ll100 -lm10 | ../bin/$1 >>../results/$1-5.txt
../bin/sprand 2000 12000 3 -ll100 -lm10 | ../bin/$1 >>../results/$1-6.txt
#
#echo "dikb\t" >> ../results/results.txt
../bin/sprand 200 4000 1 -ll10000 -lm100 | ../bin/$2 >>../results/$2-1.txt
../bin/sprand 200 4000 2 -ll10000 -lm100 | ../bin/$2 >>../results/$2-2.txt
../bin/sprand 200 4000 3 -ll10000 -lm100 | ../bin/$2 >>../results/$2-3.txt
../bin/sprand 2000 12000 1 -ll100 -lm10 | ../bin/$2 >>../results/$2-4.txt
../bin/sprand 2000 12000 2 -ll100 -lm10 | ../bin/$2 >>../results/$2-5.txt
../bin/sprand 2000 12000 3 -ll100 -lm10 | ../bin/$2 >>../results/$2-6.txt

#echo "dikh\t" >> ../results/results.txt
../bin/sprand 200 4000 1 -ll10000 -lm100 | ../bin/$3 >>../results/$3-1.txt
../bin/sprand 200 4000 2 -ll10000 -lm100 | ../bin/$3 >>../results/$3-2.txt
../bin/sprand 200 4000 3 -ll10000 -lm100 | ../bin/$3 >>../results/$3-3.txt
../bin/sprand 2000 12000 1 -ll100 -lm10 | ../bin/$3 >>../results/$3-4.txt
../bin/sprand 2000 12000 2 -ll100 -lm10 | ../bin/$3 >>../results/$3-5.txt
../bin/sprand 2000 12000 3 -ll100 -lm10 | ../bin/$3 >>../results/$3-6.txt
