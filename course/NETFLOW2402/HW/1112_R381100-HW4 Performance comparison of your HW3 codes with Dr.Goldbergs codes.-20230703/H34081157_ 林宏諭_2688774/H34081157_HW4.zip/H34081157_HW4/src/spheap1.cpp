
#include <iostream>
#include <fstream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/times.h>
using namespace std;

struct arc {
    int from,to;
    float length;
};

float mytimer()
{ struct tms hold;
 
 times(&hold);
 /*return  (float)(hold.tms_utime) / 60.0;*/
 return  (float)(hold.tms_utime);
}

struct node {
    int num;
    int pred;
};

int parent(int i)
{
    return (i - 1) / 2;
}
int left(int i)
{
    if(i == 0)
        return 1;
    else
        return 2*i;
}
int right(int i)
{   if(i == 0)
        return 2;
    else
        return 2*i + 1;
}
void min_heapify(vector<int> &A, int i, int heapsize)
{
    int smallest;
    int l = left(i);
    int r = right(i);
    if(l <= heapsize && A[l] < A[i])
        smallest = l;
    else
        smallest = i;
    if(r <= heapsize && A[r] < A[smallest])
        smallest = r;
    if(smallest != i) {
        swap(A[i], A[smallest]);
        min_heapify(A, smallest, heapsize);
    }
}
void build_min_heap(vector<int> &A)
{
    int heapsize = A.size() - 1;
    for(int i = (A.size() - 1) / 2; i >= 0; i--)
        min_heapify(A, i, heapsize);
}
void heapsort(vector<int> &A)
{
    int heapsize = A.size() - 1;
    build_min_heap(A);
    for(int i = A.size() - 1; i > 0; i--) {
        swap(A[0], A[i]);
        heapsize--;
        min_heapify(A, 0, heapsize);
    }
}

//void Update(vector<int> A,int i,int n) {
//    int smallest = 0;
//    int l=(2*i)+1;
//    int r=(2*i)+2;
//    if(l<=(n-1)&&A[l]<A[i])
//        smallest=l;
//    else
//        smallest=i;
//
//    if(r<=(n-1)&&A[r]<A[smallest])
//        smallest=r;
//
//    if(smallest!=i){
//        int temp=A[i];
//        A[i]=A[smallest];
//        A[smallest]=temp;
//
//        Update(A,smallest,n);
//    }
//}

int main(int argc, const char * argv[]) {
    
    int n,m;
    int sink,source;
    string filename;
    ifstream file;
//    cout << "Enter filename, source node: ";
    cin >> filename >> source;
    file.open(filename,ios::in);
    string line,problem;
    arc * matrix;
    
    float t1=0.,t2=0.;
    t1=mytimer();

    int temp_i,temp_j;
    int * point;
    int * count;
    int * d;
    bool * check;
    node * N;
    int a = 1;
    while (getline(file,line)) {
        char head;
        file >> head;
        if (head == 'p') {
            file >> problem >> n >> m;
            matrix = new arc [m+1];
            point = new int [n+1];
            count = new int [n+1];
            check = new bool [n+1];
            d = new int [n+1];
            N = new node [n+1];
            for (int i=1; i<=n+1; i++){
                N[i].num = i;
                N[i].pred = 0;
                d[i] = 10000;
                check[i] = false;
            }
            for (int i=0; i<=n+1; i++)
                count[i] = 0;
        }
        else if (head == 'a') {
            file >> temp_i >> temp_j;
            count[temp_i]++;
            matrix[a].from = temp_i;
            matrix[a].to = temp_j;
            file >> matrix[a].length;
            a++;
        }
    }
    point[1] = 1;
    
    for (int i=2; i<n+1; i++) {
        point[i] = point[i-1] + count[i-1];
    }
    
    vector<int> Heap;
    d[source] = 0;
    Heap.push_back(d[source]);
    int curr;
    while (!Heap.empty()) {
        for (int a=1; a<n+1; ++a) {
            if (d[a] == Heap[0] and check[a] == false) {
                curr = a;
                break;
            }
        }
        Heap.erase(Heap.begin());
        for (int i = point[curr]; i < point[curr+1]; ++i) {
            int value = d[curr] + matrix[i].length;
            if (value < d[matrix[i].to]) {
                if (d[matrix[i].to] == 10000) {
                    d[matrix[i].to] = value;
                    N[matrix[i].to].pred = matrix[i].from;
                    Heap.push_back(d[matrix[i].to]);
                    heapsort(Heap);
                }
                else {
                    int temp_value = d[matrix[i].to];
                    d[matrix[i].to] = value;
                    N[matrix[i].to].pred = matrix[i].from;
                    for(int j=0;j<Heap.size();++j) {
                        if (Heap[j] == temp_value){
                            Heap[j] = value;
                            break;
                        }
                    }
                    heapsort(Heap);
                }
            }
        }
        check[curr] = true;
    }
//    for (int a=1; a<n+1; ++a) {
//        if (a != source) {
//            cout << source << "->" << a << ":[";
//            if (d[a] == 10000) {
//                cout << "can not reach]" << endl;
//            }
//            else {
//                cout << d[a] << "]" << a << "<-";
//                int temp = N[a].pred;
//                while (temp != source) {
//                    cout << temp << "<-";
//                    temp = N[temp].pred;
//                }
//                cout << source << endl;
//            }
//        }
//    }
    int Total = 0;
    for (int a=1; a<n+1; ++a)
        if (a != source)
            if (d[a] != 10000)
                Total += d[a];
    t2=mytimer();
//    cout << "Time: " << t2-t1 << " " << Total << endl;
    if (filename=="inputs/input1.sp")
        cout << "spheap\t";
    cout << t2-t1 << "\t";
    return 0;
}
