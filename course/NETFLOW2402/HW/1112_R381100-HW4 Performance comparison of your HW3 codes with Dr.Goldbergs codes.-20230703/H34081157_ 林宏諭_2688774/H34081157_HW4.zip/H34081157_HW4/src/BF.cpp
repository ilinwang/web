
#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/times.h>

using namespace std;

struct arc {
    int from,to;
    float length;
};
float mytimer()
{ struct tms hold;
 
 times(&hold);
 /*return  (float)(hold.tms_utime) / 60.0;*/
 return  (float)(hold.tms_utime);
}

struct node {
    int num;
    int pred;
};

int main(int argc, const char * argv[]) {
    
    int n,m;
    int sink,source;
    string filename;
    ifstream file;
//    cout << "Enter filename, source node: ";
    cin >> filename >> source;
    file.open(filename,ios::in);
    string line,problem;
    arc * matrix;
    
    float t1=0.,t2=0.;
    t1=mytimer();

    int temp_i,temp_j;
    int * point;
    int * count;
    int * d;
    bool * check;
    node * N;
    int a = 1;
    while (getline(file,line)) {
        char head;
        file >> head;
        if (head == 'p') {
            file >> problem >> n >> m;
            matrix = new arc [m+1];
            point = new int [n+1];
            count = new int [n+1];
            d = new int [n+1];
            N = new node [n+1];
            for (int i=1; i<=n+1; i++){
                N[i].num = i;
                N[i].pred = 0;
                d[i] = 10000;
            }
            for (int i=0; i<=n+1; i++)
                count[i] = 0;
        }
        else if (head == 'a') {
            file >> temp_i >> temp_j;
            count[temp_i]++;
            matrix[a].from = temp_i;
            matrix[a].to = temp_j;
            file >> matrix[a].length;
            a++;
        }
    }
    point[1] = 1;
    
    for (int i=2; i<n+1; i++) {
        point[i] = point[i-1] + count[i-1];
    }
    vector<int> List;
    d[source] = 0;
    List.push_back(source);
    
    while (!List.empty()) {
        int curr = List[0];
        List.erase(List.begin());
        for (int i = point[curr]; i < point[curr+1]; ++i) {
            int value = d[curr] + matrix[i].length;
            if (value <= d[matrix[i].to]) {
                N[matrix[i].to].pred = matrix[i].from;
                d[matrix[i].to] = value;
                List.push_back(matrix[i].to);
            }
        }
    }
    
    
    
//    for (int a=1; a<n+1; ++a) {
//        if (a != source) {
//            cout << source << "->" << a << ":[";
//            if (d[a] == 10000) {
//                cout << "can not reach]" << endl;
//            }
//            else {
//                cout << d[a] << "]" << a << "<-";
//                int temp = N[a].pred;
//                while (temp != source) {
//                    cout << temp << "<-";
//                    temp = N[temp].pred;
//                }
//                cout << source << endl;
//            }
//        }
//    }
    int Total = 0;
    for (int a=1; a<n+1; ++a)
        if (a != source)
            if (d[a] != 10000)
                Total += d[a];
    t2=mytimer();
//    cout << "Time: " << t2-t1 << " " << Total << endl;
    if (filename=="inputs/input1.sp")
        cout << "BF\t";
    cout << t2-t1 << "\t";
    return 0;
}
