g++ src/BF.cpp -o BF
g++ src/PAPE.cpp -o PAPE
g++ src/spdial1.cpp -o spdial1
g++ src/spheap1.cpp -o spheap1

echo "input\t1\t2\t3\t4\t5\t6" >> results/results.txt

#echo "BF\t" >> results/results.txt
for((n=1;n<=6;n++))
do
    echo "inputs/input$n.sp 10" > input.txt
    ./BF < input.txt >> results/results.txt
done
echo "\n" >> results/results.txt
#echo "PAPE\t" >> results/results.txt
for((n=1;n<=6;n++))
do
    echo "inputs/input$n.sp 10" > input.txt
    ./PAPE < input.txt >> results/results.txt
done
echo "\n" >> results/results.txt
#echo "spdial1\t" >> results/results.txt
for((n=1;n<=6;n++))
do
    echo "inputs/input$n.sp 10" > input.txt
    ./spdial1 < input.txt >> results/results.txt
done
echo "\n" >> results/results.txt
#echo "spheap1\t" >> results/results.txt
for((n=1;n<=6;n++))
do
    echo "inputs/input$n.sp 10" > input.txt
    ./spheap1 < input.txt >> results/results.txt
done




