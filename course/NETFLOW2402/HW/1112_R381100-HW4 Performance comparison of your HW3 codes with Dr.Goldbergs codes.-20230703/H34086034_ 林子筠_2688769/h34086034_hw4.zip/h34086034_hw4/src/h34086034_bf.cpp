/*
    This code can be compiled and run ok.

    purpose:
        Read file, printout 1-ALL shortest paths' total length, using BF FIFO.

    usage:
        h34086034_bf  no output file  input1.txt

    input file:
        input1.txt

    output file:
        no

    compile:
        g++ -o h34086034_bf h34086034_bf.cpp

    pseudocode:
    read file, m, and n
    ------
    store arcs A and arc lengths L
    ------
    input s
    ------
    Bellman Ford FIFO
    ------
    print result

    coded by Zi-Yun Lin, ID: H34086034, email: celine20001024@gmail.com
    date: 2023.05.01
*/

#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<queue>
#include <ctime>
using namespace std;

int main(){

	string fname;
	cout << "Please input network filename: ";
	cin  >> fname;
	cout << endl;

	string path = "../inputs/" + fname;

	ifstream file;
	file.open(path.c_str());

	string str, temp;
    int n1, n2, len; //n1: from, n2: to
    int n = 0, m = 0, x = 0;

	while(getline(file,str)){
        //read n,m
        if(str[0] == 'p'){
		    for(int i = 0; i < str.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n = stoi(temp.substr(0,x));
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            m = stoi(temp.substr(x));
            break;
    }}

    vector<int> A[n+1]; //store from to
    vector<int> L[n+1]; //store arc length

    while(getline(file,str)){
		if(str[0] == 'a'){
            //split str for node1
            for(int i = 0; i < str.size(); i++){
                if(isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n1 = stoi(temp.substr(0,x));
            //split str for node2
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n2 = stoi(temp.substr(0,x));
            //split str for arc length
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            len = stoi(temp.substr(x));
            A[n1].push_back(n2);
            L[n1].push_back(len);
        }
    }

    int s = 0;
    cout << "Please input a source node: ";
	cin  >> s;
	while(s > n){
        cout << endl << "!!Warning!!: node " << s << " does not exist." << endl << "Please input a source node: ";
        cin  >> s;
	}
	cout << endl;

	//time computation
    clock_t start = clock();

    //BellmanFord
    int INT_MAX = 2147483647;

    //initialize
    queue<int> Q;
    Q.push(s);

    vector<bool> inQ(n+1, false);
    inQ[s] = true;

    vector<int> d(n+1, INT_MAX); //distance
    d[s] = 0;

    vector<int> pred(n+1,-1); //predecessor
    pred[s] = 0;

    while(!Q.empty()){
        int cur = Q.front(); //current node
        Q.pop();
        inQ[cur] = false;

        for(int j = 0; j < A[cur].size() ; j++){ //for each arc(i,j) in A(i)
            int temp = d[cur] + L[cur][j];
            if(d[cur] != INT_MAX && d[A[cur][j]] > temp){
                d[A[cur][j]] = temp;
                pred[A[cur][j]] = cur;
                if(!inQ[A[cur][j]]){
                    Q.push(A[cur][j]);
                    inQ[A[cur][j]] = true;
    }}}}

    clock_t stop = clock();
    double t = static_cast<double>(stop - start) / CLOCKS_PER_SEC;

    int sum = 0; //sum of all the 1-ALL shortest path lengths
    for(int i = 1; i <= n; i++){
        if(d[i] != INT_MAX){
            sum += d[i];
    }}

    cout << "start: " << start << endl;
    cout << "stop: " << stop << endl;
    cout << "n: " << n << endl;
    cout << "m: " << m << endl;
    cout << "Sum of distances: " << sum << endl;
    cout << "Running time of SP computation: " << t << endl;

	file.close();
	return 0;
}
