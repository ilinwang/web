/*
    This code can be compiled and run ok, but will occur stack overflow when n*C+1 is about 180001.

    purpose:
        Read file, printout 1-ALL shortest paths' total length, using Dijkstra's Dial's bucket.

    usage:
        h34086034_spdial  no output file input1.txt

    input file:
        input1.txt

    output file:
        no

    compile:
        g++ -o h34086034_spdial h34086034_spdial.cpp

    pseudocode:
    read file, m, and n
    ------
    store arcs A and arc lengths L
    ------
    input s
    ------
    Dijkstra's Dial's bucket
    ------
    print result

    coded by Zi-Yun Lin, ID: H34086034, email: celine20001024@gmail.com
    date: 2023.05.03
*/

#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<queue>
#include<algorithm>
#include <ctime>
#include <cmath>
using namespace std;

int main(){

	string fname;
	cout << "Please input network filename: ";
	cin  >> fname;
	cout << endl;

	string path = "../inputs/" + fname;

	ifstream file;
	file.open(path.c_str());

	string str, temp;
    int n1, n2, len; //n1: from, n2: to
    int n = 0, m = 0, x = 0;

	while(getline(file,str)){
        //read n,m
        if(str[0] == 'p'){
		    for(int i = 0; i < str.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n = stoi(temp.substr(0,x));
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            m = stoi(temp.substr(x));
            break;
    }}

    vector<int> A[n+1]; //store from to
    vector<int> L[n+1]; //store arc length

    while(getline(file,str)){
		if(str[0] == 'a'){
            //split str for node1
            for(int i = 0; i < str.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n1 = stoi(temp.substr(0,x));
            //split str for node2
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n2 = stoi(temp.substr(0,x));
            //split str for arc length
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            len = stoi(temp.substr(x));
            A[n1].push_back(n2);
            L[n1].push_back(len);
    }}

    int s = 0;
    cout << "Please input a source node: ";
	cin  >> s;
	while(s > n){
        cout << endl << "!!Warning!!: node " << s << " does not exist." << endl << "Please input a source node: ";
        cin  >> s;
	}
	cout << endl;

	//time computation
    clock_t start = clock();

	//Dial's bucket
	int INT_MAX = 2147483647;
    int C = L[1][0]; //max length

	for(int i = 1; i <= n; i++){
        for(int j = 0; j < L[i].size(); j++){
            if(L[i][j] > C){
                C = L[i][j];
    }}}

    C = sqrt(C);

    //initialize
    vector<int> d(n+1,INT_MAX); //distance
    d[s] = 0;

    vector<int> B[n*C+1]; //creat buckets B
    B[0].push_back(s);

    int idx = 0;
    int min_node;

    while(1){
        while(B[idx].size() == 0 && idx < n*C){idx++;} //find idx of non-empty bucket

        if(idx == n*C){break;}

        min_node = B[idx][0];
        B[idx].erase(B[idx].begin());

        for(int j = 0; j < A[min_node].size() ; j++){ //for each arc(i,j) in A(i)
            if(d[A[min_node][j]] >= d[min_node] + L[min_node][j]){
                if(d[A[min_node][j]] != INT_MAX){
                    B[d[A[min_node][j]]].erase(remove(B[d[A[min_node][j]]].begin(), B[d[A[min_node][j]]].end(), A[min_node][j]), B[d[A[min_node][j]]].end());
                }
                B[d[min_node] + L[min_node][j]].push_back(A[min_node][j]);
                d[A[min_node][j]] =  d[min_node] + L[min_node][j];
    }}}

    clock_t stop = clock();
    double t = static_cast<double>(stop - start) / CLOCKS_PER_SEC;

    int sum = 0; //sum of all the 1-ALL shortest path lengths
    for(int i = 1; i <= n; i++){
        if(d[i] != INT_MAX){
            sum += d[i];
    }}

    cout << "n: " << n << endl;
    cout << "m: " << m << endl;
    cout << "Sum of distances: " << sum << endl;
    cout << "Running time of SP computation: " << t << endl;

	file.close();
	return 0;
}
