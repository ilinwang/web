/*
    This code can be compiled and run okay.

    This code is to read a network file and to let the users input the nodes they want to do 
    the Dijkstra binary heap implementation.

    usage:
        NEWheap_sp.cpp xxx
        where xxx is the input network filename, e.g. test1.sp

    input file:
        test1.sp
        test2.sp

    compile:
        g++ NEWheap_sp.cpp -o NEWheap_sp

    pseudocode:
        struct Arc tail, head, length
        ----- readFile(filename) 
        ifstream ifs(filename)
        if (type == "p") 
            iss >> problemType >> n >> m
            forward_star.resize(n)
        else if (type == "a") 
            iss >> arc.tail >> arc.head >> arc.length
            arcs.push_back(arc)
        
        ----- build forward star
        for (int i = 0; i < arcs.size(); i++) 
            forward_star[arc.tail].push_back(arc)

        ----- printPath(source, node, predecessor)
        if (node == source) 
            cout << node
            return
        cout << node << "<-"
        printPath(source, predecessor[node], predecessor)

        ----- minheap(heap, index, heapSize)
        smallest = index;
        left = 2 * index + 1
        right = 2 * index + 2

        if (left < heapSize && heap[left].first < heap[smallest].first)
            smallest = left

        if (right < heapSize && heap[right].first < heap[smallest].first) 
            smallest = right
        
        if (smallest != index) 
            swap(heap[index], heap[smallest])
            minheap(heap, smallest, heapSize)
    
        ----- buildheap(heap)
        n = heap.size()
        for (int i = n / 2 - 1; i >= 0; i--) 
            minheap(heap, i, n)

        ----- findmin(heap)
        return heap[0]

        ----- deletemin(heap)
        swap(heap[0], heap.back())
        heap.pop_back();
        minheap(heap, 0, heap.size())

        ----- dijkstra(source)
        heap.push_back(make_pair(0, source))
        dist[source] = 0
        buildheap(heap)
        while (!heap.empty())
            u = findmin(heap).second
            deletemin(heap)
            for (int i = 0; i < forward_star[u].size(); i++)
                int v = arc.head
                double weight = arc.length
                if (dist[u] + weight < dist[v])
                    dist[v] = dist[u] + weight
                    predecessor[v] = u
                    heap.push_back(make_pair(dist[v], v))
                    buildheap(heap)

    coded by Yu-Shian Chen, ID: r36114109, email: yushian99@gmail.com
    date: 2023.04.06
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <string>
#include <sstream>
#include <climits>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <map>

using namespace std;

struct Arc {
    int tail, head;
    double length;
};

const int MAX = 10000;

vector<vector<Arc> > forward_star(MAX);
vector<int> dist(MAX, INT_MAX); // for the shortest distances
vector<int> predecessor(MAX, -1);
vector<Arc> arcs;

void minheap(vector<pair<int, int> >& heap, int index, int size) {
    int smallest = index;
    int left = 2 * index + 1;
    int right = 2 * index + 2;

    if (left < size && heap[left].first < heap[smallest].first) {
        smallest = left;
    }

    if (right < size && heap[right].first < heap[smallest].first) {
        smallest = right;
    }

    if (smallest != index) {
        swap(heap[index], heap[smallest]);
        minheap(heap, smallest, size);
    }
}

void buildheap(vector<pair<int, int> >& heap) {
    int n = heap.size();
    for (int i = n / 2 - 1; i >= 0; i--) {
        minheap(heap, i, n); // build the min-heap
    }
}

pair<int, int> findmin(vector<pair<int, int> >& heap) {
    return heap[0]; // find root from the min-heap
}

void deletemin(vector<pair<int, int> >& heap) {
    swap(heap[0], heap.back());
    heap.pop_back(); // delete root from the min-heap
    minheap(heap, 0, heap.size());
}

void dijkstra(int source) {
    vector<pair<int, int> > heap;
    heap.push_back(make_pair(0, source));
    dist[source] = 0; // for the distance of the source node to be 0

    buildheap(heap);

    while (!heap.empty()) {
        int u = findmin(heap).second; // find the node with the minimum distance
        deletemin(heap);

        for (int i = 0; i < forward_star[u].size(); i++) {
            const Arc& arc = forward_star[u][i];
            int v = arc.head; // find the outgoing arc from u
            double weight = arc.length; // get the length between them

            if (dist[u] + weight < dist[v]) {
                dist[v] = dist[u] + weight; // update the distance if a shorter path is found
                predecessor[v] = u; // recored the predessor
                heap.push_back(make_pair(dist[v], v)); // update node v and dist[v] to heap
                buildheap(heap);
            }
        }
    }
}

void readFile(const string& filename) {
    ifstream ifs(filename);
    while (ifs.fail()) {
        cout << "Input file failed\n";
        cout << "Please input network filename: ";
        string input;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');  // clear input buffer
        getline(cin, input);
        ifs.open(input);
    }

    string line;
    int n = 0, m = 0;

    while (getline(ifs, line)) {
        istringstream iss(line);
        string type;
        iss >> type;

        if (type == "p") {
            string problemType;
            iss >> problemType >> n >> m;
            forward_star.resize(n); // resize forward star
        } else if (type == "a") {
            Arc arc;
            iss >> arc.tail >> arc.head >> arc.length; // sort them into the structure arc 
            arcs.push_back(arc);
        }
    }

    for (int i = 0; i < arcs.size(); i++) {
        const Arc& arc = arcs[i];
        forward_star[arc.tail].push_back(arc); // build forward star
    }
}

void printPath(int source, int node, const vector<int>& predecessor) {
    if (node == source) {
        cout << node;
        return;
    }
    cout << node << "<-";
    printPath(source, predecessor[node], predecessor); // print shortest path
}



int main() {
    cout << "Please input network filename: ";
    string filename;
    cin >> filename;

    readFile(filename);

    int source_node;
    cout << "Please input a source node: ";
    cin >> source_node;

    dijkstra(source_node); 

    int total = 0;
    for (int i = 1; i <= forward_star.size(); i++) {
        if (i == source_node)
            continue;
        cout << source_node << "->" << i << ": ";
        if (dist[i] == INT_MAX) {
            cout << "[cannot reach]\n";
        } else {
            cout << "[" << dist[i] << "] ";
            if (dist[i] == 0) {
                cout << i;
            } else {
                printPath(source_node, i, predecessor);
            }
            cout << endl;
        }
    }

    return 0;
}
