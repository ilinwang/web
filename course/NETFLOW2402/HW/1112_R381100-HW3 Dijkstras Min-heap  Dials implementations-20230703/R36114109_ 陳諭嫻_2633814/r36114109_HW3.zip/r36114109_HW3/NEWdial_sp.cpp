/*
    This code can be compiled and run okay.

    This code is to read a network file and to let the users input the nodes they want to do 
    the Dijkstra dial implementation.

    usage:
        NEWdial_sp.cpp xxx
        where xxx is the input network filename, e.g. test1.sp

    input file:
        test1.sp
        test2.sp

    compile:
        g++ NEWdial_sp.cpp -o NEWdial_sp

    pseudocode:
        struct Arc tail, head, length
        ----- readFile(filename) 
        ifstream ifs(filename)
        if (type == "p") 
            iss >> problemType >> n >> m
            forward_star.resize(n)
        else if (type == "a") 
            iss >> arc.tail >> arc.head >> arc.length
            arcs.push_back(arc)
        
        ----- build forward star
        for (int i = 0; i < arcs.size(); i++) 
            forward_star[arc.tail].push_back(arc)

        ----- printPath(source, node, predecessor)
        if (node == source) 
            cout << node
            return
        cout << node << "<-"
        printPath(source, predecessor[node], predecessor)

        ----- Dial(source)
        dist[source] = 0
        buckets[0] = 1

        for (int k = 0; k < forward_star.size(); k++) 
            updated = false

            for (int i = 0; i <= maxBucket; i++) 
                if (buckets[i] == 0) 
                    continue

                for (int u = 0; u < forward_star.size(); u++) 
                    if (dist[u] != i)
                        continue

                    for (int i = 0; i < forward_star[u].size(); i++) 
                        v = arc.head
                        weight = arc.length

                        if (dist[u] + weight < dist[v]) 
                            if (dist[v] != INT_MAX) 
                                buckets[dist[v]]--
                
                            dist[v] = dist[u] + weight
                            predecessor[v] = u
                            buckets[dist[v]]++
                            maxBucket = max(maxBucket, dist[v])
                            updated = true


            if (!updated) 
                break;


    coded by Yu-Shian Chen, ID: r36114109, email: yushian99@gmail.com
    date: 2023.04.07
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <string>
#include <sstream>
#include <climits>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <map>

using namespace std;

struct Arc {
    int tail, head;
    double length;
};

const int MAX = 10000;

vector<vector<Arc> > forward_star(MAX);
vector<int> dist(MAX, INT_MAX); // for the shortest distances
vector<int> buckets(MAX, 0); // for dial
vector<int> predecessor(MAX, -1);
vector<Arc> arcs;

void Dial(int source) {
    fill(dist.begin(), dist.end(), INT_MAX); // initialize all distances to infinity
    fill(buckets.begin(), buckets.end(), 0); // clear the buckets

    dist[source] = 0;
    buckets[0] = 1;

    int maxBucket = 0;
    int n = forward_star.size();  

    for (int k = 0; k < n; k++) {
        bool updated = false;

        for (int i = 0; i <= maxBucket; i++) {
            if (buckets[i] == 0) {
                continue;
            }

            for (int u = 0; u < n; u++) {
                if (dist[u] != i)
                    continue; // skip nodes if their distance is not equal to the current bucket

                for (int i = 0; i < forward_star[u].size(); i++) {
                    const Arc& arc = forward_star[u][i];
                    int v = arc.head; // find the outgoing arc from u
                    double weight = arc.length; // get the arc length 


                    if (dist[u] + weight < dist[v]) {
                        if (dist[v] != INT_MAX) {
                            buckets[dist[v]]--; // remove v from current bucket
                        }

                        dist[v] = dist[u] + weight;
                        predecessor[v] = u;
                        buckets[dist[v]]++; // put v in the right bucket
                        maxBucket = max(maxBucket, dist[v]);
                        updated = true;
                    }
                }
            }
        }

        if (!updated) {
            break;
        }
    }
}

void readFile(const string& filename) {
    ifstream ifs(filename);
    while (ifs.fail()) {
        cout << "Input file failed\n";
        cout << "Please input network filename: ";
        string input;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');  // clear input buffer
        getline(cin, input);
        ifs.open(input);
    }

    string line;
    int n = 0, m = 0;

    while (getline(ifs, line)) {
        istringstream iss(line);
        string type;
        iss >> type;

        if (type == "p") {
            string problemType;
            iss >> problemType >> n >> m;
            forward_star.resize(n); // resize forward star
        } else if (type == "a") {
            Arc arc;
            iss >> arc.tail >> arc.head >> arc.length; // sort them into the structure arc 
            arcs.push_back(arc);
        }
    }

    for (int i = 0; i < arcs.size(); i++) {
        const Arc& arc = arcs[i];
        forward_star[arc.tail].push_back(arc); // build forward star
    }
}

void printPath(int source, int node, const vector<int>& predecessor) {
    if (node == source) {
        cout << node;
        return;
    }
    cout << node << "<-";
    printPath(source, predecessor[node], predecessor); // print shortest path
}


int main() {
    cout << "Please input network filename: ";
    string filename;
    cin >> filename;

    readFile(filename);

    int source_node;
    cout << "Please input a source node: ";
    cin >> source_node;

    Dial(source_node);

    int total = 0;
    for (int i = 1; i <= forward_star.size(); i++) {
        if (i == source_node)
            continue;
        cout << source_node << "->" << i << ": ";
        if (dist[i] == INT_MAX) {
            cout << "[cannot reach]\n";
        } else {
            cout << "[" << dist[i] << "] ";
            if (dist[i] == 0) {
                cout << i;
            } else {
                printPath(source_node, i, predecessor);
            }
            cout << endl;
        }
    }
    return 0;
}
