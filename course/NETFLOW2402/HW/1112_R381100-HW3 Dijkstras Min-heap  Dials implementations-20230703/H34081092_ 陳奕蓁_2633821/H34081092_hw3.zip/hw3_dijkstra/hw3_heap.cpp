/*
   This code can be compiled and run ok.

   This is to calculate the shortest path from source node to other nodes, 
   using the Dijkstra's heap implementation.
   
   usage:
     1. input the name of a sp file
     2. input a source node
     3. output the shortest path to each node
	   
   output files:
     none
	   
   compile:
     gcc -o H34081092_hw2 H34081092_hw2.cpp
   
   pseudocode:
    find_min(heapArr){
        return heapArr[1][0];
    end func

    adjustHeap(heapArr, x:distance, i:nodenum, num:#elements){
        j = num/2;
        arcNum = i;
        
        while(j != 0):
            if x < heapArr[j][1]:
                heapArr[i][0] = heapArr[j][0]
                heapArr[i][1] = heapArr[j][1]
                heapArr[j][0] = arcNum
                heapArr[j][1] = x
                i = j
                j = j/2
            else:
                heapArr[num][0] = arcNum
                heapArr[num][1] = x
                break
            end if
        end while
    end func

    adjustHeap2(heapArr, i:node num, n:#element){
        j = 2*i;
        x = heapArr[i][1];
        arcNum = heapArr[i][0];
        while(j<=n):
            if(j<n):
                if heapArr[j][1] > heapArr[j+1][1] then j++
            end if
        
            if x <= heapArr[j][1]:
                break
            else:
                heapArr[j/2][1] = heapArr[j][1]
                heapArr[j/2][0] = heapArr[j][0]
                j = j * 2
            end if
        end while

        heapArr[j/2][1] = x;
        heapArr[j/2][0] = arcNum;
    end func

    delete_min( heapArr,  n:#element){
        if n==1:
            heapArr[1][0] = 0;
            heapArr[1][1] = 123456;
        else:
            heapArr[1][0] = heapArr[n][0];
            heapArr[1][1] = heapArr[n][1];
            heapArr[n][0] = 0;
            heapArr[n][1] = 123456;
        end if
        n=n-1;

        if n>0 then adjustHeap2(heapArr, 1, n);
    end func

    insertHeap(heapArr, x:distance, i: node num, num:#element){
        
        parentNum = num/2

        if parentNum == 0:
            heapArr[1][0] = i;
            heapArr[1][1] = x; 
        else:
            adjustHeap(heapArr, x, i, num)
        end if
    end func

    decrease_key( heapArr, new_weight, j:node num, n:#element){
        for i=1 t0 n:
            if heapArr[i][0] == j:
                heapArr[i][1] = new_weight;
                break;
            end if
        end for
    end func


    int main()
        head = 1
        count = 1

        for i=1 to n do:
            star[i] = m+1
            while(count <= m)
                if arc[count][0]==i
                    count++
                    if count == m+1
                        star[i] = head
                else
                    star[i] = head;
                    head = count;
                    break;
                end if
            end while
        end for

        for(int i=1; i<=n; i++){
            heapArr[i] = new int [2];
            heapArr[i][1] = 123456;
        }

        elementNum = 0;

        for(int i=1; i<=n; i++){
            d[i] = 123456;
            pred[i] = 0;
        }

        d[s]=0;
        pred[s]=0;

        elementNum++;
        insertHeap(heapArr, d[s], s, elementNum);
        
        while(elementNum != 0):
            i = find_min(heapArr)

            delete_min(heapArr, elementNum)
            elementNum--
            
            for k=star[i] to star[i+1]-1
                if(k>m) then break
                
                j = arc[k][1]
                temp = d[i] + arc[k][2]
                if d[j] > temp:
                    if d[j]==123456:
                        d[j] = temp
                        pred[j] = i
                        elementNum++
                        insertHeap(heapArr, d[j], j, elementNum)
                    else:
                        d[j] = temp
                        pred[j] = i
                        decrease_key(heapArr, d[j], j, elementNum)
                    end if
                end if
            end for
        end while

    coded by Yi-chen Chen, ID: H34081092, email: H34081092@gs.ncku.edu.tw
   date: 2023.03.18
*/

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <sstream>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cmath>
using namespace std;

//read the data and split the lines 
vector<string> split( string line, char x, char tab){
    vector<string> result;
    string tmp = "";

    for(int i=0; i<line.length(); i++){
        if(line[i] == x | line[i]==tab){
            if(tmp!=""){
                result.push_back(tmp);
                tmp = "";
            }
            
        }else{
            tmp += line[i];
            if (i+1 == line.length()){
                result.push_back(tmp);
            }
            
        }
    }
    return result;
}

int ** heapArr;

int find_min(int** heapArr){
    return heapArr[1][0];
}

void adjustHeap(int** heapArr, int x, int i, int num){
    int j = num/2; //j 是 i 的 parent
    int arcNum = i;
    
    while(j != 0){
        if(x < heapArr[j][1]){
            heapArr[i][0] = heapArr[j][0];
            heapArr[i][1] = heapArr[j][1];
            heapArr[j][0] = arcNum;
            heapArr[j][1] = x;
            i = j;
            j = j/2;
        }else{
            heapArr[num][0] = arcNum;
            heapArr[num][1] = x;
            break;
        }
    }
}

void adjustHeap2(int** heapArr, int i, int n){
    int j = 2*i;
    int x = heapArr[i][1];
    int arcNum = heapArr[i][0];
    while(j<=n){
        if(j<n){
            if (heapArr[j][1] > heapArr[j+1][1]) j++;
        }

        if(x <= heapArr[j][1]) {
            break;
        }else{
            heapArr[j/2][1] = heapArr[j][1];
            heapArr[j/2][0] = heapArr[j][0];
            j = j * 2;
        }
    }
    heapArr[j/2][1] = x;
    heapArr[j/2][0] = arcNum;
}

void delete_min(int** heapArr, int n){
    if(n==1){
        heapArr[1][0] = 0;
        heapArr[1][1] = 123456;
    }else{
        heapArr[1][0] = heapArr[n][0];
        heapArr[1][1] = heapArr[n][1];
        heapArr[n][0] = 0;
        heapArr[n][1] = 123456;
    }
    n=n-1;

    if(n>0) adjustHeap2(heapArr, 1, n);
}

void insertHeap(int** heapArr, int x, int i, int num){
    
    int parentNum = num/2;

    if (parentNum == 0){
        // root
        heapArr[1][0] = i; // 編號
        heapArr[1][1] = x; // weight
    }else{
        adjustHeap(heapArr, x, i, num);
    }
}

void decrease_key(int** heapArr, int new_weight, int j, int n){
    for (int i=1; i<=n;i++){
        if (heapArr[i][0] == j){
            heapArr[i][1] = new_weight;
            break;
        }
    }
}


int main(){
    string name, type;
    int n ,m;
    vector<string> tmp;
    ifstream myFile;
    string filename;
    int* star;
    cout<<"Please input network filename:";
    cin>>filename;

    // filename = "test1.sp";

    myFile.open(filename);
    string line;
    int ** arc;
    int c=1;
    int bigM=10000;

    while (getline(myFile, line)) {
        if (line[0]=='t'){
            tmp = split(line,' ','\t');
            name = tmp[1];
        }
        else if(line[0]=='p'){
            tmp = split(line,' ', '\t');
            type = tmp[1];
            n = stoi(tmp[2]);
            m = stoi(tmp[3]);

            arc = new int* [m+1];
            for(int i=1; i<=m;i++){
                arc[i] = new int [3];
            }

        }else if(line[0]=='a'){
            tmp = split(line,' ', '\t');
            
            arc[c][0]=stoi(tmp[1]);
            arc[c][1]=stoi(tmp[2]);
            arc[c][2] = stoi(tmp[3]);
            c+=1;
        }
    }
    //print arc
    // cout <<"arc:" << endl;
    // for (int i=1; i<=m; i++){
    //     cout << "arc[" << i <<"] ";
    //     cout << arc[i][0];
    //     cout << "->";
    //     cout << arc[i][1];
    //     cout << ", weight: " << arc[i][2];
    //     cout << endl;
    // }
    // Close file
    myFile.close();

    star = new int [n+1];

    int head = 1;
    int count = 1;

    for (int i=1; i<=n; i++){
        star[i] = 10;
        while(count <= m){
            if(arc[count][0]==i){
                count++;
                if(count==m+1){
                    star[i] = head;
                }
            }else{
                star[i] = head;
                head = count;
                break;
            }
        }
    }

    // for(int i=1; i<=n; i++){
    //     cout<<star[i]<<endl;
    // }

    // 建立 heap 的 array ，分別存入:1.arc 的編號  2.arc 的 weight
    heapArr = new int * [m+1];
    for(int i=1; i<=n; i++){
        heapArr[i] = new int [2];
        heapArr[i][1] = 123456;
    }
    cout<<endl<<endl;


    int* d = new int [n+1];
    int* pred = new int [n+1];

    int s ;
    cout << "Please input a source node: ";
    cin >> s;
    // s=2;

    int elementNum = 0;

    //begin

    for(int i=1; i<=n; i++){
        d[i] = 123456;
        pred[i] = 0;
    }

    d[s]=0;
    pred[s]=0;

    elementNum++;
    insertHeap(heapArr, d[s], s, elementNum);
    

    while(elementNum != 0){
        int i = find_min(heapArr);

        delete_min(heapArr, elementNum);
        elementNum--;

        for (int k=star[i]; k<star[i+1]; k++){
            if(k>m){
                break;
            }
            int j = arc[k][1];
            int temp = d[i] + arc[k][2];
            if (d[j] > temp){
                if (d[j]==123456){
                    d[j] = temp;
                    pred[j] = i;
                    elementNum++;
                    insertHeap(heapArr, d[j], j, elementNum);
                    
                }else{
                    d[j] = temp;
                    pred[j] = i;
                    decrease_key(heapArr, d[j], j, elementNum);
                }
            }
        }
    }

    cout<<"RESULT:"<<endl;

    for (int i=1; i<=n; i++){
        if(i != s){
            if(d[i]==123456){
                cout << s <<"->" << i << " : " << "[Can not reach]" << endl;
            }else{
                cout << s <<"->" << i << " : [" << d[i] << "]: " ;
                int pre = pred[i];
                cout << i;
                while(pre!=0){
                    cout<<" <- "<< pre ;
                    pre = pred[pre];
                } 
                cout<<endl;
            }
        }
    }
}