/*
   This code can be compiled and run ok.

   This is to calculate the shortest path from source node to other nodes, 
   using the Dijkstra's Dial's implementation.
   
   usage:
     1. input the name of a sp file
     2. input a source node
     3. output the shortest path to each node
  
   input file:
     test1.sp
	   
   output files:
     none
	   
   compile:
     gcc -o hw3_dial hw3_dial.cpp
   
   pseudocode:

    decrease_key(bucket, j:node num, d:new distance, i:current scanned bucket num , N:#bucket)
        while(i!=N)
            found whether node j is in bucket i
            if found then break
        end while
        insert(bucket[d],j)
    end func


    int main
        head = 1
        count = 1

        for i=1 to n do:
            star[i] = m+1
            while(count <= m)
                if arc[count][0]==i
                    count++
                    if count == m+1
                        star[i] = head
                else
                    star[i] = head;
                    head = count;
                    break;
                end if
            end while
        end for


        for  i=2 to m
            if arc[i][2] > arc[max][2]
                max = i
            
        C = arc[max][2]
        N = 1+(n-1)*C

        for i=1 to n
            d[i] = 123456
            pred[i] = 0
        end for

        d[s] = 0;
        pred[s] = 0;

        bucket[0].insert(s)

        int index = 0;
        while index <= N:
            if (!bucket[index].empty()) 
                i = get node from bucket[index]
                
                for  k=star[i] to star[i+1]-1:
                    if(k>m) then break
                    j = arc[k][1]
                    temp = d[i] + arc[k][2]

                    if d[j] > temp
                        d[j] = temp
                        pred[j] = i
                        bucket[temp].insert(j)
                    end if
                end for
            end if
            index++;
        end while

    coded by Yi-chen Chen, ID: H34081092, email: H34081092@gs.ncku.edu.tw
   date: 2023.04.09
*/

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <vector>
#include <cstring>
#include <set>
using namespace std;

//read the data and split the lines 
vector<string> split( string line, char x, char tab){
    vector<string> result;
    string tmp = "";

    for(int i=0; i<line.length(); i++){
        if(line[i] == x | line[i]==tab){
            if(tmp!=""){
                result.push_back(tmp);
                tmp = "";
            }
            
        }else{
            tmp += line[i];
            if (i+1 == line.length()){
                result.push_back(tmp);
            }
            
        }
    }
    return result;
}

void decrease_key(set<int>* bucket, int j, int new_d, int i, int N){
    while(i!=N){
        set<int>::iterator iter;
        iter = bucket[i].find(j);
        if (iter != bucket[i].end()) { //find j in bucket[i]
            bucket[i].erase(*iter);
            break;
        }
    }
    bucket[new_d].insert(j); //insert node j into new bucket
}

int main(){
    string name, type;
    int n ,m;
    vector<string> tmp;
    ifstream myFile;
    string filename;
    int* star;
    cout<<"Please input network filename:";
    cin>>filename;

    // filename = "test1.sp";

    myFile.open(filename);
    string line;
    int ** arc;
    int c=1;
    int bigM=10000;

    while (getline(myFile, line)) {
        if (line[0]=='t'){
            tmp = split(line,' ','\t');
            name = tmp[1];
        }
        else if(line[0]=='p'){
            tmp = split(line,' ', '\t');
            type = tmp[1];
            n = stoi(tmp[2]);
            m = stoi(tmp[3]);

            arc = new int* [m+1];
            for(int i=1; i<=m;i++){
                arc[i] = new int [3];
            }

        }else if(line[0]=='a'){
            tmp = split(line,' ', '\t');
            
            arc[c][0]=stoi(tmp[1]);
            arc[c][1]=stoi(tmp[2]);
            arc[c][2] = stoi(tmp[3]);
            c+=1;
        }
    }
    //print arc
    // cout <<"arc:" << endl;
    // for (int i=1; i<=m; i++){
    //     cout << "arc[" << i <<"] ";
    //     cout << arc[i][0];
    //     cout << "->";
    //     cout << arc[i][1];
    //     cout << ", weight: " << arc[i][2];
    //     cout << endl;
    // }
    // Close file
    myFile.close();

    star = new int [n+1];

    int head = 1;
    int count = 1;

    for (int i=1; i<=n; i++){
        star[i] = m+1;
        while(count <= m){
            if(arc[count][0]==i){
                count++;
                if(count==m+1){
                    star[i] = head;
                }
            }else{
                star[i] = head;
                head = count;
                break;
            }
        }
    }

    int C;
    int max = 1;
    for (int i=2; i<=m; i++){
        if(arc[i][2] > arc[max][2]){
            max = i;
        }
    }

// set bucket
    C = arc[max][2];
    int N = 1+(n-1)*C;

    set<int>* bucket = new set<int> [N];

    int* d = new int [n+1];
    int* pred = new int [n+1];

    int s ;
    // s = 3;
    cout << "Please input a source node: ";
    cin >> s;

    // begin
    for(int i=1; i<=n; i++){
        d[i] = 123456;
        pred[i] = 0;
    }

    d[s] = 0;
    pred[s] = 0;

    // put node s into bucket 0
    bucket[0].insert(s);

    int index = 0;
    while(index <= N){
        if (!bucket[index].empty()) {
            // 從bucket 中取出最小值
            set<int>::iterator iter;
            iter = bucket[index].begin();
            bucket[index].erase(iter);
            int i = *iter;
            
            for (int k=star[i]; k<star[i+1]; k++){
                if(k>m){break;}
                int j = arc[k][1];
                int temp = d[i] + arc[k][2];
                if (d[j] > temp){
                    d[j] = temp;
                    pred[j] = i;
                    bucket[temp].insert(j);

                    //test
                    // cout<<"[insert] ";cout<<"temp="<<temp<<endl;
                    // set<int>::iterator iter;
                    // for (iter = bucket[temp].begin(); iter != bucket[temp].end(); iter++) {
                    //     cout << *iter << ",";
                    // }cout<<endl;
                }
            }
        }
        index++;
    }

    // end
    // print result
    cout<<"RESULT:"<<endl;

    for (int i=1; i<=n; i++){
        if(i != s){
            if(d[i]==123456){
                cout << s <<"->" << i << " : " << "[Can not reach]" << endl;
            }else{
                cout << s <<"->" << i << " : [" << d[i] << "]: " ;
                int pre = pred[i];
                cout << i;
                while(pre!=0){
                    cout<<" <- "<< pre ;
                    pre = pred[pre];
                } 
                cout<<endl;
            }
        }
    }
}