#include <iostream>
# include <fstream>
# include <sstream>
using namespace std;

#ifndef READ_SP_FORWARD_REVERSE_STAR_H_INCLUDED
#define READ_SP_FORWARD_REVERSE_STAR_H_INCLUDED

bool Initialization (int *&pointForward, int *&pointReverse, double **&network, string &fileName, string &problemName, string &problemType, int &n, int &m){
    // open the file
    ifstream myFile;
    cout << "Please input network filename: ";
    cin >> fileName;
    myFile.open(fileName);
    // Check if the file was opened successfully
    if (!myFile.is_open()){
        cout << "Failed to open file " << fileName << "!!" << endl;
        return 0;
    }

    /* read file
    from, to: temporarily record the start and end points of the path
    distance: temporarily record the distance of the path
    line: a line read from a file
    c: the first field in line, expected to be a character
    */
    int from, to;
    double distance;
    string line, c;

    while (getline(myFile, line)){ // read a line from a myFile
        istringstream lineSplitIss(line);
        lineSplitIss >> c; // get the first field in line
        switch (c[0]) {
        // if the first letter is t, store the problem name
        case 't':
            lineSplitIss >> problemName;
            break;
        // if the first letter is p, store the problem type, n, m, and initialize two-dimensional matrix with pointer
        case 'p':
            lineSplitIss >> problemType >> n >> m;
            pointForward = new int[n+2];
            pointReverse = new int[n+2];
            pointForward[n+1] = m+1;
            pointReverse[n+1] = m+1;
            network = new double*[m+1];
            for (int i = 1; i <= n; i++){ // row 1 is where the first arc is stored
                pointForward[i] = 1;
                pointReverse[i] = 1;
            }
            for (int i = 1; i <= m; i++){  network[i] = new double[4]; }// from to cost capacity
            break;
        // if the first letter is a, calculate where the arc starting at each point should be
        case 'a':
            lineSplitIss >> from >> to >> distance;
            for (int i = from + 1; i <= n; i++){ pointForward[i]++; }
            for (int i = to + 1; i <= n; i++){ pointReverse[i]++; }
            break;
        default:
            break;
        }
    }
    myFile.close();
    return 1;
}

void Store_Forward_Star (int *&pointForward, double **&network, string &fileName, int &n){
    // open the file
    ifstream myFile;
    myFile.open(fileName);

    /* read file
    from, to: temporarily record the start and end points of the path
    temp: record the arc that should be used next at each point
    distance: temporarily record the distance of the path
    line: a line read from a file
    c: the first field in line, expected to be a character
    */
    int from, to, temp[n+1];
    double distance;
    string line, c;
    // let temp = pointForward
    for (int i = 0; i <= n; i++){
        temp[i] = pointForward[i];
    }

    while (getline(myFile, line)){ // read a line from a myFile
        istringstream lineSplitIss(line);
        lineSplitIss >> c;
        if (c[0] == 'a') { // if the first letter is a, store arc where it should be
            lineSplitIss >> from >> to >> distance;
            network[temp[from]][0] = from;
            network[temp[from]][1] = to;
            network[temp[from]++][2] = distance;
        }
    }
    myFile.close();
}


void Store_Reverse_Star (int *&pointReverse, double **&network, string &fileName, int &n){
    // open the file
    ifstream myFile;
    myFile.open(fileName);

    /* read file
    from, to: temporarily record the start and end points of the path
    temp: record the arc that should be used next at each point
    distance: temporarily record the distance of the path
    line: a line read from a file
    c: the first field in line, expected to be a character
    */
    int from, to, temp[n+1];
    double distance;
    string line, c;
    // let temp = pointReverse
    for (int i = 0; i <= n; i++){
        temp[i] = pointReverse[i];
    }
    while (getline(myFile, line)){ // read a line from a myFile
        istringstream lineSplitIss(line);
        lineSplitIss >> c;
        if (c[0] == 'a') { // if the first letter is a, store arc where it should be
            lineSplitIss >> from >> to >> distance;
            network[temp[to]][0] = from;
            network[temp[to]][1] = to;
            network[temp[to]++][2] = distance;
        }
    }
    myFile.close();
}

void Store_Forward_Reverse_Star (int *&pointForward, int *&pointReverse, double **&ptrReverse, double **&network, string &fileName, int &n, int &m){
    ifstream myFile;
    myFile.open(fileName);

    /* read file
    from, to: temporarily record the start and end points of the path
    tempForward / tempReverse: record the arc that should be used next at each point
    distance: temporarily record the distance of the path
    line: a line read from a file
    c: the first field in line, expected to be a character
    */
    int from, to, tempForward[n+1], tempReverse[n+1];
    double distance;
    string line, c;
    ptrReverse = new double*[m];
    // let tempForward = pointForward; tempReverse = pointReverse
    for (int i = 0; i <= n; i++){
        tempForward[i] = pointForward[i];
        tempReverse[i] = pointReverse[i];
    }

    while (getline(myFile, line)){ // read a line from a myFile
        istringstream lineSplitIss(line);
        lineSplitIss >> c;
        if (c[0] == 'a') { // if the first letter is a, store arc where it should be
            lineSplitIss >> from >> to >> distance;
            network[tempForward[from]][0] = from;
            network[tempForward[from]][1] = to;
            network[tempForward[from]][2] = distance;
            ptrReverse[tempReverse[to]++] = network[tempForward[from]++]; // I use pointer here
        }
    }
    myFile.close();
}

#endif // READ_SP_FORWARD_REVERSE_STAR_H_INCLUDED
