#ifndef DIJKSTRADIAL_H_INCLUDED
#define DIJKSTRADIAL_H_INCLUDED

using namespace std;

struct Linklist{ // declare node -> node and next
    Linklist(int node):node(node){}
    int node;
    Linklist* next = NULL;
};

class Dial{
public:
    Dial(int n, int C,int s)
        :n(n), C(C){ // initialization
        Buckets = new Linklist*[n*C+2];
        for (int i = 0; i < n*C + 1; i++){
            Buckets[i] = NULL;
        }
        // source node
        Buckets[0] = new Linklist(s);
    }
    Linklist* Find_Next(){ // get the node have smallest distance, and delete it
        while(Buckets[finding_distance] == NULL){ // check bucket until there is/are value(s) in it
            finding_distance++;
            if (finding_distance > n*C){ // if number of bucket larger than nC, return -1
                return new Linklist(-1);
            }
        }
        // when found, pop the first value in the bucket, and return the first value
        Linklist *temp =  Buckets[finding_distance];
        Buckets[finding_distance] = temp->next;
        return temp;
    }
    void Relabel(int node, int original_label, int new_label){
        if (original_label != -1){ // relabel
            Linklist *before =  Buckets[original_label], *temp;
            if (before->node == node){ // if original label is the first value
                temp = before;
                before->next = temp->next;
            }
            else{ // else, find original label
                while (before->next->node != node) { before = before->next; }
                temp = before->next;
                before->next = temp->next;
            }
            //let the label in the bucket of new label
            temp->next = Buckets[new_label];
            Buckets[new_label] = temp;
        }
        else{ // add node
            Linklist *new_node = new Linklist(node);
            new_node->next = Buckets[new_label]; // add new node at the first in the bucket
            Buckets[new_label] = new_node;
        }
    }
private:
    int n;
    int C;
    int finding_distance = 0;
    Linklist** Buckets;
};




#endif // DIJKSTRADIAL_H_INCLUDED
