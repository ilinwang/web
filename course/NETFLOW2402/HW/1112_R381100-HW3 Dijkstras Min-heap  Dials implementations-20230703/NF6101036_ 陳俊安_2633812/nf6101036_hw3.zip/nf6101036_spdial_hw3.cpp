/*
    This code can be compiled and run ok.

    This code is to read a network and output shortest path through binary heap implementation and Dial's implementation

    usage:
        you may input a file which contains a network data and enter a source node, 
        the code will output as follows.
        Output:
    1. distance from source node to each other node
    2. shorest path from source node to each other node

    input file:
        test1.sp
        test2.sp
        
    output files:
        No output file
        
    compile:
        g++ -o ./nf6101036_spdial_hw3.cpp

    pseudocode:

    tokenize(str,del,out)
    --------
    out = split(str,del)
    return out
    --------

    printpath(vec,shortest)
    --------
    if vec.size() == shortest 
        print('*')
    print(vec)
    --------

    int isNotVisited(x, vec)
    --------
    if x in vec
        return 1
    else
        return 0
    --------

    find_idx(vec,i)
    --------
    if i in vec
        return 1
    return 0
    --------

    Dijkstra Alg(adj_list,scr_node)
    --------
    create an array to record the distance
    create an array to record the pre-node

    update scr_node
    while not all the node are permenant node
        find min distance node
        update adjacency node
        if the distance is smaller
            update distance
            update pre-node

    print array(scr, distance array, pre-node array)

    return 0
    
    Print array(scr, distance array, pre-node array)
    --------
    for i in array:
        if i not equal to src:
            while pre-node is blank:
                print  [can not reach]
            while pre-node is not blank and pre-node not equal to src:
                keep printing

    --------
    input file name
    read in file

    while(get each line)
    {

        if first_letter = 'p'
        {
            get num_of_node, num_of_arc
        }

        built a dynamic array base on num_of_node
        built a dynamic array base on num_of_arc

        if first_letter = 'a'
        {
            get from_node, to_node, arc_length 
        }
    }

    input source node
    run dikjstra


    ------

    coded by Chun-An Chen, ID: nf6101036, email: nf6101036@gs.ncku.edu.tw
    date: 2023.04.09
*/
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <map>
#include <cstring>
#include <array>
#include <stdio.h>
#include <queue>
#include <stack>
#include <cstdio>
#include <utility>

using namespace std;

void tokenize(string const &str, const char* delim,
            vector<string> &out)
{
    /*tokenize will read in a string, seperate base on delimiter and output a vector of seperated string*/
    char *token = strtok(const_cast<char*>(str.c_str()), delim);
    while (token != nullptr)
    {
        out.push_back(string(token));
        token = strtok(nullptr, delim);
    }
}

void printpath(vector<int>& path,int sh_path)
{

    int size = path.size();
    int arc_num = size-1;
    if(arc_num == sh_path)
    {
        printf("*");
    }

    printf("[%i]:",arc_num);
    for (int i = 0; i < size-1; i++)
    {
        printf("%i-",path[i]);
    }
    printf("%i\n",path[size-1]);
    
}
 
// utility function to check if current
// vertex is already present in path
int isNotVisited(int x, vector<int>& path)
{
    int size = path.size();
    for (int i = 0; i < size; i++)
        if (path[i] == x)
            return 0;//is visited
    return 1;//is not visited
}

// utility function for finding paths in graph
// from source to destination

int find_idx(vector<int> vec, int ii){

    for (int i = 0; i < vec.size(); i++){
        if (vec[i] == ii){
            return 1;
        }
    }
    return 0;
}

void print_sp(vector<int> &prenode, vector<int> &dist, int src){

    for (int i = 1; i < prenode.size(); i++)
    {
        if (i != src)
        {
            if(prenode[i] == 0)
            {
                printf("%i->%i :[can not reach]\n",i,src);
            }
            else
            {
                int sp_dist = dist[i];
                printf("%i->%i :[%i]",i,src,sp_dist);
                printf("%i",i);
                int p_n = prenode[i];
                while(p_n != src)
                {
                    printf("<-%i",p_n);
                    p_n = prenode[p_n];
                }
                if(p_n == src)
                {
                    printf("<-%i\n",src);
                }
            }
            
        }
    }

}

void Dial_implemtation(vector<vector<pair<int,float> > > &adj_list,int src, int max_w){

    int total_node = adj_list.size();
    vector<int> prenode(total_node,0); //pre-node vector
    int M = 999;
    vector<int> dist(total_node,M);
    vector<bool> permanant_node(total_node,false);
    vector<vector<int> > bucket;
    bucket.resize(max_w*total_node+1);



    int cur_node = src;
    dist[cur_node] = 0;
    bucket[dist[cur_node]].push_back(cur_node);
    int ii = 0;
    while (ii < bucket.size())
    {
        if(not bucket[ii].empty())
        {
            int min_key = bucket[ii][bucket[ii].size()-1];
            cur_node = min_key;
            permanant_node[cur_node] = true;
            for(int i = 0; i < adj_list[cur_node].size(); i++)
            {
                int to_node = adj_list[cur_node][i].first;
                float arc_len = adj_list[cur_node][i].second;

                if (permanant_node[to_node] != true)
                {
                    // 如過要去的新的距離小於原來的距離則更新
                    if(dist[cur_node] + arc_len < dist[to_node])
                    {
                        dist[to_node] = dist[cur_node] + arc_len;
                        prenode[to_node] = cur_node;
                        bucket[dist[to_node]].push_back(to_node);
                    }
         
                }
            }
            bucket[ii].pop_back();
        }
        else{
            ii++;
        }
    }    
    print_sp(prenode,dist,src);
}


int main() {
    
    //input file name
    string filename;
    cout<<"Enter a filename"<<endl;
    cin >> filename;
    // filename = "test1.sp";
    ifstream ifile(filename);
    if(!ifile.is_open())
    {
        printf("Error, file does not exist!!\n");
        exit(0);
    }

    vector<string> rr;
    string s;
    char symbol;
    int from_node, to_node, num_of_node, num_of_arc, max_arcl = 0;
    float arc_len;
    vector<int>::iterator it_vec;
    vector<array<float,3> > arc_info_vec;
    vector<int> node_arc_index_vec;
    vector<vector<pair<int,float> > > adj_list;

    //read each line
     while (getline(ifile, s))
    {
        // cout << s << "\n";
        rr.push_back(s);


        //extract the number of node and arc
        if(s[0] == 'p')
        {
            vector<string> result;
            const char* delim = "	, ,	";
            tokenize(s,delim,result);
                
            num_of_node = stoi(result[2]);
            num_of_arc = stoi(result[3]);
            printf("num of node : %i\n",num_of_node);
            printf("num of arc :  %i\n",num_of_arc);
        }

        // adj_list.resize(num_of_node+1);
        adj_list.resize(num_of_node+1); //record the adjacent list for each node


        //extract arc information
        if(s[0] == 'a')
        {
            // cout << "input arc" << endl;
            vector<string> result;
            const char* delim = "	";
            tokenize(s,delim,result);


            from_node = stoi(result[1]);
            to_node = stoi(result[2]);
            arc_len = stof(result[3]);
            if (arc_len > max_arcl){
                max_arcl = arc_len;
            }
            pair<int,float> p = make_pair(to_node,arc_len);
            adj_list[from_node].push_back(p);
            array<float,3> arc_array = {from_node,to_node,arc_len};
            arc_info_vec.push_back(arc_array);
        }

    }
    
    sort(arc_info_vec.begin(),arc_info_vec.end());

    node_arc_index_vec.push_back(0);
    int init_node = 1;

    //iterate over every node
    for(int i = 0; i < num_of_node; i++)
    {
        //find the first row index of the node
        for(int ii = 0; ii < arc_info_vec.size(); ii++)
        {
            if(arc_info_vec[ii][0] == init_node)
            {
                // cout<<"find first arc index of node " << init_node << endl;
                node_arc_index_vec.push_back(ii);
                init_node += 1;
                break;
            }
            if(init_node == num_of_node)//last node has no adjacent
            {
                node_arc_index_vec.push_back(num_of_arc);
            }
        }

    }

    ifile.close();

    while(true)
    {
        bool is_source_node_bool = true;
        int source_node;

        while(is_source_node_bool)
        {
            printf("Please input a source node\n");
            cin >> source_node;
            it_vec = find(node_arc_index_vec.begin(), node_arc_index_vec.end(), source_node);
            // if(it_vec == node_arc_index.end())
            if(source_node > num_of_node)
            {
                printf("!!Warning!!: node %i does not exist",source_node);
            }
            else
            {
                is_source_node_bool = false;
            }
        }

        //implement
        Dial_implemtation(adj_list,source_node,max_arcl);
        
    }

    return 0;
}