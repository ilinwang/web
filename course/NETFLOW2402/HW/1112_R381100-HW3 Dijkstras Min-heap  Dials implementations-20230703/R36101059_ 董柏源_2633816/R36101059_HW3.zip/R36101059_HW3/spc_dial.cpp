/*
   pseudocode:
   Read a file line by line
   Check every characters for every line
    if line[0] == 'c'
        then skip
    else if line[0] == 't'
        then recode title_of_problem_name
    else if line[0] == 'p'
        then recode problem_type, amount of nodes and amount of arcs
    else if line[0] == 'n'
        then skip
    else if line[0] == 'a'
        then recode from_node, to_node and length

    Construct a forward star

    Input a source node (s)

    dial():
    Initialize;
    while(all bucket != null){
        if(current_bucket != null)
            find_min node i;
            delete node i;
            for each(i,j) belong to A(i)
                temp = d[i] + C[i][j]
                if(temp < d[j])
                    update d[j] , pred[j] and bucket;

        else
            current_bucket++;
    }

    print out 1 to all , distance and path
   ---------------------------------------------------------------------------
*/

#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <cstdlib>
#include <typeinfo>
#include <iomanip>
#include <cctype>
#include <cstring>
#include <vector>

// Settings
using namespace std;
string user_filename;
int user_source_node = 0;
int user_sink_node = 0;
string line;
string title_of_problem_name;
string problem_type;
int num_nodes =0;
int num_arcs =0;
int **graph;
int arc_index_count = 0;
char row_label;
int *point;
int M = 999999;

int *d; //distance
int *pred; //predecessor
vector<vector<int>> dial_bucket;
int C = 0;
int unlimited_index;
int current_bucket;
int deleted_node;

ifstream myFile;
void readFile();
void dial();

int main() {



    while(user_filename != "-1"){
        cout << "Please input network filename (or -1 to exit) : " ;
        cin >> user_filename ;
        myFile.open(user_filename);
        while(!myFile.is_open() && user_filename != "-1"){
            cout <<"failed. wrong filename."<<endl;
            cout << "Please input network filename (or -1 to exit) : " ;
            cin >> user_filename ;
        }
        if(myFile.is_open()){

            cout << "opened"<<endl;
            readFile();

            cout << "Please input a source node (or -1 to exit , -2 to change input file) : " ;
            cin >> user_source_node ;
            while(user_source_node != -1 && user_source_node != -2){
                if(user_source_node > 0 && user_source_node <= num_nodes){
                    dial();
                    cout << "Please input a source node (or -1 to exit , -2 to change input file) : " ;
                    cin >> user_source_node ;
                }
                else{
                    cout <<"!!Warning!!: node "<< user_source_node <<" does not exist"<< endl;
                    cout << "Please input a source node (or -1 to exit , -2 to change input file) : " ;
                    cin >> user_source_node ;
                }
            }
            if(user_source_node == -1){
                user_filename = "-1";
            }
        }

    }
    cout <<"exit"<< endl;

    return 0;
}

void readFile(){

    // Open file

    // Record file content
    //point[node]
    //graph[node][j] j=0 tail  j=1 head  j=2 length
    while (myFile.get(row_label)) {
        if(row_label == 'c'){
            getline(myFile, line);
        }
        else if(row_label == 'p'){
            myFile>>problem_type >> num_nodes >> num_arcs;
            //initialize point & graph size
            point = new int[num_nodes+1];
            graph = new int*[num_arcs];
            point[num_nodes] = num_arcs; //dummy
            arc_index_count = 0;
        }
        else if(row_label == 'n'){
            getline(myFile, line);
        }
        else if(row_label == 'a'){
            //set array_point & array_graph
            graph[arc_index_count] = new int[3];
            myFile >> graph[arc_index_count][0] >> graph[arc_index_count][1] >> graph[arc_index_count][2];
            if(arc_index_count == 0){
                point[graph[arc_index_count][0]-1] = 0;
            }
            else if(graph[arc_index_count][0] != graph[arc_index_count-1][0]){
                point[graph[arc_index_count][0]-1] = arc_index_count;
            }
            if(graph[arc_index_count][2] > C){
                C = graph[arc_index_count][2];
            }
            arc_index_count++;
        }
    }

    for(int i = graph[num_arcs-1][0]; i<num_nodes;i++){
        point[i] = num_arcs;
    }
    for(int i = num_nodes-1; i > 0; i--){
        if(point[i] == 0){
            point[i] = point[i+1];
        }
    }
    //Close file
    myFile.close();
    return;
}

void dial(){
    //Initialize
    d = new int[num_nodes];
    pred = new int[num_nodes];
    dial_bucket.resize((num_nodes-1)*C+2);
    unlimited_index = (num_nodes-1)*C+1;
    current_bucket = 0;
    for(int i= 0 ; i<num_nodes ;i++){
        d[i] = M;
        pred[i] = 0;
        if( i+1 != user_source_node){
            dial_bucket[unlimited_index].push_back(i+1);
        }
        else{
            dial_bucket[0].push_back(i+1);
        }
    }
    d[user_source_node-1] = 0;


    while(!(current_bucket == unlimited_index-1 && dial_bucket[unlimited_index-1].size() == 0)){
        if(dial_bucket[current_bucket].size() != 0){
            deleted_node = dial_bucket[current_bucket][0];
            dial_bucket[current_bucket].erase(dial_bucket[current_bucket].begin());
            for(int i = point[deleted_node-1]; i < point[deleted_node]; i++){
                if(graph[i][2]+d[deleted_node-1] < d[graph[i][1]-1]){
                    if(d[graph[i][1]-1] == M){
                        d[graph[i][1]-1] = graph[i][2]+d[deleted_node-1]; // update distance label
                        for(int j = 0; j<dial_bucket[unlimited_index].size(); j++){
                            if(graph[i][1] == dial_bucket[unlimited_index][j]){
                                dial_bucket[d[graph[i][1]-1]].push_back(graph[i][1]);
                                dial_bucket[unlimited_index].erase(dial_bucket[unlimited_index].begin()+j);
                                break;
                            }
                        }
                    }
                    else{
                        d[graph[i][1]-1] = graph[i][2]+d[deleted_node-1]; // update distance label
                        for(int j = current_bucket; j<dial_bucket.size()-1; j++){
                            for(int k = 0; k<dial_bucket[j].size(); k++){
                                if(graph[i][1] == dial_bucket[j][k]){
                                    dial_bucket[d[graph[i][1]-1]].push_back(graph[i][1]);
                                    dial_bucket[j].erase(dial_bucket[j].begin()+k);
                                    break;
                                }
                            }
                        }
                    }
                    pred[graph[i][1]-1] = deleted_node;
                }
            }
        }
        else
            current_bucket++;
    }

    for (int i = 1; i<=num_nodes; i++){
        if(i != user_source_node){
            cout<< user_source_node <<"->"<<i<<": ";

            if(pred[i-1] == 0){
                cout<< "[can not reach]"<<endl;
            }
            else{
                cout<<"["<<d[i-1]<<"] "<< i <<"<-";
                int pass_node = i ;
                while(pred[pass_node-1] != user_source_node){
                    cout<< pred[pass_node-1] << "<-";
                    pass_node = pred[pass_node-1];
                }
                cout<<user_source_node<<endl;
            }
        }
    }
    return;
}
