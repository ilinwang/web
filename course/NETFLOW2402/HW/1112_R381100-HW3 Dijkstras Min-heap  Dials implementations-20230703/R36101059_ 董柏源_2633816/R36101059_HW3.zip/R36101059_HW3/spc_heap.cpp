/*
   pseudocode:
   Read a file line by line
   Check every characters for every line
    if line[0] == 'c'
        then skip
    else if line[0] == 't'
        then recode title_of_problem_name
    else if line[0] == 'p'
        then recode problem_type, amount of nodes and amount of arcs
    else if line[0] == 'n'
        then skip
    else if line[0] == 'a'
        then recode from_node, to_node and length

    Construct a forward star

    Input a source node (s)

    heap():
    create a heap H;
    Initialize;
    Insert(s,H);
    while( H != null){
        find_min node i;
        delete node i;
        for each(i,j) belong to A(i)
            temp = d[i] + C[i][j]
            if(temp < d[j])
                if(d[j] = M)
                    Insert(j,H)
                decreaseKey(j,temp,H)
                update d[j] , pred[j]
    }

    print out 1 to all , distance and path
   ---------------------------------------------------------------------------
*/
#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <cstdlib>
#include <typeinfo>
#include <iomanip>
#include <cctype>
#include <cstring>
#include <vector>

// Settings
using namespace std;
string user_filename ;
int user_source_node =0;
int user_sink_node =0;
string line;
string title_of_problem_name;
string problem_type;
int num_nodes =0;
int num_arcs =0;
int **graph;
int arc_index_count = 0;
char row_label;
int *point;
int point_index_count = 0;
int M = 999999;

int *d; //distance
int *pred; //predecessor
vector<int> S;
vector<int> H;
int *root;

ifstream myFile;
void readFile();
void minHeapify(int,int);
void decreaseKey(int,int);
void heap();

int main() {

    while(user_filename != "-1"){
        cout << "Please input network filename (or -1 to exit) : " ;
        cin >> user_filename ;
        myFile.open(user_filename);
        while(!myFile.is_open() && user_filename != "-1"){
            cout <<"failed. wrong filename."<<endl;
            cout << "Please input network filename (or -1 to exit) : " ;
            cin >> user_filename ;
        }
        if(myFile.is_open()){

            cout << "opened"<<endl;
            readFile();

            cout << "Please input a source node (or -1 to exit , -2 to change input file) : " ;
            cin >> user_source_node ;
            while(user_source_node != -1 && user_source_node != -2){
                if(user_source_node > 0 && user_source_node <= num_nodes){
                    heap();
                    cout << "Please input a source node (or -1 to exit , -2 to change input file) : " ;
                    cin >> user_source_node ;
                }
                else{
                    cout <<"!!Warning!!: node "<< user_source_node <<" does not exist"<< endl;
                    cout << "Please input a source node (or -1 to exit , -2 to change input file) : " ;
                    cin >> user_source_node ;
                }
            }
            if(user_source_node == -1){
                user_filename = "-1";
            }
        }

    }
    cout <<"exit"<< endl;

    return 0;
}

void readFile(){

    // Open file

    // Record file content
    //point[node]
    //graph[node][j] j=0 tail  j=1 head  j=2 length
    while (myFile.get(row_label)) {
        if(row_label == 'c'){
            getline(myFile, line);
        }
        else if(row_label == 'p'){
            myFile>>problem_type >> num_nodes >> num_arcs;
            //initialize point & graph size
            point = new int[num_nodes+1];
            graph = new int*[num_arcs];
            point[num_nodes] = num_arcs; //dummy
            arc_index_count = 0;
        }
        else if(row_label == 'n'){
            getline(myFile, line);
        }
        else if(row_label == 'a'){
            //set array_point & array_graph
            graph[arc_index_count] = new int[3];
            myFile >> graph[arc_index_count][0] >> graph[arc_index_count][1] >> graph[arc_index_count][2];
            if(arc_index_count == 0){
                point[graph[arc_index_count][0]-1] = 0;
            }
            else if(graph[arc_index_count][0] != graph[arc_index_count-1][0]){
                point[graph[arc_index_count][0]-1] = arc_index_count;
            }

            arc_index_count++;
        }
    }

    for(int i = graph[num_arcs-1][0]; i<num_nodes;i++){
        point[i] = num_arcs;
    }
    for(int i = num_nodes-1; i > 0; i--){
        if(point[i] == 0){
            point[i] = point[i+1];
        }
    }
    //Close file
    myFile.close();
    return;
}

void minHeapify(int node_index,int heap_length){

    int left = 2*node_index;
    int right = 2*node_index+1;
    int smallest;

    if ( left <= heap_length && d[H[left]-1] <= d[H[node_index]-1])
        smallest = left;
    else
        smallest = node_index;

    if (right <= heap_length && d[H[right]-1] <= d[H[smallest]-1])
        smallest = right;

    if (smallest != node_index) {
        swap(H[smallest], H[node_index]);
        minHeapify(smallest,heap_length);
    }
}

void decreaseKey(int node_index, int new_d){

    if (new_d > d[H[node_index]-1]) {
        d[H[node_index]-1] = new_d;
        return;
    }

    d[H[node_index]-1] = new_d;
    while (node_index > 1 && d[H[node_index/2]-1] > d[H[node_index]-1]) {
        swap(H[node_index], H[node_index/2]);
        node_index = node_index/2;
    }

}

void heap(){
    //Initialize
    H.resize(1);
    d = new int[num_nodes];
    pred = new int[num_nodes];
    for(int i= 0 ; i<num_nodes ;i++){
        d[i] = M;
        pred[i] = 0;
    }
    d[user_source_node-1] = 0;

    H.push_back(user_source_node);

    while(H.size() != 1){
        int deleted_node;
        deleted_node = H[1];
        H[1] = H[H.size()-1];
        H.pop_back();
        minHeapify(1,H.size());
        for(int i = point[deleted_node-1]; i < point[deleted_node]; i++){
            if(graph[i][2]+d[deleted_node-1] < d[graph[i][1]-1]){
                if(d[graph[i][1]-1] == M){
                    H.push_back(graph[i][1]);
                    decreaseKey(H.size()-1,graph[i][2]+d[deleted_node-1]);
                }
                for(int j = 1; j<H.size()-1; j++){
                    if(graph[i][1] == H[j]){
                        decreaseKey(j,graph[i][2]+d[deleted_node-1]);
                        break;
                    }
                }
                pred[graph[i][1]-1] = deleted_node;
            }
        }

    }

    for (int i = 1; i<=num_nodes; i++){
        if(i != user_source_node){
            cout<< user_source_node <<"->"<<i<<": ";

            if(pred[i-1] == 0){
                cout<< "[can not reach]"<<endl;
            }
            else{
                cout<<"["<<d[i-1]<<"] "<< i <<"<-";
                int pass_node = i ;
                while(pred[pass_node-1] != user_source_node){
                    cout<< pred[pass_node-1] << "<-";
                    pass_node = pred[pass_node-1];
                }
                cout<<user_source_node<<endl;
            }
        }
    }
    return;
}
