/*
    This code can be compiled and run ok, but will occur stack overflow when n*C+1 is about 180001.

    purpose:
        Read test1.sp file, printout 1-ALL shortest path with length from s, using Dijkstra's Dial's bucket.

    usage:
        h34086034_spdial1  no output file  text1.sp

    input file:
        text1.sp

    output file:
        no

    compile:
        g++ -o h34086034_spdial1 h34086034_spdial1.cpp

    pseudocode:
    read m,n (hw1)
    ------
    vector<int> A[n+1]; //store from to
    vector<int> L[n+1]; //store arc length

    store arcs A and arc lengths L
    ------
    input s
    ------
    //Dial's bucket

    //define max length C
	for i = 1 to n do
        for j = 0 to L[i].size()-1 do
            if L[i][j] > C then C = L[i][j];

    vector<int> B[n*C+1]; //create n*C+1 buckets B

    //initialize
    vector<int> pred(n+1); //predecessor
    vector<int> d(n+1); //distance

    for i = 1 to n do
        d[i] = INT_MAX;
        pred[i] = -1;

    d[s] = 0;
    pred[s] = 0;
    B[0].push_back(s);

    while 1 do
        while B[idx].size() = 0 and idx < n*C do idx++; //find idx of non-empty bucket

        if idx == n*C then break; //done

        min_node = B[idx][0];
        erase min_node from B[idx];

        for each arc(i,j) in A(i) do
            if d[A[min_node][j]] >= d[min_node] + L[min_node][j] then
                if d[A[min_node][j]] != INT_MAX then
                    erase A[min_node][j] from B[d[A[min_node][j]]]

                B[d[min_node] + L[min_node][j]].push_back(A[min_node][j]);
                d[A[min_node][j]] =  d[min_node] + L[min_node][j];
                pred[A[min_node][j]] = min_node;
    ------
    print all shortest path with length from s to all other nodes

    coded by Zi-Yun Lin, ID: H34086034, email: celine20001024@gmail.com
    date: 2023.04.08
*/

#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<queue>
#include<algorithm>
using namespace std;

int main(){

	string fname; //file name

	cout << "Please input network filename: ";
	cin  >> fname;
	cout << endl;

	ifstream file; //read file
	file.open(fname.c_str());

	string str, temp; //str: each line in file, temp: temporary
    int x = 0; //x is used for substr()
    int n1, n2, len; //n1: from, n2: to
    int n = 0, m = 0;

	while(getline(file,str)){
        //read m
        if(str[0] == 'p'){
		    for (int i = 0; i < str.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for (int i = 0; i < temp.size(); i++){
                if (isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            m = stoi(temp.substr(x+1));
        }
        //read n
        if(str[0] == 'n'){
		    n = stoi(str.substr(2));
		    break;
        }
    }

    vector<int> A[n+1]; //store from to
    vector<int> L[n+1]; //store arc length

    while(getline(file,str)){
		if(str[0] == 'a'){
            //split str for node1
            for(int i = 0; i < str.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n1 = stoi(temp.substr(0,x));
            //split str for node2
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n2 = stoi(temp.substr(0,x));
            //split str for arc length
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            len = stoi(temp.substr(x));
            A[n1].push_back(n2);
            L[n1].push_back(len);
    }}

    int s = 0;
    cout << "Please input a source node: ";
	cin  >> s;
	while(s > n){
        cout << endl << "!!Warning!!: node " << s << " does not exist." << endl << "Please input a source node: ";
        cin  >> s;
	}
	cout << endl;

	//Dial's bucket
	int INT_MAX = 2147483647;
    int C = L[1][0]; //max length

	for(int i = 1; i <= n; i++){
        for(int j = 0; j < L[i].size(); j++){
            if(L[i][j] > C){
                C = L[i][j];
            }
        }
	}

    cout << C << endl;
	cout << n*C+1 << endl;

    vector<int> B[n*C+1]; //creat buckets B

    /*for(int i = 1; i <= n*C; i++){
        cout << i << ": ";
        for(int j = 0; j < B[i].size(); j++){
            cout << B[i][j] << " ";
        }
        cout << endl;
	}*/

    //initialize
    vector<int> pred(n+1); //predecessor
    vector<int> d(n+1); //distance

    for(int i = 1; i <= n; i++){
        d[i] = INT_MAX;
        pred[i] = -1;
    }

    d[s] = 0;
    pred[s] = 0;
    B[0].push_back(s);

    int idx = 0;
    int min_node;

    while(1){
        while(B[idx].size() == 0 && idx < n*C){idx++;} //find idx of non-empty bucket

        if(idx == n*C){break;}

        min_node = B[idx][0];
        B[idx].erase(B[idx].begin());

        for(int j = 0; j < A[min_node].size() ; j++){ //for each arc(i,j) in A(i)
            if(d[A[min_node][j]] >= d[min_node] + L[min_node][j]){
                if(d[A[min_node][j]] != INT_MAX){
                    B[d[A[min_node][j]]].erase(remove(B[d[A[min_node][j]]].begin(), B[d[A[min_node][j]]].end(), A[min_node][j]), B[d[A[min_node][j]]].end());
                }
                B[d[min_node] + L[min_node][j]].push_back(A[min_node][j]);
                d[A[min_node][j]] =  d[min_node] + L[min_node][j];
                pred[A[min_node][j]] = min_node;
            }
        }
    }

    for(int i = 1; i <= n; i++){
        if(i != s){
            if(d[i] == INT_MAX){
                cout << s << "->" << i << ": [" << "can not reach" << "]" << endl;
            }
            else{
                cout << s << "->" << i << ": [" << d[i] << "] " << i;
                int temp = i;
                while(pred[temp] != s){
                    cout << "<-" << pred[temp];
                    temp = pred[temp];
                }
            cout << "<-" << s << endl;
    }}}

	file.close();
	return 0;
}
