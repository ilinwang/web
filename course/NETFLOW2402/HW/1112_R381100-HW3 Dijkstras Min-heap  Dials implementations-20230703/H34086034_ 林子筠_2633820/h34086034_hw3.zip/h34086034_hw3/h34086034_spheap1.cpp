/*
    This code can be compiled and run ok.

    purpose:
        Read test1.sp file, printout 1-ALL shortest path with length from s, using Dijkstra's binary heap.

    usage:
        h34086034_spheap1  no output file  text1.sp

    input file:
        text1.sp

    output file:
        no

    compile:
        g++ -o h34086034_spheap1 h34086034_spheap1.cpp

    pseudocode:
    void Update(vector<int> &H, int i){
        left = 2*i + 1;     //left child
        right = 2*i + 2;    //right child
        smallest = i;

        if left < H.size() and H[left] < H[smallest] then
            smallest = left;
        if right < H.size() and H[right] < H[smallest] then
            smallest = right;

        if smallest != i then
            swap H[smallest] and H[i];
            Update(H, smallest);
    ------
    void Insert(vector<int> &H, int node){
        H.push_back(node);

        if H.size() is not empty then
            for i = H.size()/2 - 1 down to 0 do
                Update(H, i);
    ------
    void Delete(vector<int> &H, int node){
        int h;
        for h = 0 to H.size()-1 do
            if node = H[h] then
                break;

        last = H.size() - 1;
        swap H[last] and H[h];

        H.pop_back();
        for i = H.size()/2 - 1 down to 0 do
            Update(H, i);
    ------
    void DecreaseKey(vector<int> &H, int temp, int node){
        int h;
        for h = 0 to H.size()-1 do
            if node = H[h] then
                break;

        H[h] = temp;
        h_parent = (h-1)/2;

        while(h != 0 && H[h_parent] > H[h]){
            swap H[h_parent] and H[h];
            h = h_parent;
    ------
    read m,n (hw1)
    ------
    store arcs A and arc lengths L
    ------
    input s
    ------
    Binary Heap

    INT_MAX = 2147483647;
    creat heap vector<int> H

    //initialize
    vector<int> pred(n+1); //predecessor
    vector<int> d(n+1); //distance

    for i = 1 to n do
        d[i] = INT_MAX;
        pred[i] = -1;
    d[s] = 0;
    pred[s] = 0;

    Insert(H,s);

    int min_node;
    while H.size() is not empty do
        min_node = H[0]; //find min
        Delete(H, min_node); //delete min

        for each arc(i,j) in A(i) do
            temp = d[min_node] + L[min_node][j];
            if d[A[min_node][j]] >= temp then
                if d[A[min_node][j]] = INT_MAX then //not in H yet
                    d[A[min_node][j]] = temp;
                    pred[A[min_node][j]] = min_node;
                    Insert(H, A[min_node][j]);
                else
                    d[A[min_node][j]] = temp;
                    pred[A[min_node][j]] = min_node;
                    DecreaseKey(H,temp,min_node);
    ------
    for i = 1 to n do
        if i != s then
            if d[i] = INT_MAX
                print "can not reach";
            else
                print distance and path;

    coded by Zi-Yun Lin, ID: H34086034, email: celine20001024@gmail.com
    date: 2023.03.23
*/

#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<queue>
using namespace std;

void Update(vector<int> &H, int i){
    int left = 2*i + 1;     //left child
    int right = 2*i + 2;    //right child
    int smallest = i;

    if(left < H.size() && H[left] < H[smallest])
        smallest = left;
    if(right < H.size() && H[right] < H[smallest])
        smallest = right;

    if(smallest != i) {
        int temp = H[smallest];
        H[smallest] = H[i];
        H[i] = temp;
        Update(H, smallest);
}}

void Insert(vector<int> &H, int node){
    H.push_back(node);

    if(H.size() != 0){
        for(int i = H.size()/2 - 1; i >= 0; i--){
            Update(H, i);
}}}

void Delete(vector<int> &H, int node){
    int h;
    for(h = 0; h < H.size(); h++){
        if (node == H[h]){
            break;
    }}

    int last = H.size() - 1;
    int temp = H[last];
    H[last] = H[h];
    H[h] = temp;

    H.pop_back();
    for(int i = H.size()/2 - 1; i >= 0; i--){
        Update(H, i);
}}

void DecreaseKey(vector<int> &H, int temp, int node){
    int h;
    for(h = 0; h < H.size(); h++){
        if(node == H[h]){
            break;
    }}

    H[h] = temp;
    int h_parent = (h-1)/2;

    while(h != 0 && H[h_parent] > H[h]){
        int temp_swap = H[h];
        H[h] = H[h_parent];
        H[h_parent] = temp_swap;
        h = h_parent;
}}

int main(){

	string fname; //file name

	cout << "Please input network filename: ";
	cin  >> fname;
	cout << endl;

	ifstream file; //read file
	file.open(fname.c_str());

	string str, temp; //str: each line in file, temp: temporary
    int x = 0; //x is used for substr()
    int n1, n2; //n1: from, n2: to
    int n = 0, m = 0;
    double len;

	while(getline(file,str)){
        //read m
        if(str[0] == 'p'){
		    for (int i = 0; i < str.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for (int i = 0; i < temp.size(); i++){
                if (isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            m = stoi(temp.substr(x+1));
        }
        //read n
        if(str[0] == 'n'){
		    n = stoi(str.substr(2));
		    break;
    }}

    vector<int> A[n+1]; //store from to
    vector<double> L[n+1]; //store arc length

    while(getline(file,str)){
		if(str[0] == 'a'){
            //split str for node1
            for(int i = 0; i < str.size(); i++){
                if (isdigit(str[i])){
                    x = i;
                    break;
            }}
            temp = str.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n1 = stoi(temp.substr(0,x));
            //split str for node2
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i]) == 0){
                    x = i;
                    break;
            }}
            n2 = stoi(temp.substr(0,x));
            //split str for arc length
            temp = temp.substr(x);
            for(int i = 0; i < temp.size(); i++){
                if(isdigit(temp[i])){
                    x = i;
                    break;
            }}
            len = stod(temp.substr(x));
            A[n1].push_back(n2);
            L[n1].push_back(len);
    }}

    int s = 0;
    cout << "Please input a source node: ";
	cin  >> s;
	while(s > n){
        cout << endl << "!!Warning!!: node " << s << " does not exist." << endl << "Please input a source node: ";
        cin  >> s;
	}
	cout << endl;

    //Binary Heap
    int INT_MAX = 2147483647;
    vector<int> H; //creat heap H

    //initialize
    vector<int> pred(n+1); //predecessor
    vector<int> d(n+1); //distance

    for(int i = 1; i <= n; i++){
        d[i] = INT_MAX;
        pred[i] = -1;
    }

    d[s] = 0;
    pred[s] = 0;

    //insert
    Insert(H,s);

    int min_node;
    while(H.size() != 0){
        min_node = H[0]; //find min
        Delete(H, min_node);

        for(int j = 0; j < A[min_node].size() ; j++){ //for each arc(i,j) in A(i)
            int temp = d[min_node] + L[min_node][j];
            if(d[A[min_node][j]] >= temp){
                if(d[A[min_node][j]] == INT_MAX){
                    d[A[min_node][j]] = temp;
                    pred[A[min_node][j]] = min_node;
                    Insert(H, A[min_node][j]);
                }
                else{
                    d[A[min_node][j]] = temp;
                    pred[A[min_node][j]] = min_node;
                    DecreaseKey(H,temp,min_node);
    }}}}

    for(int i = 1; i <= n; i++){
        if(i != s){
            if(d[i] == INT_MAX){
                cout << s << "->" << i << ": [" << "can not reach" << "]" << endl;
            }
            else{
                cout << s << "->" << i << ": [" << d[i] << "] " << i;
                int temp = i;
                while(pred[temp] != s){
                    cout << "<-" << pred[temp];
                    temp = pred[temp];
                }
            cout << "<-" << s << endl;
    }}}

	file.close();
	return 0;
}
