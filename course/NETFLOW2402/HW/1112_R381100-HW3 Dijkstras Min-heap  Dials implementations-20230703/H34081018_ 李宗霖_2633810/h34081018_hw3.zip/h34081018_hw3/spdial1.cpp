/*
This is to read a network and to do Dijkstra's Dial's implementation.
   
    usage:
        read the network info, choose a source node then see results

        execute spdial1
        input the file name and one node numbers
    
    input file:
        test1.sp or test2.sp
        
    output files:
        none
        
    compile:
        g++ -o spdial1 spdial1.cpp

    pseudocode:
    input filename to read file
    ------
    use struct and class to define arcs and Graphs
    ------
    initial(int s){
        initialize pred and distance with n + 1 spaces
        initialize bucket with 3 * n spaces
        all distance = inf
        distance(s) = 0
        pred(s) = 0
        insert s to bucket 0
    }

    dial(int s){
        initial(s);
        from bucket 0 to bucket 3 * n - 1{
            while(bucktet is not empty){
                pop a node in the bucket
                scan through the arcs start from the node and update distance and bucket if needed
            }
        }
        printd(s);
    }
    ------

    coded by Tsung-Lin Li, ID: h34081018, email: h34081018@gs.ncku.edu.tw
    date: 2023.04.10
*/
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>

using namespace std;

struct edge{
    int head;
    int tail;
    int length;
};

class Graph{
    int node_num, arc_num;
    edge *arcs;
    int *point;
    int *pred, *d;
    vector<vector<int>> bucket;

    public:
    Graph(string filename){
        ifstream readfile(filename);
        string Text;
        int temp = 1, latest_tail = 0;

        // read file line by line
        while (getline (readfile, Text)) {
            // initialize dynamic allocated array
            if(Text[0] == 'p'){
                Text = Text.substr(6);
                istringstream is(Text);
                is >> node_num >> arc_num;
                arcs = new edge[arc_num + 1];
                point = new int[node_num + 1];
            }
            // store arc info
            else if(Text[0] == 'a'){
                Text = Text.substr(2);
                istringstream is(Text);
                is >> arcs[temp].tail >> arcs[temp].head >> arcs[temp].length;
                if(latest_tail != arcs[temp].tail){
                    point[arcs[temp].tail] = temp;
                    latest_tail = arcs[temp].tail;
                }
                else if (temp == arc_num){
                    point[node_num] = arc_num + 1;
                }
                temp++;
            }
        }
        readfile.close();
    }

    void printGraph(){
        for(int i = 1; i < arc_num + 1; i++){
            printf("edge %i (%i -> %i): %i\n", i, arcs[i].tail, arcs[i].head, arcs[i].length);
        }
        for(int i = 1; i < node_num + 1; i++){
            printf("point %i: %i\n", i, point[i]);
        }
    }

    void initial(int s){
        d = new int[node_num + 1];
        pred = new int[node_num + 1];
        bucket.resize(3 * node_num);
        for(int i = 1; i < node_num + 1; i++){
            d[i] = INT_MAX;
        }
        d[s] = 0;
        pred[s] = 0;
        bucket[0].push_back(s);
    }

    void print_bucket(){
        for(int i = 0; i < bucket.size(); i++){
            cout << "bucket " << i << ": ";
            for(int j = 0; j < bucket[i].size(); j++){
                cout << bucket[i][j] << " ";
            }
            cout << endl;
        }
    }

    void dial(int s){
        initial(s);
        for(int i = 0; i < bucket.size(); i++){
            while(!bucket[i].empty()){
                int cur = bucket[i].back();
                bucket[i].pop_back();
                for(int j = point[cur]; j < point[cur + 1]; j++){
                    int temp = d[cur] + arcs[j].length;
                    if(temp < d[arcs[j].head]){
                        d[arcs[j].head] = temp;
                        pred[arcs[j].head] = cur;
                        bucket[temp].push_back(arcs[j].head);
                    }
                }
            }
        }
        printd(s);
    }

    void printd(int s){
        for(int i = 1; i < node_num + 1; i++){
            if(i == s){
                continue;
            }
            if(d[i] != INT_MAX){
                printf("%i->%i: [%i] ", s, i, d[i]);
                int temp = i;
                while(temp != s){
                    cout << temp << "<-";
                    temp = pred[temp];
                }
                cout << s << endl;
            }
            else{
                printf("%i->%i: [can not reach]\n", s, i);
            }
        }
    }

    ~Graph(){
        delete[] arcs, point, d, pred;
    }
};

int main(){
    string filename;
    printf("Please input network filename: ");
    cin >> filename;

    Graph g(filename);
    // g.printGraph();

    int start;
    printf("Please input the source node: ");
    cin >> start;
    cout << endl;

    g.dial(start);
    cout << endl;

    g.~Graph();
    
    return 0;
}