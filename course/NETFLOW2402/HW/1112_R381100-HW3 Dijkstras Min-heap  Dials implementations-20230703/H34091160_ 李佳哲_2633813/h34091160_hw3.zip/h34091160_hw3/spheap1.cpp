/*
   This code can be compiled and run ok.

   Purpose:
     This code can first read a network file and source node(s),
     then output a shortest path with its length from s to all the other nodes by binary mean heap.

   Usage:
     Firstly, user request to input a filename. If filename is invalid, it will print error message and terminate.
     Secondly, user request to input a source node. If source node is invalid, it will print error message and terminate,
     else, it will print out the result of 1-ALL shortest path.

   Input file:
     test1.sp
     test2.sp

   Output files:
     None.

   Compile:
     g++ -o h34091160_hw3_spheap1 h34091160_hw3_spheap1.cpp

 Pseudocode:
   Begin
     create-heap(n);
     d(j) := 999999 for j in N
     d(s) := 0 and pred(s) := -1
     InsertValue(s);
     while heap isn't empty do
     begin
       i = getMin();
       deleteMin();
       for each (i,j) in A(i) do
       Begin
         value := d(i) + c_ij
         if d(j) > value then
            if d(j) is infinite then insertValue(j);
            else decreaseKey(i,value);
            d(j) := d(i) + c_ij
            pred(j) := i
       End
     End
     Print out the results
   End

   coded by 李佳哲, ID: h34091160, email: h34091160@gs.ncku.edu.tw
   date: 2023.05.11
*/

#include <vector>
#include <fstream>
#include <sstream>
#include <iostream>
using namespace std;

// Define the structure of node
struct Nodes {
    int node_index = 0;    // Record the index of the node
    int pred = 0;    // Record the predecessor of the node
    int arc_len = 0;    // Only used in record adj.list, the arc length of arc(i,j)
    int arc_index = 0;    // Only used in record adj.list, the arc index of arc(i,j)
    int d = 0;    // Record the distance label of the node
    int key = 0;    // Heap's key
    Nodes* next;    // Only used in record adj.list, pointer
};

// Define the structure of arc
struct Arcs {
    int arc_index = 0;  // Record the index of the arc
    int s = 0;  // Record the tail node of the arc
    int t = 0;  // Record the head node of the arc
    int distance = 0;  // Record the length of the arc
};

// Define a class that implement adjacency list
class AdjacencyList {
    Nodes* head;
public:
    // Initialize
    AdjacencyList() {
        head = nullptr;
    }

    // Add node to the adj. list
    void addNode(int num, int arc_index, int arc_distance) {
        Nodes* newNode = new Nodes;
        newNode->node_index = num;
        newNode->arc_len = arc_distance;
        newNode->arc_index = arc_index;
        newNode->next = nullptr;

        if (head == nullptr) {
            head = newNode;
        }
        else {
            Nodes* curr = head;
            while (curr->next != nullptr) {
                curr = curr->next;
            }
            curr->next = newNode;
        }
    }

    // Return the outdegree nodes of node i (by array)
    int* outdegree_nodes(int outdegree_num){
        int* out = new int[outdegree_num];
        Nodes* curr = head;

        for(int y=0;y<outdegree_num;y++){
            out[y] = curr->node_index;
            curr = curr->next;
        }
        return out;
    }

    // Return the outdegree arcs of node i (by array)
    int* outdegree_arcs(int outdegree_num){
        int* out = new int[outdegree_num];
        Nodes* curr = head;

        for(int y=0;y<outdegree_num;y++){
            out[y] = curr->arc_index;
            curr = curr->next;
        }
        return out;
    }
};

// Define class to store the index of the node by binary min heap data structure
class BinaryMinHeap {
private:
    vector<int> heap;   // Store the distance label of the node
    vector<int> index;   // Store the index of the node

    // Get the index of the parent
    int parent(int i) {
        return (i - 1) / 2;
    }

    // Get the index of the left child
    int left(int i) {
        return 2 * i + 1;
    }

    // Get the index of the right child
    int right(int i) {
        return 2 * i + 2;
    }

    // Swap two nodes in the heap (both distance label and node index)
    void swap(int i, int j) {
        int temp1 = 0, temp2 = 0;
        temp1 = heap[i];
        heap[i] = heap[j];
        heap[j] = temp1;

        temp2 = index[i];
        index[i] = index[j];
        index[j] = temp2;
    }

    // Heapify a node down the heap if the parent is larger than the child (recursive)
    void heapify_down(int heapIndex) {
        int l = left(heapIndex);
        int r = right(heapIndex);
        int smallest = heapIndex;

        if (l < heap.size() && heap[l] < heap[smallest]) {
            smallest = l;
        }
        if (r < heap.size() && heap[r] < heap[smallest]) {
            smallest = r;
        }
        if (smallest != heapIndex) {
            swap(heapIndex, smallest);
            heapify_down(smallest);
        }
    }

    // Heapify a node up the heap if the child is smaller than the parent (recursive)
    void heapify_up(int heapIndex) {
        int p = parent(heapIndex);

        if (heapIndex > 0 && heap[heapIndex] < heap[p]) {
            swap(heapIndex, p);
            heapify_up(p);
        }
    }

public:
    // Constructor
    BinaryMinHeap(){}

    // Clear the memory
    void cleanMemory() {
        heap.clear();
        index.clear();
    }

    // Find and return the node index of minimum key (root of the heap)
    int find_min_node() {
        if (heap.size() == 0) {
            throw "Heap is empty!";
        }
        return index[0];
    }

    // Insert a new key in the last of the heap (both distance label and node index)
    void insert_key(int value, int node_idx) {
        heap.push_back(value);
        index.push_back(node_idx);
        heapify_up(heap.size() - 1);
    }

    // After DU, decrease the key of an object from its current value to a new value
    void decrease_key(int node_num, int value) {
        int number = 0;
        for (int i=0;i<heap.size();i++) {
            if (index[i] == node_num) {
                number = i;
                break;
            }
        }
        heap[number] = value;  // Distance update
        heapify_up(number);  // Sort the heap
    }

    // Delete the root of the heap (both distance label and node index)
    void delete_min() {
        if (heap.size() == 0) {
            throw "Heap is empty";
        }

        heap[0] = heap.back();
        heap.pop_back();  // delete the root, and replace it by the last value of the heap
        index[0] = index.back();
        index.pop_back();  // delete the root, and replace it by the last value of the heap

        heapify_down(0);  // Sort the heap again
    }

    // Return true if the heap is empty
    bool isEmpty() {
        if (heap.size() == 0) {
            return true;
        }
    }
};

// Dijkstra's SP: binary min heap implementation
void spheap(int source_node, int n,  Nodes* node, Arcs* arc, int* outdegree_num, AdjacencyList* adjList_out){
    // 1. Initialized
    BinaryMinHeap heap;    // Create heap

    for(int i=0;i<n;i++){  // Initialize
        if(i == source_node-1){
            node[i].d = 0;
            node[i].pred = -1;  // I use pred(s) = -1 instead of pred(s) = 0 to prevent conflict (node 1 is node[0] in my code)
        }
        else{
            node[i].d = 999999;
        }
    }

    heap.insert_key(0, source_node-1);  // insert node s to heap

    // 2. While loop (NS and DU)
    while(!heap.isEmpty()){  // While heap is not empty
        // Get the root of heap and delete it
        int i = heap.find_min_node();

        heap.delete_min();

        // array that contains outdegree nodes and arcs of node i
        int* outdeg_num = adjList_out[i + 1].outdegree_nodes(outdegree_num[i]);
        int* outdeg_arc = adjList_out[i + 1].outdegree_arcs(outdegree_num[i]);

        for(int j=0;j<outdegree_num[i];j++){    // for each (i,j) in A(i)
            int value = node[i].d + arc[outdeg_arc[j]-1].distance;    // value = d(i) + c_ij
            if(node[outdeg_num[j]-1].d > value){    // if d(j) > value
                if(node[outdeg_num[j]-1].d == 999999){    // if d(j) is infinite
                    node[outdeg_num[j]-1].d = value;    // d(j) = d(i) + c_ij
                    node[outdeg_num[j]-1].pred = i;    // pred(j) = i
                    heap.insert_key(node[outdeg_num[j]-1].d, node[outdeg_num[j]-1].node_index - 1);
                }
                else{
                    node[outdeg_num[j]-1].d = value;    // d(j) = d(i) + c_ij
                    node[outdeg_num[j]-1].pred = i;    // pred(j) = i
                    heap.decrease_key(node[outdeg_num[j]-1].node_index - 1, value);  // Distance update, then sort the heap again
                }
            }
        }
    }

    // Print out the results
    int sum = 0;
    cout << endl;
    for(int i=0;i<n;i++){
        if(i+1 == source_node){
            continue;
        }
        else if(node[i].d == 999999){
            cout << source_node << "->" << i + 1 << " : [can not reach]" << endl;
        }
        else{
            cout << source_node << "->" << i + 1 << " : [" << node[i].d << "] " << i + 1;
            sum += node[i].d;
            int trace = i;
            while (node[trace].pred != -1) {
                cout << "<-" << node[trace].pred + 1;
                trace = node[trace].pred;
            }
            cout << endl;
        }
    }
    heap.cleanMemory();
}

int main()
{
    string filename;
    cout << "Please input network filename: ";    // User input filename
    getline(cin, filename);
    ifstream file(filename);

    if(!file.is_open()){
        cerr << "Failed to open " << filename << endl;
        return 1;
    }

    string s, first, problem_type, problem_name;
    int n = 0;    // Number of nodes
    int m = 0;    // Number of arcs
    int start_node = 0;    // Starting node of the arc
    int end_node = 0;    // Ending node of the arc
    int distance = 0;    // Distance of the arc
    int index = 0;    // Index of the arc
    bool counter = true;

    Arcs* arc;    // Record arcs
    Nodes* node;    // Record nodes
    AdjacencyList* adjList_out;    // Record adjacency list by outdegree
    int* outdegree_num;    // Record outdegree number of each node

    while (getline(file, s)) {
        istringstream stringfile(s);
        stringfile >> first;    // Read the first word of the line

        if(first[0]=='t'){    // Case 1: When read 't', record title of the problem name
            stringfile >> problem_name;
        }
        else if(first[0]=='p'){    // Case 2: When read 'p', record problem type, # of node and arc
            stringfile >> problem_type >> n >> m;

            // Dynamically allocating memory
            outdegree_num = new int[n];
            node = new Nodes[n];
            arc = new Arcs[m];
            adjList_out = new AdjacencyList[n];

            // Save the nodes
            for(int i=0;i<n;i++){
                node[i].node_index = i + 1;
            }
        }
        else if(first[0]=='a'){    // Case 3: When read 'a', record start node, end node and the distance between them
            stringfile >> start_node >> end_node >> distance;

            // Save the arc information
            arc[index].arc_index = index + 1;
            arc[index].s = start_node;
            arc[index].t = end_node;
            arc[index].distance = distance;

            // Check the outdegree number of each node
            if (counter){
                for(int i=0;i<n;i++){
                    outdegree_num[i] = 0;  // Initialized
                }
                counter = 0;
                outdegree_num[start_node-1]++;
            }
            else{   // Record outdegree number
                outdegree_num[start_node-1]++;
            }

            // Add into adjacency list
            adjList_out[start_node].addNode(arc[index].t, arc[index].arc_index, arc[index].distance);
            index++;
        }
    }

    int source_node = 0;
    cout << "Please input a source node: ";    // User input source node
    cin >> source_node;

    if(source_node <= 0 || source_node > n){    // Print warning message
        cout << "\n!!Warning!!: Node " << source_node << " does not exist." << endl;
    }
    else {
        spheap(source_node, n, node, arc, outdegree_num, adjList_out);  // Execute binary min heap
    }

    delete[] node;   // Clear the memory
    delete[] arc;
    delete[] outdegree_num;
    delete[] adjList_out;

    file.close();    // Close file

    return 0;
}


