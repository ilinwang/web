There are 5 files you should read:
1.A multiple pairs shortest path algorithm 05.pdf : my paper on transportation science which contains 
  description of the algorithm DLU2
2. An algebraic decomposed algorithm for all pairs shortest paths 14.pdf: another paper I wrote which contains description of the algorithm DLU1 (aaim-apsp3.pdf is almost the same)
3.carre.ppt : introduces Caree's APSP algorithm
4.DLU.ppt : introduces my algorithms DLU1 & DLU2 & SLU
5.sp_in_dm_for_netflow : introduces other algegraic APSP algorithms